"""
Demo / validation harness for the robo-advisory pipeline.

Run:  python3 demo.py

This proves the pipeline runs end-to-end (Steps 2-6) on SIMULATED data before
any real peer responses or the Markowitz asset universe are available --
see report Section 8. Also does a basic recovery-accuracy check: since we know
each simulated respondent's true theta, we can check the adaptive engine
actually recovers it, which is the pipeline's most important correctness test.
"""
import sys
import numpy as np
import pandas as pd
sys.path.insert(0, ".")

from robo_advisory.pipeline import run_full_pipeline, simulate_peer_group, synthetic_asset_universe
from robo_advisory.elicitation.models import PARAM_NAMES

pd.set_option("display.width", 160)
pd.set_option("display.max_columns", 20)


def recovery_check(peer):
    """How close does the adaptive engine's posterior mean land to the
    respondent's TRUE simulated parameters? (Only possible in simulation --
    this is exactly the validation step real data can't give us.)
    """
    print("\n=== Parameter recovery check (simulation only) ===")
    errs = {p: [] for p in PARAM_NAMES}
    for name in peer["names"]:
        session = peer["sessions"][name]
        summary = session.posterior_summary()
        true_theta = peer["true_thetas"][name]
        print(f"\n{name}:")
        for i, p in enumerate(PARAM_NAMES):
            est = summary[p]["mean"]
            lo, hi = summary[p]["ci90"]
            true_v = true_theta[i]
            in_ci = lo <= true_v <= hi
            err = abs(est - true_v)
            errs[p].append(err)
            print(f"  {p:9s}  true={true_v:6.3f}  est={est:6.3f}  90%CI=({lo:6.3f},{hi:6.3f})  "
                  f"{'OK' if in_ci else 'MISS'}")
    print("\nMean absolute error per parameter across the simulated peer group:")
    for p in PARAM_NAMES:
        print(f"  {p:9s}  MAE={np.mean(errs[p]):.4f}")


def main():
    print("=" * 78)
    print("ROBO-ADVISORY PIPELINE -- END-TO-END DEMO RUN (synthetic data)")
    print("=" * 78)

    df, universe, peer = run_full_pipeline(n_people=5, n_assets=10, seed=42)
    recovery_check(peer)

    print("\n" + "=" * 78)
    print("Full pipeline run: Steps 2-6 -> per-respondent EUT & BPT portfolios")
    print("=" * 78)
    df, universe, peer = run_full_pipeline(n_people=5, n_assets=10, seed=42)
    print("\nAsset universe (synthetic placeholder for the Markowitz project's real mu/Sigma):")
    print(pd.DataFrame({"ticker": universe["tickers"], "mu": universe["mu"].round(3)}))
    print(f"rf = {universe['rf']:.3f}")

    print("\nPer-respondent results:")
    display_cols = ["respondent", "gamma_pooled", "lambda_pooled", "beta_present_bias",
                     "retest_consistency", "EUT_risky_fraction", "EUT_expected_return",
                     "EUT_volatility", "BPT_safety_capital_frac", "BPT_combined_return",
                     "BPT_combined_volatility"]
    print(df[display_cols].round(3).to_string(index=False))

    from robo_advisory.elicitation.hierarchical import pool_group
    pooled_debug = pool_group(list(peer["sessions"].values()))
    print("\nShrinkage weights applied (gamma, lambda) -- transparency on how much each")
    print("respondent's pooled estimate leans on their own data vs. the group mean:")
    for name in peer["names"]:
        g = pooled_debug[name]["gamma"]
        l = pooled_debug[name]["lam"]
        print(f"  {name:8s} gamma: raw={g['raw']:.3f} pooled={g['pooled']:.3f} w={g['shrinkage_weight']:.2f}  |  "
              f"lambda: raw={l['raw']:.3f} pooled={l['pooled']:.3f} w={l['shrinkage_weight']:.2f}")

    print("\nStep 6 commentary:")
    for _, row in df.iterrows():
        print(f"  - {row['commentary']}")

    out_path = "outputs/demo_pipeline_results.csv"
    df.to_csv(out_path, index=False)
    print(f"\nFull results written to {out_path}")


if __name__ == "__main__":
    main()
