"""
Minimal correctness test suite. Run with:  python3 -m pytest tests/ -v
(or: python3 tests/test_pipeline.py  to run without pytest installed)
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np

from robo_advisory.elicitation.engine import run_adaptive_session, retest_consistency, N_GRID
from robo_advisory.elicitation.hierarchical import pool_group
from robo_advisory.personality.bfi2_scoring import score_bfi2, BFI2_ITEMS
from robo_advisory.portfolio.eut import eut_allocation, tangency_weights
from robo_advisory.portfolio.bpt import safety_first_weights, bpt_allocation, safety_capital_fraction_from_lambda
from robo_advisory.ingest import (load_respondent_json, load_peer_group, load_peer_group_glob,
                                    pool_group_from_summaries, score_all_bfi2)
from robo_advisory.pipeline import run_full_pipeline, run_full_pipeline_from_real_data, synthetic_asset_universe


def test_posterior_sums_to_one():
    theta = np.array([1.0, 2.0, 0.9, 0.8, 0.97])
    s = run_adaptive_session("t1", theta, n_questions=6, rng=np.random.default_rng(0))
    post = s.posterior()
    assert post.shape[0] == N_GRID
    assert abs(post.sum() - 1.0) < 1e-8
    assert np.all(post >= 0)


def test_retest_consistency_range():
    theta = np.array([1.0, 2.0, 0.9, 0.8, 0.97])
    s = run_adaptive_session("t2", theta, n_questions=10, n_retests=2, rng=np.random.default_rng(1))
    rc = retest_consistency(s)
    assert 0.0 <= rc <= 1.0


def test_hierarchical_pooling_floor():
    theta_a = np.array([0.5, 1.5, 0.9, 0.8, 0.97])
    theta_b = np.array([2.5, 3.5, 1.1, 0.7, 0.95])
    sa = run_adaptive_session("A", theta_a, n_questions=8, rng=np.random.default_rng(2))
    sb = run_adaptive_session("B", theta_b, n_questions=8, rng=np.random.default_rng(3))
    pooled = pool_group([sa, sb], min_individual_weight=0.3)
    assert pooled["A"]["gamma"]["shrinkage_weight"] >= 0.3
    # pooled estimates for A and B should still differ (not fully collapsed)
    assert abs(pooled["A"]["gamma"]["pooled"] - pooled["B"]["gamma"]["pooled"]) > 1e-6


def test_bfi2_scoring_ranges():
    responses = {i: 3 for i in range(60)}  # all "neutral" responses
    result = score_bfi2(responses)
    assert set(result["domains"].keys()) == {
        "Extraversion", "Agreeableness", "Conscientiousness",
        "Negative Emotionality", "Open-Mindedness"}
    for v in result["domains"].values():
        assert 1.0 <= v <= 5.0
    assert result["n_items_scored"] == 60
    assert result["missing_items"] == []
    assert len(BFI2_ITEMS) == 60


def test_bfi2_missing_items():
    responses = {i: 3 for i in range(54)}  # 6 items missing
    result = score_bfi2(responses)
    assert result["n_items_scored"] == 54
    assert len(result["missing_items"]) == 6


def test_tangency_weights_sum_to_one():
    mu = np.array([0.10, 0.15, 0.08])
    sigma = np.array([[0.04, 0.01, 0.0], [0.01, 0.09, 0.0], [0.0, 0.0, 0.02]])
    w = tangency_weights(mu, sigma, rf=0.05)
    assert abs(w.sum() - 1.0) < 1e-8


def test_eut_allocation_bounds():
    mu = np.array([0.10, 0.15, 0.08])
    sigma = np.array([[0.04, 0.01, 0.0], [0.01, 0.09, 0.0], [0.0, 0.0, 0.02]])
    result = eut_allocation(mu, sigma, rf=0.05, gamma=3.0, long_only=True)
    assert 0.0 <= result["risky_fraction"] <= 1.0
    assert abs(result["risky_weights"].sum() - 1.0) < 1e-6
    # higher gamma -> lower risky fraction (monotonicity sanity check)
    result_low_gamma = eut_allocation(mu, sigma, rf=0.05, gamma=0.5, long_only=True)
    assert result_low_gamma["risky_fraction"] >= result["risky_fraction"]


def test_eut_rejects_nonpositive_gamma():
    mu = np.array([0.10, 0.15])
    sigma = np.eye(2) * 0.04
    try:
        eut_allocation(mu, sigma, rf=0.05, gamma=0.0)
        assert False, "should have raised"
    except ValueError:
        pass


def test_safety_first_weights_valid_simplex():
    mu = np.array([0.10, 0.15, 0.08, 0.20])
    sigma = np.eye(4) * 0.05 + 0.01
    result = safety_first_weights(mu, sigma, threshold=0.05)
    w = result["weights"]
    assert abs(w.sum() - 1.0) < 1e-4
    assert np.all(w >= -1e-6)


def test_bpt_safety_fraction_monotonic_in_lambda():
    frac_low = safety_capital_fraction_from_lambda(1.0)
    frac_high = safety_capital_fraction_from_lambda(4.0)
    assert frac_high > frac_low
    assert 0.0 <= frac_low <= 1.0 and 0.0 <= frac_high <= 1.0


def test_bpt_allocation_runs():
    mu = np.array([0.10, 0.15, 0.08, 0.20])
    sigma = np.eye(4) * 0.05 + 0.01
    result = bpt_allocation(mu, sigma, rf=0.05, safety_threshold=0.0,
                             aspiration_threshold=0.14, safety_capital_frac=0.6)
    # stock weights + G-Sec weight = all of the client's wealth
    assert abs(result["combined_weights"].sum() + result["gsec_weight"] - 1.0) < 1e-6
    assert np.all(result["combined_weights"] >= -1e-9)
    assert 0.0 <= result["gsec_weight"] <= 0.6 + 1e-9


def _real_universe():
    from robo_advisory.pipeline import load_real_asset_universe
    d = os.path.join(os.path.dirname(__file__), "..", "real_asset_universe_standard_lambda")
    return load_real_asset_universe(os.path.join(d, "mu.csv"), os.path.join(d, "covariance.csv"), rf=0.0675)


def test_capped_tangency_respects_cap_and_matches_uncapped_when_slack():
    from robo_advisory.portfolio.eut import max_ratio_weights
    u = _real_universe()
    w = max_ratio_weights(u["mu"], u["sigma"], u["rf"], cap=0.10)
    assert abs(w.sum() - 1.0) < 1e-9 and w.min() >= 0 and w.max() <= 0.10 + 1e-9
    # with a cap that never binds, the QP must reproduce the closed-form tangency
    w_free = max_ratio_weights(u["mu"], u["sigma"], u["rf"], cap=0.50)
    w_cf = tangency_weights(u["mu"], u["sigma"], u["rf"])
    assert np.abs(w_free - w_cf).max() < 1e-5


def test_capped_tangency_beats_random_feasible_portfolios():
    from robo_advisory.portfolio.eut import max_ratio_weights, portfolio_stats
    u = _real_universe()
    mu, S, rf = u["mu"], u["sigma"], u["rf"]
    w = max_ratio_weights(mu, S, rf, cap=0.10)
    r, v = portfolio_stats(w, mu, S)
    best = (r - rf) / v
    rng = np.random.default_rng(0)
    for _ in range(200):
        x = rng.dirichlet(np.ones(len(mu)))
        if x.max() > 0.10:
            continue
        r2, v2 = portfolio_stats(x, mu, S)
        assert (r2 - rf) / v2 <= best + 1e-9


def test_telser_safety_account_meets_shortfall_constraint():
    from scipy.stats import norm
    from robo_advisory.portfolio.bpt import telser_equity_share, prob_below
    e = telser_equity_share(mu_T=0.1324, sigma_T=0.1617, rf=0.0675, floor=0.0, alpha=0.05)
    mu_s, sig_s = 0.0675 + e * (0.1324 - 0.0675), e * 0.1617
    assert 0 < e < 1
    assert abs(prob_below(mu_s, sig_s, 0.0) - 0.05) < 1e-9          # binds exactly at alpha
    assert mu_s - norm.ppf(0.95) * sig_s >= -1e-12


def test_bpt_v2_risk_falls_with_loss_aversion_and_is_diversified():
    from robo_advisory.pipeline import _construct_portfolios
    u = _real_universe()
    rows = [_construct_portfolios(f"c{lam}", 2.0, lam, u, {}) for lam in (1.0, 1.6, 2.5, 4.0)]
    vols = [r["BPT_combined_volatility"] for r in rows]
    gsec = [r["BPT_gsec_weight"] for r in rows]
    assert all(a > b for a, b in zip(vols, vols[1:]))       # more loss-averse -> less risk
    assert all(a < b for a, b in zip(gsec, gsec[1:]))       # ... and more G-Secs
    assert max(r["BPT_max_single_stock"] for r in rows) <= 0.10 + 1e-9
    assert max(r["EUT_max_single_stock"] for r in rows) <= 0.10 + 1e-9


def test_bfi2_facet_balance():
    from collections import Counter
    facet_keying = {}
    for it in BFI2_ITEMS:
        f = it["facet"]
        facet_keying.setdefault(f, {"true": 0, "rev": 0})
        facet_keying[f]["rev" if it["reverse"] else "true"] += 1
    assert len(facet_keying) == 15
    assert all(v["true"] == 2 and v["rev"] == 2 for v in facet_keying.values())
    dom_counts = Counter(it["domain"] for it in BFI2_ITEMS)
    assert all(c == 12 for c in dom_counts.values())


def test_ingest_load_and_pool_real_fixtures():
    import glob, os
    fixture_dir = os.path.join(os.path.dirname(__file__), "..", "sample_real_data")
    paths = sorted(glob.glob(os.path.join(fixture_dir, "*.json")))
    assert len(paths) >= 2, "expected sample_real_data fixtures to exist for this test"

    pg = load_peer_group(paths)
    assert len(pg["names"]) == len(paths)

    pooled = pool_group_from_summaries(pg["raw"])
    for name in pg["names"]:
        assert "gamma" in pooled[name]
        assert 0.30 <= pooled[name]["gamma"]["shrinkage_weight"] <= 1.0

    bfi2_all = score_all_bfi2(pg["raw"])
    for name in pg["names"]:
        # independent Python re-scoring must match the JS-computed summary
        # the survey shipped in the same file (cross-implementation check)
        py_domains = bfi2_all[name]["domains"]
        js_domains = pg["raw"][name]["bfi2"]["domains"]
        for d in js_domains:
            assert abs(py_domains[d] - js_domains[d]) < 0.01, f"{name}/{d} Python vs JS mismatch"


def test_pipeline_real_data_end_to_end():
    import glob, os
    fixture_dir = os.path.join(os.path.dirname(__file__), "..", "sample_real_data")
    paths = sorted(glob.glob(os.path.join(fixture_dir, "*.json")))
    universe = synthetic_asset_universe(n_assets=6, seed=3)
    df = run_full_pipeline_from_real_data(paths, universe)
    assert len(df) == len(paths)
    for col in ("gamma_pooled", "lambda_pooled", "EUT_risky_fraction", "BPT_safety_capital_frac"):
        assert col in df.columns
        assert df[col].notna().all()
    # BPT safety allocation should increase with loss aversion (monotonicity sanity check)
    assert df.sort_values("lambda_pooled")["BPT_safety_capital_frac"].is_monotonic_increasing


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    passed, failed = 0, 0
    for t in tests:
        try:
            t()
            print(f"PASS  {t.__name__}")
            passed += 1
        except Exception as e:
            print(f"FAIL  {t.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
