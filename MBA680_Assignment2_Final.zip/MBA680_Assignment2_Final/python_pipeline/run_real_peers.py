"""
run_real_peers.py
==================
Runs the 5 confirmed-valid real peer-group respondents through the FULL
pipeline: Steps 2-4 (elicitation pooling, BFI-2 scoring), Step 5 (EUT +
SP/A-BPT portfolio construction against the REAL Markowitz Portfolio
Project asset universe), and Step 6 (rule-based commentary).

Respondent attribution (confirmed by the user; internal file 'name' field
did not always match -- see each file's _attribution_note):
  - Shree Charan  <- attachment.txt / shree-charan-risk-time-results.json
                     (internal name recorded as "Ineni sree charan")
  - Kshitij       <- rajat-risk-time-results.json
                     (internal name recorded as "Rajat" -- misspelling, per
                      user: "Kshitij is misspelled as Rajat")
  - Kartika       <- kratika_soni_assessment.json
                     (internal name recorded as "Kratika Soni")
  - Ayushi        <- ayushi-risk-time-results.json (internal name "Ayushi",
                     no correction needed; also confirmed as a co-author on
                     the Markowitz Portfolio Project report, "Ayushi Mishra")
  - Adwaaiit Pande <- adwaaiit-risk-time-results.json (the user's own
                     response; internal name "Adwaaiit Pande", no correction
                     needed; retestConsistency=1.0)

EXCLUDED per explicit user instruction ("The file is nonsense. Leave it."):
  - sree-charan-risk-time-results.json (the separately-uploaded file, NOT
    the pasted attachment.txt above) -- all 20 adaptive questions were
    answered identically (choseB=false throughout), a degenerate
    non-responsive pattern, and its generalRisk=10 self-report directly
    contradicts the extremely risk-averse-looking posterior it produced.

Asset universe: REAL data, extracted from the group's own delivered
Markowitz Portfolio Project workbook (MBA680_Portfolio_Workbook_Final.xlsx)
-- 66-stock NSE universe, 3-year annualized covariance matrix, rf=6.75%.
The workbook exposes the covariance matrix and the final optimal
(max-Sharpe) portfolio P's weights and summary stats, but NOT a per-asset
expected-return vector directly. Per-asset mu was therefore back-solved via
Black-Litterman-style reverse optimization (implied equilibrium returns):
    lambda_mkt = (E[Rp] - rf) / sigma_p^2
    mu_implied = rf*1 + lambda_mkt * Sigma @ w_P
using the workbook's own reported optimal portfolio P as the reference.
Verified internally consistent: w_P . mu_implied reproduces E[Rp] to 6
decimal places, and w_P' Sigma w_P reproduces sigma_p^2 exactly. See
real_asset_universe/meta.json for the full derivation record. This is a
disclosed modeling step (not raw data), same spirit as this project's other
disclosed approximations (CI-to-variance, hierarchical-pooling floor, etc.)
-- state it plainly wherever these portfolio numbers are used, do not
present mu_implied as if it were given data.
"""
from __future__ import annotations
import json
from pathlib import Path

import numpy as np
import pandas as pd

from robo_advisory.ingest import load_peer_group, pool_group_from_summaries, score_all_bfi2
from robo_advisory.pipeline import build_commentary, _construct_portfolios, load_real_asset_universe

DATA_DIR = Path(__file__).parent / "real_peer_data"
RESPONDENT_FILES = [
    str(DATA_DIR / "shree-charan-risk-time-results.json"),
    str(DATA_DIR / "kshitij-risk-time-results.json"),
    str(DATA_DIR / "kartika-risk-time-results.json"),
    str(DATA_DIR / "ayushi-risk-time-results.json"),
    str(DATA_DIR / "adwaaiit-risk-time-results.json"),
]

UNIVERSE_DIR = Path(__file__).parent / "real_asset_universe"
UNIVERSE_DIR_STD = Path(__file__).parent / "real_asset_universe_standard_lambda"


def main():
    pg = load_peer_group(RESPONDENT_FILES)
    pooled = pool_group_from_summaries(pg["raw"], min_individual_weight=0.30)
    bfi2_all = score_all_bfi2(pg["raw"])

    universe = load_real_asset_universe(
        str(UNIVERSE_DIR / "mu.csv"), str(UNIVERSE_DIR / "covariance.csv"), rf=0.0675
    )
    meta = json.loads((UNIVERSE_DIR / "meta.json").read_text())
    universe_std = load_real_asset_universe(
        str(UNIVERSE_DIR_STD / "mu.csv"), str(UNIVERSE_DIR_STD / "covariance.csv"), rf=0.0675
    )
    meta_std = json.loads((UNIVERSE_DIR_STD / "meta.json").read_text())

    # --- Steps 2-4 + 6 summary --------------------------------------------
    print("=" * 78)
    print("STEPS 2-4 & 6: Elicited & pooled behavioral parameters, personality, commentary")
    print("=" * 78)
    summary_rows = []
    for name in pg["names"]:
        data = pg["raw"][name]
        params = pooled[name]
        bfi2 = bfi2_all[name]
        commentary = build_commentary(name, params["lam"]["pooled"], bfi2["domains"])

        summary_rows.append({
            "respondent": name,
            "generalRisk_0to10": data.get("generalRisk"),
            "generalPatience_0to10": data.get("generalPatience"),
            "grableLytton_total": (data.get("grableLytton") or {}).get("total"),
            "grableLytton_level": (data.get("grableLytton") or {}).get("level"),
            "dospert_investing_mean": (data.get("dospertFinancial") or {}).get("investingMean"),
            "dospert_gambling_mean": (data.get("dospertFinancial") or {}).get("gamblingMean"),
            "gamma_raw": round(params["gamma"]["raw"], 3),
            "gamma_pooled": round(params["gamma"]["pooled"], 3),
            "lambda_raw": round(params["lam"]["raw"], 3),
            "lambda_pooled": round(params["lam"]["pooled"], 3),
            "alpha_w_pooled": round(params["alpha_w"]["pooled"], 3),
            "beta_hyp_pooled": round(params["beta_hyp"]["pooled"], 3),
            "delta_pooled": round(params["delta"]["pooled"], 3),
            "retestConsistency": data.get("retestConsistency"),
            "bfi2_Extraversion": round(bfi2["domains"].get("Extraversion", float("nan")), 2),
            "bfi2_Agreeableness": round(bfi2["domains"].get("Agreeableness", float("nan")), 2),
            "bfi2_Conscientiousness": round(bfi2["domains"].get("Conscientiousness", float("nan")), 2),
            "bfi2_NegativeEmotionality": round(bfi2["domains"].get("Negative Emotionality", float("nan")), 2),
            "bfi2_OpenMindedness": round(bfi2["domains"].get("Open-Mindedness", float("nan")), 2),
            "bfi2_source": bfi2.get("source", "js-computed"),
            "step6_commentary": " | ".join(commentary),
        })

    summary_df = pd.DataFrame(summary_rows)
    pd.set_option("display.width", 220)
    pd.set_option("display.max_columns", 50)
    print(summary_df.to_string(index=False))

    out_dir = Path(__file__).parent / "outputs"
    out_dir.mkdir(exist_ok=True)
    summary_df.to_csv(out_dir / "real_peers_steps2to4and6.csv", index=False)

    # --- Data-quality flags -------------------------------------------------
    print("\n" + "=" * 78)
    print("DATA-QUALITY FLAGS (disclosed limitations)")
    print("=" * 78)
    for name in pg["names"]:
        degenerate = [p for p in ["gamma", "lam", "alpha_w", "beta_hyp", "delta"]
                      if abs(pg["raw"][name]["posterior"][p]["ci90"][1]
                             - pg["raw"][name]["posterior"][p]["ci90"][0]) < 1e-6]
        flags = []
        if degenerate:
            flags.append(f"zero-width 90% CI on {degenerate}")
        rc = pg["raw"][name].get("retestConsistency")
        if rc is not None and rc < 0.8:
            flags.append(f"low retest consistency ({rc}) -- answers to the two hidden repeat questions diverged")
        print(f"  {name}: {'; '.join(flags) if flags else 'no flags'}")
    print(f"\n  Note: none of the {len(pg['names'])} files include per-item BFI-2 rawAnswers (an earlier "
          f"survey export version), so BFI-2 domain/facet scores are the JS-computed values carried "
          f"through as-is.")

    # --- Step 5a: REAL universe, AS-IMPLIED by the workbook's own optimal --
    # portfolio P. Disclosed caveat: P's Sharpe (2.21) is in-sample-optimized
    # (Michaud 1989's "Markowitz enigma"), so the implied market price of risk
    # (lambda_mkt=11.68) is unrealistically high and saturates every
    # respondent's long-only EUT risky-fraction at 100%, regardless of gamma.
    print("\n" + "=" * 78)
    print("STEP 5a: EUT + SP/A-BPT -- AS-IMPLIED from the workbook's optimal portfolio P")
    print(f"({meta['n_assets']} stocks, rf={universe['rf']:.4f}, lambda_mkt={meta['lambda_mkt_implied']:.2f} "
          f"-- see real_asset_universe/meta.json)")
    print("CAVEAT: lambda_mkt this high saturates EUT risky-fraction at 100% for every gamma > ~0.42.")
    print("=" * 78)
    port_rows = []
    for name in pg["names"]:
        params = pooled[name]
        gamma, lam = params["gamma"]["pooled"], params["lam"]["pooled"]
        port_rows.append(_construct_portfolios(name, gamma, lam, universe, {}))
    port_df = pd.DataFrame(port_rows)
    print(port_df.to_string(index=False))
    port_df.to_csv(out_dir / "real_peers_step5a_as_implied.csv", index=False)

    # --- Step 5b: REAL universe, STANDARD lambda (He & Litterman 1999) -----
    # applied to the market-cap-weighted 66-stock portfolio -- avoids the
    # in-sample-optimization circularity of 5a and actually differentiates
    # respondents by their elicited risk aversion, which is the point of Step 5.
    print("\n" + "=" * 78)
    print("STEP 5b: EUT + SP/A-BPT -- STANDARD lambda=2.5 on market-cap-weighted reference")
    print(f"(implied market Sharpe={meta_std['implied_market_sharpe']:.3f} -- see "
          f"real_asset_universe_standard_lambda/meta.json)")
    print("This is the version that should be used/quoted for the deliverable.")
    print("=" * 78)
    from robo_advisory.portfolio.eut import tangency_weights as _tan_w
    w_tan_std = _tan_w(universe_std["mu"], universe_std["sigma"], universe_std["rf"])
    tan_excess_std = float(w_tan_std @ (universe_std["mu"] - universe_std["rf"]))
    tan_var_std = float(w_tan_std @ universe_std["sigma"] @ w_tan_std)

    port_rows_std = []
    for name in pg["names"]:
        params = pooled[name]
        gamma, lam = params["gamma"]["pooled"], params["lam"]["pooled"]
        row = _construct_portfolios(name, gamma, lam, universe_std, {})
        row["EUT_risky_fraction_UNCLIPPED"] = tan_excess_std / (max(gamma, 0.05) * tan_var_std)
        port_rows_std.append(row)
    port_df_std = pd.DataFrame(port_rows_std)
    print(port_df_std.to_string(index=False))
    print("\n  NOTE: EUT_risky_fraction_UNCLIPPED is lambda_mkt/gamma before the long-only [0,1] cap.")
    print(f"  All {len(pg['names'])} peers' elicited gamma is low enough that the *unclipped* preferred risky fraction")
    print("  exceeds 100% (they'd want leverage if allowed) -- so EUT_risky_fraction saturates at 1.0")
    print("  for everyone regardless of how different their gamma actually is. EUT alone does NOT")
    print("  differentiate this peer group under a long-only constraint; the SP/A-BPT safety-capital")
    print("  fraction (which scales with elicited loss aversion, not gamma) is what differentiates them")
    print("  -- itself a finding worth stating explicitly in Step 6 commentary on EUT vs BPT for robo-advisory.")
    port_df_std.to_csv(out_dir / "real_peers_step5b_standard_lambda.csv", index=False)

    # Top holdings under the standard-lambda version (the one worth reading)
    print("\n--- Top-10 EUT risky-sleeve holdings per respondent (Step 5b, standard lambda) ---")
    from robo_advisory.portfolio.eut import eut_allocation
    weights_rows = []
    for name in pg["names"]:
        gamma = max(pooled[name]["gamma"]["pooled"], 0.05)
        eut = eut_allocation(universe_std["mu"], universe_std["sigma"], universe_std["rf"], gamma)
        w = eut["risky_weights"]
        order = np.argsort(-w)[:10]
        print(f"\n{name} (gamma={gamma:.3f}, risky fraction={eut['risky_fraction']:.3f}):")
        for idx in order:
            if w[idx] > 1e-6:
                print(f"    {universe_std['tickers'][idx]:<14} {w[idx]*100:6.2f}%")
                weights_rows.append({"respondent": name, "ticker": universe_std["tickers"][idx],
                                      "weight_within_risky_sleeve": w[idx]})
    pd.DataFrame(weights_rows).to_csv(out_dir / "real_peers_step5b_top_holdings.csv", index=False)

    print(f"\nWrote:\n  {out_dir / 'real_peers_steps2to4and6.csv'}\n"
          f"  {out_dir / 'real_peers_step5a_as_implied.csv'}\n"
          f"  {out_dir / 'real_peers_step5b_standard_lambda.csv'}\n"
          f"  {out_dir / 'real_peers_step5b_top_holdings.csv'}")


if __name__ == "__main__":
    main()
