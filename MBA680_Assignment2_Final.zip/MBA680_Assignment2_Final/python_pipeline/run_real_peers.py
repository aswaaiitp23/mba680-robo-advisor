"""
run_real_peers.py
==================
Runs the 5 confirmed-valid real peer-group respondents through the FULL
pipeline: Steps 2-4 (elicitation pooling, BFI-2 scoring), Step 5 (EUT +
SP/A-BPT portfolio construction against the REAL Markowitz Portfolio
Project asset universe), and Step 6 (rule-based commentary).

Respondent attribution (confirmed by the user; internal file 'name' field
did not always match -- see each file's _attribution_note):
  - Shree Charan  <- attachment.txt / shree-charan-risk-time-results.json
                     (internal name recorded as "Ineni sree charan")
  - Kshitij       <- rajat-risk-time-results.json
                     (internal name recorded as "Rajat" -- misspelling, per
                      user: "Kshitij is misspelled as Rajat")
  - Kartika       <- kratika_soni_assessment.json
                     (internal name recorded as "Kratika Soni")
  - Ayushi        <- ayushi-risk-time-results.json (internal name "Ayushi",
                     no correction needed; also confirmed as a co-author on
                     the Markowitz Portfolio Project report, "Ayushi Mishra")
  - Adwaaiit Pande <- adwaaiit-risk-time-results.json (the user's own
                     response; internal name "Adwaaiit Pande", no correction
                     needed; retestConsistency=1.0)

EXCLUDED per explicit user instruction ("The file is nonsense. Leave it."):
  - sree-charan-risk-time-results.json (the separately-uploaded file, NOT
    the pasted attachment.txt above) -- all 20 adaptive questions were
    answered identically (choseB=false throughout), a degenerate
    non-responsive pattern, and its generalRisk=10 self-report directly
    contradicts the extremely risk-averse-looking posterior it produced.

Asset universe: REAL data, extracted from the group's own delivered
Markowitz Portfolio Project workbook (MBA680_Portfolio_Workbook_Final.xlsx)
-- 66-stock NSE universe, 3-year annualized covariance matrix, rf=6.75%.
The workbook exposes the covariance matrix and the final optimal
(max-Sharpe) portfolio P's weights and summary stats, but NOT a per-asset
expected-return vector directly. Per-asset mu was therefore back-solved via
Black-Litterman-style reverse optimization (implied equilibrium returns):
    lambda_mkt = (E[Rp] - rf) / sigma_p^2
    mu_implied = rf*1 + lambda_mkt * Sigma @ w_P
using the workbook's own reported optimal portfolio P as the reference.
Verified internally consistent: w_P . mu_implied reproduces E[Rp] to 6
decimal places, and w_P' Sigma w_P reproduces sigma_p^2 exactly. See
real_asset_universe/meta.json for the full derivation record. This is a
disclosed modeling step (not raw data), same spirit as this project's other
disclosed approximations (CI-to-variance, hierarchical-pooling floor, etc.)
-- state it plainly wherever these portfolio numbers are used, do not
present mu_implied as if it were given data.
"""
from __future__ import annotations
import json
from pathlib import Path

import numpy as np
import pandas as pd

from robo_advisory.ingest import load_peer_group, pool_group_from_summaries, score_all_bfi2
from robo_advisory.pipeline import (build_commentary, _construct_portfolios, load_real_asset_universe,
                                   universe_layers, POSITION_CAP, SAFETY_FLOOR, SAFETY_ALPHA)
from robo_advisory.portfolio.bpt import safety_capital_fraction_from_lambda

DATA_DIR = Path(__file__).parent / "real_peer_data"
RESPONDENT_FILES = [
    str(DATA_DIR / "shree-charan-risk-time-results.json"),
    str(DATA_DIR / "kshitij-risk-time-results.json"),
    str(DATA_DIR / "kartika-risk-time-results.json"),
    str(DATA_DIR / "ayushi-risk-time-results.json"),
    str(DATA_DIR / "adwaaiit-risk-time-results.json"),
]

UNIVERSE_DIR = Path(__file__).parent / "real_asset_universe"
UNIVERSE_DIR_STD = Path(__file__).parent / "real_asset_universe_standard_lambda"


def main():
    pg = load_peer_group(RESPONDENT_FILES)
    pooled = pool_group_from_summaries(pg["raw"], min_individual_weight=0.30)
    bfi2_all = score_all_bfi2(pg["raw"])

    universe = load_real_asset_universe(
        str(UNIVERSE_DIR / "mu.csv"), str(UNIVERSE_DIR / "covariance.csv"), rf=0.0675
    )
    meta = json.loads((UNIVERSE_DIR / "meta.json").read_text())
    universe_std = load_real_asset_universe(
        str(UNIVERSE_DIR_STD / "mu.csv"), str(UNIVERSE_DIR_STD / "covariance.csv"), rf=0.0675
    )
    meta_std = json.loads((UNIVERSE_DIR_STD / "meta.json").read_text())

    # --- Steps 2-4 + 6 summary --------------------------------------------
    print("=" * 78)
    print("STEPS 2-4 & 6: Elicited & pooled behavioral parameters, personality, commentary")
    print("=" * 78)
    summary_rows = []
    for name in pg["names"]:
        data = pg["raw"][name]
        params = pooled[name]
        bfi2 = bfi2_all[name]
        commentary = build_commentary(name, params["lam"]["pooled"], bfi2["domains"])

        summary_rows.append({
            "respondent": name,
            "generalRisk_0to10": data.get("generalRisk"),
            "generalPatience_0to10": data.get("generalPatience"),
            "grableLytton_total": (data.get("grableLytton") or {}).get("total"),
            "grableLytton_level": (data.get("grableLytton") or {}).get("level"),
            "dospert_investing_mean": (data.get("dospertFinancial") or {}).get("investingMean"),
            "dospert_gambling_mean": (data.get("dospertFinancial") or {}).get("gamblingMean"),
            "gamma_raw": round(params["gamma"]["raw"], 3),
            "gamma_pooled": round(params["gamma"]["pooled"], 3),
            "lambda_raw": round(params["lam"]["raw"], 3),
            "lambda_pooled": round(params["lam"]["pooled"], 3),
            "alpha_w_pooled": round(params["alpha_w"]["pooled"], 3),
            "beta_hyp_pooled": round(params["beta_hyp"]["pooled"], 3),
            "delta_pooled": round(params["delta"]["pooled"], 3),
            "retestConsistency": data.get("retestConsistency"),
            "bfi2_Extraversion": round(bfi2["domains"].get("Extraversion", float("nan")), 2),
            "bfi2_Agreeableness": round(bfi2["domains"].get("Agreeableness", float("nan")), 2),
            "bfi2_Conscientiousness": round(bfi2["domains"].get("Conscientiousness", float("nan")), 2),
            "bfi2_NegativeEmotionality": round(bfi2["domains"].get("Negative Emotionality", float("nan")), 2),
            "bfi2_OpenMindedness": round(bfi2["domains"].get("Open-Mindedness", float("nan")), 2),
            "bfi2_source": bfi2.get("source", "js-computed"),
            "step6_commentary": " | ".join(commentary),
        })

    summary_df = pd.DataFrame(summary_rows)
    pd.set_option("display.width", 220)
    pd.set_option("display.max_columns", 50)
    print(summary_df.to_string(index=False))

    out_dir = Path(__file__).parent / "outputs"
    out_dir.mkdir(exist_ok=True)
    summary_df.to_csv(out_dir / "real_peers_steps2to4and6.csv", index=False)

    # --- Data-quality flags -------------------------------------------------
    print("\n" + "=" * 78)
    print("DATA-QUALITY FLAGS (disclosed limitations)")
    print("=" * 78)
    for name in pg["names"]:
        degenerate = [p for p in ["gamma", "lam", "alpha_w", "beta_hyp", "delta"]
                      if abs(pg["raw"][name]["posterior"][p]["ci90"][1]
                             - pg["raw"][name]["posterior"][p]["ci90"][0]) < 1e-6]
        flags = []
        if degenerate:
            flags.append(f"zero-width 90% CI on {degenerate}")
        rc = pg["raw"][name].get("retestConsistency")
        if rc is not None and rc < 0.8:
            flags.append(f"low retest consistency ({rc}) -- answers to the two hidden repeat questions diverged")
        print(f"  {name}: {'; '.join(flags) if flags else 'no flags'}")
    print(f"\n  Note: none of the {len(pg['names'])} files include per-item BFI-2 rawAnswers (an earlier "
          f"survey export version), so BFI-2 domain/facet scores are the JS-computed values carried "
          f"through as-is.")

    # --- Step 5a: REAL universe, AS-IMPLIED by the workbook's own optimal --
    # portfolio P. Disclosed caveat: P's Sharpe (2.21) is in-sample-optimized
    # (Michaud 1989's "Markowitz enigma"), so the implied market price of risk
    # (lambda_mkt=11.68) is unrealistically high and saturates every
    # respondent's long-only EUT risky-fraction at 100%, regardless of gamma.
    print("\n" + "=" * 78)
    print("STEP 5a: EUT + SP/A-BPT -- AS-IMPLIED from the workbook's optimal portfolio P")
    print(f"({meta['n_assets']} stocks, rf={universe['rf']:.4f}, lambda_mkt={meta['lambda_mkt_implied']:.2f} "
          f"-- see real_asset_universe/meta.json)")
    print("CAVEAT: lambda_mkt this high saturates EUT risky-fraction at 100% for every gamma > ~0.42 (kept for disclosure only).")
    print("=" * 78)
    port_rows = []
    for name in pg["names"]:
        params = pooled[name]
        gamma, lam = params["gamma"]["pooled"], params["lam"]["pooled"]
        port_rows.append(_construct_portfolios(name, gamma, lam, universe, {}))
    port_df = pd.DataFrame(port_rows)
    print(port_df.to_string(index=False))
    port_df.to_csv(out_dir / "real_peers_step5a_as_implied.csv", index=False)

    # --- Step 5b: REAL universe, STANDARD lambda (He & Litterman 1999) -----
    # applied to the market-cap-weighted 66-stock portfolio -- avoids the
    # in-sample-optimization circularity of 5a. Version-2 model: 10% single-
    # stock cap on every equity sleeve; BPT safety account may hold G-Secs and
    # must not lose money in more than 5% of years (Telser 1955).
    print("\n" + "=" * 78)
    print("STEP 5b: EUT + SP/A-BPT -- STANDARD lambda=2.5 on market-cap-weighted reference")
    print(f"(implied market Sharpe={meta_std['implied_market_sharpe']:.3f} -- see "
          f"real_asset_universe_standard_lambda/meta.json)")
    print(f"Model v2: single-stock cap {POSITION_CAP:.0%}; safety account floor {SAFETY_FLOOR:.0%} "
          f"with shortfall probability <= {SAFETY_ALPHA:.0%}")
    print("This is the version that should be used/quoted for the deliverable.")
    print("=" * 78)
    port_rows_std = []
    for name in pg["names"]:
        params = pooled[name]
        gamma, lam = params["gamma"]["pooled"], params["lam"]["pooled"]
        port_rows_std.append(_construct_portfolios(name, gamma, lam, universe_std, {}))
    port_df_std = pd.DataFrame(port_rows_std)
    print(port_df_std.to_string(index=False))
    port_df_std.to_csv(out_dir / "real_peers_step5b_standard_lambda.csv", index=False)

    L = universe_layers(universe_std)
    tick = universe_std["tickers"]
    mu_s, sig_s, rf_s = universe_std["mu"], universe_std["sigma"], universe_std["rf"]
    w_T = L["tangency_weights"]; w_A = L["aspiration_layer"]["weights"]
    print("\n--- Universe-level building blocks (identical for every client) ---")
    print(f"  Capped tangency T : return {L['tangency_return']:.4%}, vol {L['tangency_volatility']:.4%}, "
          f"Sharpe {(L['tangency_return'] - rf_s) / L['tangency_volatility']:.4f}, "
          f"implied lambda {(L['tangency_return'] - rf_s) / L['tangency_volatility'] ** 2:.4f}, "
          f"{int((w_T > 1e-6).sum())} names, max {w_T.max():.2%}")
    print(f"  Safety account    : {L['safety_equity_share']:.2%} in T, {1 - L['safety_equity_share']:.2%} G-Secs; "
          f"return {L['safety_return']:.4%}, vol {L['safety_volatility']:.4%}")
    print(f"  Aspiration A      : H_a = {L['aspiration_threshold']:.4%}; return "
          f"{L['aspiration_layer']['expected_return']:.4%}, vol {L['aspiration_layer']['volatility']:.4%}, "
          f"{int((w_A > 1e-6).sum())} names")

    # Holdings: EUT risky sleeve (= T, same for all) and each client's full BPT book
    hold_rows = []
    for i in np.argsort(-w_T):
        if w_T[i] > 1e-6:
            hold_rows.append({"portfolio": "EUT tangency (all clients)", "ticker": tick[i], "weight": w_T[i]})
    for i in np.argsort(-w_A):
        if w_A[i] > 1e-6:
            hold_rows.append({"portfolio": "BPT aspiration account", "ticker": tick[i], "weight": w_A[i]})
    pd.DataFrame(hold_rows).to_csv(out_dir / "real_peers_step5b_layer_holdings.csv", index=False)

    weights_rows = []
    print("\n--- Top-10 EUT risky-sleeve holdings (same for every respondent) ---")
    for name in pg["names"]:
        for idx in np.argsort(-w_T)[:10]:
            weights_rows.append({"respondent": name, "ticker": tick[idx],
                                  "weight_within_risky_sleeve": w_T[idx]})
    for idx in np.argsort(-w_T)[:10]:
        print(f"    {tick[idx]:<14} {w_T[idx]*100:6.2f}%")
    pd.DataFrame(weights_rows).to_csv(out_dir / "real_peers_step5b_top_holdings.csv", index=False)

    bpt_rows = []
    print("\n--- Top BPT holdings per respondent (fractions of total wealth, G-Secs included) ---")
    for name in pg["names"]:
        lam = pooled[name]["lam"]["pooled"]
        s_ = safety_capital_fraction_from_lambda(lam)
        e_ = L["safety_equity_share"]
        w_c = s_ * e_ * w_T + (1 - s_) * w_A
        items = [("G-SEC", s_ * (1 - e_))] + [(tick[i], w_c[i]) for i in range(len(tick))]
        items.sort(key=lambda kv: -kv[1])
        print(f"  {name}: " + ", ".join(f"{t} {w*100:.2f}%" for t, w in items[:6]))
        for t, w in items[:10]:
            bpt_rows.append({"respondent": name, "ticker": t, "weight_of_total_wealth": w})
    pd.DataFrame(bpt_rows).to_csv(out_dir / "real_peers_step5b_bpt_holdings.csv", index=False)

    # Layers file for the web portal (client-independent; clients only change s and gamma)
    cov_TA = float(w_T @ sig_s @ w_A)
    layers_json = {
        "model": "v2: 10% single-stock cap; BPT safety account = G-Secs + capped tangency (Telser, H_s=0, alpha=5%); "
                 "aspiration = capped Roy portfolio at H_a = 75th percentile of mu",
        "rf": rf_s, "cap": POSITION_CAP, "safety_floor": SAFETY_FLOOR, "safety_alpha": SAFETY_ALPHA,
        "tickers": tick,
        "T": {"weights": [round(float(x), 6) for x in w_T], "ret": L["tangency_return"], "vol": L["tangency_volatility"]},
        "A": {"weights": [round(float(x), 6) for x in w_A], "ret": L["aspiration_layer"]["expected_return"],
              "vol": L["aspiration_layer"]["volatility"], "threshold": L["aspiration_threshold"]},
        "safety_equity_share": L["safety_equity_share"],
        "cov_TA": cov_TA,
    }
    (out_dir / "portfolio_layers_standard_lambda.json").write_text(json.dumps(layers_json, indent=1))

    # Sensitivity of the BPT design choices (disclosed in the report)
    sens = []
    from robo_advisory.portfolio.bpt import bpt_layers, bpt_allocation, prob_below
    for lab, pct_, alpha_ in [("base (75th pct, 5%)", 75, 0.05), ("aspiration at median", 50, 0.05),
                              ("aspiration at 90th pct", 90, 0.05), ("shortfall prob 1%", 75, 0.01),
                              ("shortfall prob 10%", 75, 0.10)]:
        Lx = bpt_layers(mu_s, sig_s, rf_s, float(np.percentile(mu_s, pct_)), cap=POSITION_CAP,
                        safety_floor=SAFETY_FLOOR, safety_alpha=alpha_)
        for lam_lab, lam_ in [("lambda=1.0", 1.0), ("Kshitij lambda=1.6", 1.6)]:
            b = bpt_allocation(mu_s, sig_s, rf_s, SAFETY_FLOOR, Lx["aspiration_threshold"],
                               safety_capital_fraction_from_lambda(lam_), cap=POSITION_CAP, layers=Lx)
            sens.append({"setting": lab, "client": lam_lab, "safety_equity_share": Lx["safety_equity_share"],
                         "gsec_weight": b["gsec_weight"], "return": b["combined_expected_return"],
                         "volatility": b["combined_volatility"],
                         "prob_loss": prob_below(b["combined_expected_return"], b["combined_volatility"])})
    sens_df = pd.DataFrame(sens)
    print("\n--- BPT design sensitivity ---")
    print(sens_df.to_string(index=False))
    sens_df.to_csv(out_dir / "real_peers_step5b_bpt_sensitivity.csv", index=False)

    print(f"\nWrote:\n  {out_dir / 'real_peers_steps2to4and6.csv'}\n"
          f"  {out_dir / 'real_peers_step5a_as_implied.csv'}\n"
          f"  {out_dir / 'real_peers_step5b_standard_lambda.csv'}\n"
          f"  {out_dir / 'real_peers_step5b_top_holdings.csv'}\n"
          f"  {out_dir / 'real_peers_step5b_bpt_holdings.csv'}\n"
          f"  {out_dir / 'real_peers_step5b_layer_holdings.csv'}\n"
          f"  {out_dir / 'real_peers_step5b_bpt_sensitivity.csv'}\n"
          f"  {out_dir / 'portfolio_layers_standard_lambda.json'}")


if __name__ == "__main__":
    main()
