"""
robo_advisory.elicitation.models
=================================
Behavioral primitives used throughout the elicitation engine:

- CRRA / CPT value function          v(x)            (Tversky & Kahneman, 1992)
- Prelec (1998) probability weighting w(p)
- Quasi-hyperbolic discounting        D(t)            (Laibson beta-delta model)
- Fechner/Luce stochastic choice rule P(choose A)

Parameter vector theta = (gamma, lam, alpha_w, beta_hyp, delta) where:
    gamma     : outcome curvature (CRRA-style exponent, applied to both gains/losses
                for tractability -- see docstring in ChoiceModel)
    lam       : loss aversion coefficient (lambda >= 1)
    alpha_w   : Prelec probability-weighting parameter (alpha_w in (0, 2), 1 = no distortion)
    beta_hyp  : quasi-hyperbolic present-bias parameter (beta_hyp in (0, 1], 1 = no present bias)
    delta     : per-30-day exponential discount factor (delta in (0, 1])

This is a deliberately compact 5-parameter model (rather than TK92's full 6-parameter
CPT + separate gain/loss weighting exponents) so that the adaptive engine's parameter
grid stays computationally tractable for a course-project-scale respondent pool.
The literature benchmarks it is checked against (Tversky & Kahneman, 1992;
Booij, van Praag & van de Kuilen, 2010) are documented in the accompanying report.
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass

# ---------------------------------------------------------------------------
# Parameter grid definition
# ---------------------------------------------------------------------------

PARAM_NAMES = ("gamma", "lam", "alpha_w", "beta_hyp", "delta")

# Grid resolution per dimension. Kept modest so the full candidate-pool x
# grid likelihood matrix (precomputed once in engine.py) stays fast: with 7
# points/dim, 7^5 = 16,807 grid nodes -- comfortably fast in vectorized numpy
# for a live elicitation session.
GRID_SPECS = {
    "gamma":    (-0.5, 3.0, 7),   # risk-loving .. extremely risk-averse
    "lam":      (1.0, 4.0, 7),    # no loss aversion .. strong loss aversion
    "alpha_w":  (0.4, 1.4, 7),    # strong overweighting .. mild underweighting of low p
    "beta_hyp": (0.5, 1.0, 7),    # strong present bias .. none
    "delta":    (0.90, 1.0, 7),   # ~10.5%/month .. 0%/month pure discounting
}


def build_grid() -> dict:
    """Return {name: 1-D array of grid values} and the full meshgrid of thetas."""
    axes = {k: np.linspace(lo, hi, n) for k, (lo, hi, n) in GRID_SPECS.items()}
    mesh = np.meshgrid(*[axes[k] for k in PARAM_NAMES], indexing="ij")
    thetas = np.stack([m.ravel() for m in mesh], axis=1)  # (N, 5)
    return axes, thetas


# ---------------------------------------------------------------------------
# Behavioral functions
# ---------------------------------------------------------------------------

def value_fn(x: np.ndarray, gamma: np.ndarray, lam: np.ndarray) -> np.ndarray:
    """
    CPT-style value function, vectorized over (outcome, parameter-grid) pairs.
    x, gamma, lam are broadcastable arrays.
    v(x) =  x^(1-gamma)                for x >= 0   (gains; power form, curvature via gamma)
    v(x) = -lam * (-x)^(1-gamma)        for x < 0    (losses; loss aversion via lam)
    Uses 1-gamma as the exponent so gamma=0 is linear (risk-neutral) and gamma>0 is concave.
    """
    x = np.asarray(x, dtype=float)
    exponent = np.clip(1.0 - gamma, 0.05, None)  # keep exponent away from 0 for stability
    gains = np.where(x >= 0, np.power(np.abs(x), exponent), 0.0)
    losses = np.where(x < 0, -lam * np.power(np.abs(x), exponent), 0.0)
    return gains + losses


def prelec_weight(p: np.ndarray, alpha_w: np.ndarray) -> np.ndarray:
    """Prelec (1998) one-parameter probability weighting function.
    w(p) = exp(-(-ln p)^alpha_w), defined on p in (0, 1]; w(0) := 0.
    """
    p = np.clip(np.asarray(p, dtype=float), 1e-9, 1.0)
    return np.exp(-np.power(-np.log(p), alpha_w))


def quasi_hyperbolic_factor(t_days: float, beta_hyp: np.ndarray, delta: np.ndarray) -> np.ndarray:
    """Discount factor for a payment t_days in the future, beta-delta model.
    D(0) = 1 exactly (no beta penalty for "today").
    D(t) = beta_hyp * delta^(t/30) for t > 0.
    """
    periods = t_days / 30.0
    if t_days <= 0:
        return np.ones_like(beta_hyp)
    return beta_hyp * np.power(delta, periods)


@dataclass
class RiskPrompt:
    """A binary choice between a lottery and a sure amount (or two lotteries)."""
    kind: str  # "risk"
    p: float          # probability of the high outcome under Option B (lottery)
    high: float
    low: float
    sure: float        # Option A: certain amount

    def utilities(self, thetas: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        gamma, lam, alpha_w = thetas[:, 0], thetas[:, 1], thetas[:, 2]
        w = prelec_weight(np.array(self.p), alpha_w)
        u_b = w * value_fn(np.array(self.high), gamma, lam) + \
              (1 - w) * value_fn(np.array(self.low), gamma, lam)
        u_a = value_fn(np.array(self.sure), gamma, lam)
        return u_a, u_b


@dataclass
class TimePrompt:
    """A binary choice between a smaller-sooner and larger-later payment."""
    kind: str  # "time"
    amount_now: float
    t_now_days: float
    amount_later: float
    t_later_days: float

    def utilities(self, thetas: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        gamma, lam, beta_hyp, delta = thetas[:, 0], thetas[:, 1], thetas[:, 3], thetas[:, 4]
        d_now = quasi_hyperbolic_factor(self.t_now_days, beta_hyp, delta)
        d_later = quasi_hyperbolic_factor(self.t_later_days, beta_hyp, delta)
        u_a = d_now * value_fn(np.array(self.amount_now), gamma, lam)
        u_b = d_later * value_fn(np.array(self.amount_later), gamma, lam)
        return u_a, u_b


def choice_prob_b(u_a: np.ndarray, u_b: np.ndarray, noise_scale: float = 0.35) -> np.ndarray:
    """Fechner/Luce stochastic choice rule: P(choose B) = logistic((u_b - u_a) / noise_scale).
    noise_scale controls response-error magnitude (Wilcox-style contextual noise could replace
    this with a per-question-set normalization; kept fixed here for tractability).
    """
    z = (u_b - u_a) / noise_scale
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))
