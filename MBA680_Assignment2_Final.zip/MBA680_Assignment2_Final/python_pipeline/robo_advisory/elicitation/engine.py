"""
robo_advisory.elicitation.engine
=================================
Adaptive Bayesian elicitation engine, implementing the design logic proposed
in the project report (Section 3.6), adapted from the sequential-information-
maximization approach of Toubia, Johnson, Evgeniou & Delquié (2013,
Management Science) -- "Dynamic Experiments for Estimating Preferences: An
Adaptive Method of Eliciting Time and Risk Parameters".

At each step:
    1. Maintain a discrete posterior over the joint parameter grid (models.py).
    2. Score every candidate question in the pool by its EXPECTED reduction in
       posterior entropy (equivalently, expected KL-divergence of the
       post-answer posterior from the current one), averaged over the two
       possible answers weighted by their current predicted probability.
    3. Present the highest-scoring question; update the posterior via Bayes'
       rule once an answer is observed.
    4. Two previously-asked questions are re-presented later (reliability
       check, per Section 3.5 of the report).

This is a from-scratch re-implementation of the *logic* described in Toubia
et al. (2013), not a copy of their proprietary DEEP software -- see the
report's Round-3 self-review (R3.1) for why that distinction matters.
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Optional

from .models import (
    PARAM_NAMES, build_grid, RiskPrompt, TimePrompt, choice_prob_b,
)

AXES, THETAS = build_grid()
N_GRID = THETAS.shape[0]


def _candidate_risk_prompts() -> list[RiskPrompt]:
    """A pool of candidate risk questions spanning probabilities and stake ratios.
    The engine picks from this pool rather than free-form generation, which keeps
    the information-gain search fast and the questions interpretable/administrable.
    """
    prompts = []
    for p in (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9):
        for high, low, sure_frac in (
            (2000, -1600, 0.5), (2000, -400, 0.4), (5000, 0, 0.45),
            (1000, -1000, 0.5), (3000, -600, 0.35), (800, -3200, 0.6),
        ):
            sure = sure_frac * high + (1 - sure_frac) * low
            prompts.append(RiskPrompt("risk", p=p, high=high, low=low, sure=round(sure, 1)))
    return prompts


def _candidate_time_prompts() -> list[TimePrompt]:
    prompts = []
    for t_now, t_later in ((0, 30), (0, 90), (360, 390), (0, 180)):
        for x_pct in (0.5, 1, 2, 3, 5, 7, 10, 15, 20, 30):
            amt_now = 1000.0
            amt_later = 1000.0 * (1 + x_pct / 100.0)
            prompts.append(TimePrompt("time", amount_now=amt_now, t_now_days=t_now,
                                       amount_later=amt_later, t_later_days=t_later))
    return prompts


CANDIDATE_POOL = _candidate_risk_prompts() + _candidate_time_prompts()

# --- Precompute P(choose B | theta) for the ENTIRE candidate pool against the
# ENTIRE parameter grid, ONCE, at import time. This is the expensive step
# (n_candidates x N_GRID), but it is independent of any respondent's posterior
# or answers, so computing it once and reusing it for every respondent and
# every question turns the per-step "which question next?" search from a
# Python loop of per-candidate dataclass calls into a single vectorized numpy
# operation -- this is what makes the adaptive engine fast enough to run
# live rather than timing out on a brute-force re-derivation every step.
def _precompute_pool_likelihood(pool: list) -> np.ndarray:
    rows = []
    for prompt in pool:
        u_a, u_b = prompt.utilities(THETAS)
        rows.append(choice_prob_b(u_a, u_b))
    return np.stack(rows, axis=0)  # (n_candidates, N_GRID)


P_B_POOL = _precompute_pool_likelihood(CANDIDATE_POOL)  # (n_candidates, N_GRID)


@dataclass
class RespondentSession:
    """One respondent's live adaptive elicitation session."""
    respondent_id: str
    log_posterior: np.ndarray = field(default_factory=lambda: np.zeros(N_GRID))
    asked: list = field(default_factory=list)      # list of (prompt, answer)
    n_questions: int = 0
    retest_indices: list = field(default_factory=list)  # indices into `asked` re-presented later

    def posterior(self) -> np.ndarray:
        lp = self.log_posterior - self.log_posterior.max()
        p = np.exp(lp)
        return p / p.sum()

    # -- vectorized question selection --------------------------------------
    def select_next_question_vectorized(self, pool_idx_available: np.ndarray):
        """Vectorized expected-information-gain search over all currently
        available (not-yet-asked) candidates in one shot, using the module-
        level precomputed P_B_POOL likelihood matrix.
        """
        post = self.posterior()                                   # (N_GRID,)
        P_B = P_B_POOL[pool_idx_available]                         # (n_avail, N_GRID)
        p_b_marg = P_B @ post                                      # (n_avail,)
        p_b_marg = np.clip(p_b_marg, 1e-6, 1 - 1e-6)

        h_before = float(-np.sum(post[post > 1e-12] * np.log(post[post > 1e-12])))

        def entropy_after(lik: np.ndarray) -> np.ndarray:
            # lik: (n_avail, N_GRID) likelihood of the observed answer under each grid node
            new_log_post = self.log_posterior[None, :] + np.log(np.clip(lik, 1e-9, None))
            new_log_post -= new_log_post.max(axis=1, keepdims=True)
            new_post = np.exp(new_log_post)
            new_post /= new_post.sum(axis=1, keepdims=True)
            safe = np.where(new_post > 1e-12, new_post, 1.0)  # avoid log(0); those terms -> 0 anyway
            return -np.sum(new_post * np.log(safe), axis=1)

        h_after_b = entropy_after(P_B)
        h_after_a = entropy_after(1 - P_B)
        h_after = p_b_marg * h_after_b + (1 - p_b_marg) * h_after_a
        gains = h_before - h_after                                 # (n_avail,)
        best_local = int(np.argmax(gains))
        return pool_idx_available[best_local], float(gains[best_local])

    def update_by_index(self, pool_idx: int, chose_b: bool):
        p_b_grid = P_B_POOL[pool_idx]
        lik = p_b_grid if chose_b else (1 - p_b_grid)
        self.log_posterior = self.log_posterior + np.log(np.clip(lik, 1e-9, None))
        self.asked.append((pool_idx, chose_b))
        self.n_questions += 1

    # -- summary --------------------------------------------------------
    def posterior_summary(self) -> dict:
        post = self.posterior()
        out = {}
        for i, name in enumerate(PARAM_NAMES):
            vals = THETAS[:, i]
            mean = float(np.sum(post * vals))
            order = np.argsort(vals)
            cum = np.cumsum(post[order])
            cum /= cum[-1]
            lo = float(vals[order][np.searchsorted(cum, 0.05)])
            hi = float(vals[order][np.searchsorted(cum, 0.95)])
            out[name] = {"mean": mean, "ci90": (lo, hi)}
        return out


def run_adaptive_session(respondent_id: str, true_theta: Optional[np.ndarray],
                          n_questions: int = 18, n_retests: int = 2,
                          rng: Optional[np.random.Generator] = None) -> RespondentSession:
    """
    Run one respondent through the adaptive engine.

    If `true_theta` is given (5-vector), answers are SIMULATED from the same
    stochastic-choice model using that respondent's true parameters -- this is
    how the pipeline is validated end-to-end before real peer data exists. In
    production use, the answer would instead come from the live respondent's
    actual click on the presented question (see CANDIDATE_POOL[idx] for the
    human-readable prompt to display).
    """
    rng = rng or np.random.default_rng(0)
    session = RespondentSession(respondent_id=respondent_id)
    n_pool = len(CANDIDATE_POOL)
    available = np.arange(n_pool)

    for _ in range(n_questions):
        idx, gain = session.select_next_question_vectorized(available)
        if true_theta is None:
            raise ValueError("Simulation mode requires true_theta; for live respondents, "
                              "display CANDIDATE_POOL[idx] and call update_by_index(idx, answer).")
        prompt = CANDIDATE_POOL[idx]
        u_a, u_b = prompt.utilities(true_theta.reshape(1, -1))
        prob_b = float(choice_prob_b(u_a, u_b)[0])
        chose_b = bool(rng.random() < prob_b)
        session.update_by_index(idx, chose_b)
        available = available[available != idx]  # don't re-select the same question twice

    # reliability retest: re-present 2 earlier questions, unannounced
    asked_indices = [i for i, _ in session.asked]
    retest_positions = rng.choice(len(asked_indices), size=min(n_retests, len(asked_indices)),
                                   replace=False)
    for pos in retest_positions:
        idx = asked_indices[int(pos)]
        prompt = CANDIDATE_POOL[idx]
        u_a, u_b = prompt.utilities(true_theta.reshape(1, -1))
        prob_b = float(choice_prob_b(u_a, u_b)[0])
        chose_b = bool(rng.random() < prob_b)
        session.update_by_index(idx, chose_b)
        session.retest_indices.append(len(session.asked) - 1)

    return session


def retest_consistency(session: RespondentSession) -> float:
    """Fraction of retest questions answered the same way both times (reliability proxy)."""
    if not session.retest_indices:
        return float("nan")
    matches = 0
    for idx in session.retest_indices:
        pool_idx, second_answer = session.asked[idx]
        for j in range(idx):
            pool_idx2, first_answer = session.asked[j]
            if pool_idx2 == pool_idx:
                matches += int(first_answer == second_answer)
                break
    return matches / len(session.retest_indices)
