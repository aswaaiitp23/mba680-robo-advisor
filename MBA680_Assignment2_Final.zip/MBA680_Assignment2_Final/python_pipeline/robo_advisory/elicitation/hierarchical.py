"""
robo_advisory.elicitation.hierarchical
=======================================
Small-N fix (Section 3.4, R2.2 / Response-Revision-2 of the report): rather
than trust each respondent's independently-fit posterior at face value --
which is poorly identified for corner-solution respondents on ~20 questions --
this module implements empirical-Bayes partial pooling across the peer group.

Method (Efron-Morris-style shrinkage on the grid posterior means):
    1. Fit each respondent's posterior independently (engine.py).
    2. Compute the population mean and between-respondent variance for each
       parameter from the individual posterior means.
    3. Shrink each individual posterior mean toward the population mean by a
       factor proportional to that respondent's own posterior variance
       relative to the between-respondent variance -- noisier (flatter)
       individual posteriors get pulled harder toward the group.
"""
from __future__ import annotations
import numpy as np
from .models import PARAM_NAMES
from .engine import THETAS


def _param_moments(session) -> dict:
    post = session.posterior()
    out = {}
    for i, name in enumerate(PARAM_NAMES):
        vals = THETAS[:, i]
        mean = float(np.sum(post * vals))
        var = float(np.sum(post * (vals - mean) ** 2))
        out[name] = (mean, max(var, 1e-6))
    return out


def pool_group(sessions: list, min_individual_weight: float = 0.30) -> dict:
    """
    sessions: list of RespondentSession (post elicitation).

    `min_individual_weight` floors the empirical-Bayes shrinkage weight so
    that individual signal is never fully erased even when within-respondent
    posterior variance is large relative to the peer group's between-
    respondent variance -- exactly the failure mode a small peer group
    (n=4-6) with a modest question budget is prone to. Without this floor, a
    noisy but genuinely heterogeneous peer group can get shrunk to
    near-identical pooled estimates, which defeats the purpose of eliciting
    individual preferences in the first place. The floor is a standard,
    disclosed adjustment to classical Efron-Morris shrinkage, not a change to
    the underlying Bayesian logic; `raw` (unshrunk) estimates are always
    returned alongside `pooled` ones so this choice is auditable.

    Returns {respondent_id: {param: {"raw": mean, "pooled": shrunk_mean,
                                      "within_var": ..., "shrinkage_weight": w}}}
    """
    moments = {s.respondent_id: _param_moments(s) for s in sessions}
    result = {rid: {} for rid in moments}

    for name in PARAM_NAMES:
        means = np.array([moments[rid][name][0] for rid in moments])
        within_vars = np.array([moments[rid][name][1] for rid in moments])
        pop_mean = float(np.mean(means))
        between_var = float(np.var(means, ddof=1)) if len(means) > 1 else 0.0

        for rid, m, wv in zip(moments.keys(), means, within_vars):
            if between_var <= 1e-9:
                w = min_individual_weight
            else:
                w = max(between_var / (between_var + wv), min_individual_weight)
            pooled = w * m + (1 - w) * pop_mean
            result[rid][name] = {
                "raw": m, "pooled": pooled, "within_var": wv,
                "shrinkage_weight": w, "group_mean": pop_mean,
            }
    return result
