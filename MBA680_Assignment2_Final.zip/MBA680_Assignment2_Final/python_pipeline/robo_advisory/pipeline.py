"""
robo_advisory.pipeline
=======================
End-to-end orchestration, Steps 2-6 of the project brief:

  Step 2/4  ->  elicitation.engine.run_adaptive_session()      (per respondent, SIMULATED path only --
                                                                  real respondents run this client-side, in the
                                                                  survey's own JS port of this same engine)
             -> elicitation.hierarchical.pool_group()          (simulated path)
             -> ingest.pool_group_from_summaries()              (real-data path)
  Step 3    ->  personality.bfi2_scoring.score_bfi2()          (both paths)
  Step 5    ->  portfolio.eut.eut_allocation()
             -> portfolio.bpt.bpt_allocation()
  Step 6    ->  build_commentary()                              (rule-based, cites report Section 7)

Two entry points:
  run_full_pipeline(...)                 - SIMULATED peer group + SIMULATED asset universe.
                                            Use to validate the pipeline itself (report Section 9).
  run_full_pipeline_from_real_data(...)  - REAL respondent JSON exports from the live survey +
                                            a REAL asset universe (mu, sigma, rf). Use once both
                                            are actually in hand (report Section 8's remaining steps).

Both funnel into `_construct_portfolios`, so results from the two paths are
directly comparable -- the only thing that differs is where gamma/lambda/etc.
and the asset universe come from.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

from .elicitation.engine import run_adaptive_session, retest_consistency
from .elicitation.hierarchical import pool_group
from .personality.bfi2_scoring import score_bfi2, negative_emotionality_flag
from .portfolio.eut import eut_allocation
from .portfolio.bpt import bpt_allocation, safety_capital_fraction_from_lambda


# ---------------------------------------------------------------------------
# Synthetic inputs (stand-ins until real data arrives -- report Section 8)
# ---------------------------------------------------------------------------

def simulate_peer_group(n_people: int = 5, n_questions: int = 18,
                         seed: int = 42) -> dict:
    """Simulate a heterogeneous peer group's TRUE preference parameters and
    their adaptive-elicitation responses, plus a synthetic BFI-2 profile per
    person. Used only to exercise the pipeline end-to-end; real administration
    replaces every part of this function (see run_full_pipeline_from_real_data).
    """
    rng = np.random.default_rng(seed)
    names = [f"Peer_{i+1}" for i in range(n_people)]
    true_thetas = {
        n: np.array([
            rng.uniform(0.2, 2.5),   # gamma
            rng.uniform(1.2, 3.5),   # lam
            rng.uniform(0.6, 1.2),   # alpha_w
            rng.uniform(0.6, 1.0),   # beta_hyp
            rng.uniform(0.93, 1.0),  # delta
        ]) for n in names
    }
    sessions = {
        n: run_adaptive_session(n, true_thetas[n], n_questions=n_questions,
                                 rng=np.random.default_rng(seed + i))
        for i, n in enumerate(names)
    }
    # synthetic BFI-2 raw responses (1-5, 0-indexed to match BFI2_ITEMS),
    # correlated loosely with true gamma/lam so the demo's "consistency
    # check" (Section 7) has something non-trivial to flag. Indices 36-47
    # are the Negative Emotionality domain's 12 items in BFI2_ITEMS.
    bfi2_raw = {}
    for n in names:
        gamma, lam = true_thetas[n][0], true_thetas[n][1]
        base = rng.integers(2, 5, size=60).astype(float)
        neg_emotionality_bias = (lam - 1.0) / 3.0 * 1.5  # higher lambda -> higher NE items
        base[36:48] = np.clip(base[36:48] + neg_emotionality_bias + rng.normal(0, 0.5, 12), 1, 5)
        bfi2_raw[n] = {i: int(round(v)) for i, v in enumerate(base)}

    return {"names": names, "true_thetas": true_thetas, "sessions": sessions, "bfi2_raw": bfi2_raw}


def synthetic_asset_universe(n_assets: int = 10, seed: int = 7) -> dict:
    """Placeholder for the Markowitz Portfolio Project's real mu/Sigma/rf
    (report Section 6, 'problem statement 1'). Generates a plausible
    annualized mu/Sigma for a small equity universe purely for demonstration.
    """
    rng = np.random.default_rng(seed)
    tickers = [f"STK{i+1:02d}" for i in range(n_assets)]
    mu = rng.uniform(0.08, 0.22, n_assets)          # annualized expected return
    vol = rng.uniform(0.18, 0.45, n_assets)          # annualized volatility
    corr = np.full((n_assets, n_assets), 0.30)
    np.fill_diagonal(corr, 1.0)
    noise = rng.normal(0, 0.05, (n_assets, n_assets))
    corr = np.clip((corr + (noise + noise.T) / 2), -0.95, 0.95)
    np.fill_diagonal(corr, 1.0)
    eigvals, eigvecs = np.linalg.eigh(corr)
    eigvals = np.clip(eigvals, 1e-4, None)
    corr = eigvecs @ np.diag(eigvals) @ eigvecs.T
    d = np.sqrt(np.diag(corr))
    corr = corr / np.outer(d, d)
    sigma = np.outer(vol, vol) * corr
    rf = 0.065  # illustrative INR risk-free proxy (91-day T-bill order of magnitude)
    return {"tickers": tickers, "mu": mu, "sigma": sigma, "rf": rf}


def load_real_asset_universe(csv_mu_path: str, csv_cov_path: str, rf: float) -> dict:
    """
    Loader for the Markowitz Portfolio Project's real output, once received.
    Expects two CSVs:
      csv_mu_path:  columns [ticker, expected_return]  (annualized)
      csv_cov_path: a square covariance matrix, tickers as both the header
                     row and the first column (annualized)
    Adjust this function, not the rest of the pipeline, if the Markowitz
    project's actual export format differs (e.g. an Excel workbook instead
    of CSV) -- everything downstream only needs the returned dict shape.
    """
    mu_df = pd.read_csv(csv_mu_path)
    cov_df = pd.read_csv(csv_cov_path, index_col=0)
    tickers = mu_df["ticker"].tolist()
    if list(cov_df.index) != tickers or list(cov_df.columns) != tickers:
        raise ValueError("Ticker order/membership mismatch between the expected-return file "
                          "and the covariance matrix file -- align them before loading.")
    return {
        "tickers": tickers,
        "mu": mu_df["expected_return"].to_numpy(dtype=float),
        "sigma": cov_df.to_numpy(dtype=float),
        "rf": float(rf),
    }


# ---------------------------------------------------------------------------
# Step 6: rule-based commentary (report Section 7)
# ---------------------------------------------------------------------------

def build_commentary(name: str, lam_pooled: float, domain_scores: dict) -> list[str]:
    notes = []
    ne = domain_scores.get("Negative Emotionality", float("nan"))
    if negative_emotionality_flag(domain_scores) and lam_pooled < 1.8:
        notes.append(
            f"{name}: Negative Emotionality is elevated ({ne:.2f}/5) but pooled loss aversion "
            f"is comparatively low (lambda={lam_pooled:.2f}). Per report Section 7, this is a flag "
            f"to re-examine the preference elicitation rather than silently trust either number."
        )
    elif negative_emotionality_flag(domain_scores):
        notes.append(
            f"{name}: Negative Emotionality is elevated ({ne:.2f}/5), consistent with the "
            f"elevated pooled loss aversion (lambda={lam_pooled:.2f}). Recommend more reassurance "
            f"framing / drawdown communication for this respondent's safety-layer account."
        )
    else:
        notes.append(f"{name}: no BFI-2 / structural-parameter inconsistency flagged.")
    return notes


# ---------------------------------------------------------------------------
# Shared portfolio construction (report Section 6) -- used by BOTH entry points
# ---------------------------------------------------------------------------

def _construct_portfolios(name: str, gamma: float, lam: float,
                           universe: dict, extra: dict) -> dict:
    gamma = max(gamma, 0.05)
    eut = eut_allocation(universe["mu"], universe["sigma"], universe["rf"], gamma)

    safety_frac = safety_capital_fraction_from_lambda(lam)
    bpt = bpt_allocation(
        universe["mu"], universe["sigma"], universe["rf"],
        safety_threshold=universe["rf"],
        aspiration_threshold=float(np.percentile(universe["mu"], 75)),
        safety_capital_frac=safety_frac, loss_aversion=lam,
    )
    row = {
        "respondent": name,
        "gamma_pooled": gamma, "lambda_pooled": lam,
        "EUT_risky_fraction": eut["risky_fraction"],
        "EUT_expected_return": eut["expected_return"],
        "EUT_volatility": eut["volatility"],
        "BPT_safety_capital_frac": safety_frac,
        "BPT_combined_return": bpt["combined_expected_return"],
        "BPT_combined_volatility": bpt["combined_volatility"],
    }
    row.update(extra)
    return row


# ---------------------------------------------------------------------------
# Entry point 1: fully synthetic (pipeline self-validation, report Section 9)
# ---------------------------------------------------------------------------

def run_full_pipeline(n_people: int = 5, n_assets: int = 10, seed: int = 42):
    peer = simulate_peer_group(n_people=n_people, seed=seed)
    universe = synthetic_asset_universe(n_assets=n_assets)
    pooled = pool_group(list(peer["sessions"].values()))

    rows = []
    for name in peer["names"]:
        session = peer["sessions"][name]
        params = pooled[name]
        gamma, lam = params["gamma"]["pooled"], params["lam"]["pooled"]
        bfi2 = score_bfi2(peer["bfi2_raw"][name])
        commentary = build_commentary(name, lam, bfi2["domains"])

        extra = {
            "gamma_raw": params["gamma"]["raw"], "lambda_raw": params["lam"]["raw"],
            "beta_present_bias": params["beta_hyp"]["pooled"], "delta_discount": params["delta"]["pooled"],
            "retest_consistency": retest_consistency(session),
            "NegativeEmotionality": bfi2["domains"]["Negative Emotionality"],
            "commentary": " | ".join(commentary),
        }
        rows.append(_construct_portfolios(name, gamma, lam, universe, extra))

    return pd.DataFrame(rows), universe, peer


# ---------------------------------------------------------------------------
# Entry point 2: real respondent data + real asset universe
# ---------------------------------------------------------------------------

def run_full_pipeline_from_real_data(respondent_json_paths: list[str], universe: dict) -> pd.DataFrame:
    """
    respondent_json_paths: list of file paths to the JSON each peer downloaded
        from the survey's "done" screen (schemaVersion 3).
    universe: {"tickers", "mu", "sigma", "rf"} -- e.g. from load_real_asset_universe(),
        or the synthetic one if you want a dry run against real preferences but a
        placeholder universe.

    Returns the same DataFrame shape as run_full_pipeline(), so downstream
    code (reporting, plotting) doesn't need to know which path produced it.
    """
    from .ingest import load_peer_group, pool_group_from_summaries, score_all_bfi2

    pg = load_peer_group(respondent_json_paths)
    pooled = pool_group_from_summaries(pg["raw"])
    bfi2_all = score_all_bfi2(pg["raw"])

    rows = []
    for name in pg["names"]:
        data = pg["raw"][name]
        params = pooled[name]
        gamma, lam = params["gamma"]["pooled"], params["lam"]["pooled"]
        bfi2 = bfi2_all[name]
        commentary = build_commentary(name, lam, bfi2["domains"])

        extra = {
            "gamma_raw": params["gamma"]["raw"], "lambda_raw": params["lam"]["raw"],
            "beta_present_bias": params["beta_hyp"]["pooled"], "delta_discount": params["delta"]["pooled"],
            "retest_consistency": data.get("retestConsistency"),
            "generalRisk": data.get("generalRisk"), "generalPatience": data.get("generalPatience"),
            "grableLyttonTotal": (data.get("grableLytton") or {}).get("total"),
            "grableLyttonLevel": (data.get("grableLytton") or {}).get("level"),
            "dospertInvesting": (data.get("dospertFinancial") or {}).get("investingMean"),
            "dospertGambling": (data.get("dospertFinancial") or {}).get("gamblingMean"),
            "NegativeEmotionality": bfi2["domains"].get("Negative Emotionality"),
            "commentary": " | ".join(commentary),
        }
        rows.append(_construct_portfolios(name, gamma, lam, universe, extra))

    return pd.DataFrame(rows)
