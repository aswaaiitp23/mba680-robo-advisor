"""
robo_advisory.personality.bfi2_scoring
=======================================
Scoring engine for the BFI-2 (Soto & John, 2017), 60 items -> 5 domains x
3 facets each. BFI2_ITEMS below is the SAME item set embedded in the live
survey (see the project's web survey, bfi2_data.js) -- domain/facet
assignment sourced from Table 6 of Soto & John (2017), reverse-keying
cross-checked against the paper's published scoring-key fragments for 13
of 15 facets, with the remaining 2 (Intellectual Curiosity, Creative
Imagination) inferred from the stated 2-true/2-reverse balance rule the
authors applied to every facet. Structurally validated: 60 items, 12 per
domain, exactly 2 true-keyed + 2 reverse-keyed per facet (see tests).

BFI-2 items copyright 2015 by Oliver P. John and Christopher J. Soto;
reproduced for non-commercial academic use per the authors' stated policy
(see project report, Section 4).

Input format
------------
responses: dict[int, int]   # item INDEX (0-59, matching BFI2_ITEMS order)
                             # -> Likert response (1-5)
This matches the key format the live survey stores its answers under
(state.bfi2Answers, keyed by index into the same 60-item array), so a
real respondent's exported JSON can be scored by passing its
`bfi2` field's raw answers straight through -- see ingest.py.
"""
from __future__ import annotations
import numpy as np

BFI2_ITEMS = [
    {"text": 'Is outgoing, sociable', "domain": 'Extraversion', "facet": 'Sociability', "reverse": False},
    {"text": 'Tends to be quiet', "domain": 'Extraversion', "facet": 'Sociability', "reverse": True},
    {"text": 'Is sometimes shy, introverted', "domain": 'Extraversion', "facet": 'Sociability', "reverse": True},
    {"text": 'Is talkative', "domain": 'Extraversion', "facet": 'Sociability', "reverse": False},
    {"text": 'Has an assertive personality', "domain": 'Extraversion', "facet": 'Assertiveness', "reverse": False},
    {"text": 'Is dominant, acts as a leader', "domain": 'Extraversion', "facet": 'Assertiveness', "reverse": False},
    {"text": 'Prefers to have others take charge', "domain": 'Extraversion', "facet": 'Assertiveness', "reverse": True},
    {"text": 'Finds it hard to influence people', "domain": 'Extraversion', "facet": 'Assertiveness', "reverse": True},
    {"text": 'Is full of energy', "domain": 'Extraversion', "facet": 'Energy Level', "reverse": False},
    {"text": 'Shows a lot of enthusiasm', "domain": 'Extraversion', "facet": 'Energy Level', "reverse": False},
    {"text": 'Rarely feels excited or eager', "domain": 'Extraversion', "facet": 'Energy Level', "reverse": True},
    {"text": 'Is less active than other people', "domain": 'Extraversion', "facet": 'Energy Level', "reverse": True},
    {"text": 'Is compassionate, has a soft heart', "domain": 'Agreeableness', "facet": 'Compassion', "reverse": False},
    {"text": 'Is helpful and unselfish with others', "domain": 'Agreeableness', "facet": 'Compassion', "reverse": False},
    {"text": 'Can be cold and uncaring', "domain": 'Agreeableness', "facet": 'Compassion', "reverse": True},
    {"text": 'Feels little sympathy for others', "domain": 'Agreeableness', "facet": 'Compassion', "reverse": True},
    {"text": 'Is respectful, treats others with respect', "domain": 'Agreeableness', "facet": 'Respectfulness', "reverse": False},
    {"text": 'Is polite, courteous to others', "domain": 'Agreeableness', "facet": 'Respectfulness', "reverse": False},
    {"text": 'Is sometimes rude to others', "domain": 'Agreeableness', "facet": 'Respectfulness', "reverse": True},
    {"text": 'Starts arguments with others', "domain": 'Agreeableness', "facet": 'Respectfulness', "reverse": True},
    {"text": 'Assumes the best about people', "domain": 'Agreeableness', "facet": 'Trust', "reverse": False},
    {"text": 'Has a forgiving nature', "domain": 'Agreeableness', "facet": 'Trust', "reverse": False},
    {"text": 'Tends to find fault with others', "domain": 'Agreeableness', "facet": 'Trust', "reverse": True},
    {"text": "Is suspicious of others' intentions", "domain": 'Agreeableness', "facet": 'Trust', "reverse": True},
    {"text": 'Is systematic, likes to keep things in order', "domain": 'Conscientiousness', "facet": 'Organization', "reverse": False},
    {"text": 'Keeps things neat and tidy', "domain": 'Conscientiousness', "facet": 'Organization', "reverse": False},
    {"text": 'Tends to be disorganized', "domain": 'Conscientiousness', "facet": 'Organization', "reverse": True},
    {"text": "Leaves a mess, doesn't clean up", "domain": 'Conscientiousness', "facet": 'Organization', "reverse": True},
    {"text": 'Is efficient, gets things done', "domain": 'Conscientiousness', "facet": 'Productiveness', "reverse": False},
    {"text": 'Is persistent, works until the task is finished', "domain": 'Conscientiousness', "facet": 'Productiveness', "reverse": False},
    {"text": 'Tends to be lazy', "domain": 'Conscientiousness', "facet": 'Productiveness', "reverse": True},
    {"text": 'Has difficulty getting started on tasks', "domain": 'Conscientiousness', "facet": 'Productiveness', "reverse": True},
    {"text": 'Is reliable, can always be counted on', "domain": 'Conscientiousness', "facet": 'Responsibility', "reverse": False},
    {"text": 'Is dependable, steady', "domain": 'Conscientiousness', "facet": 'Responsibility', "reverse": False},
    {"text": 'Can be somewhat careless', "domain": 'Conscientiousness', "facet": 'Responsibility', "reverse": True},
    {"text": 'Sometimes behaves irresponsibly', "domain": 'Conscientiousness', "facet": 'Responsibility', "reverse": True},
    {"text": 'Worries a lot', "domain": 'Negative Emotionality', "facet": 'Anxiety', "reverse": False},
    {"text": 'Can be tense', "domain": 'Negative Emotionality', "facet": 'Anxiety', "reverse": False},
    {"text": 'Is relaxed, handles stress well', "domain": 'Negative Emotionality', "facet": 'Anxiety', "reverse": True},
    {"text": 'Rarely feels anxious or afraid', "domain": 'Negative Emotionality', "facet": 'Anxiety', "reverse": True},
    {"text": 'Often feels sad', "domain": 'Negative Emotionality', "facet": 'Depression', "reverse": False},
    {"text": 'Tends to feel depressed, blue', "domain": 'Negative Emotionality', "facet": 'Depression', "reverse": False},
    {"text": 'Feels secure, comfortable with self', "domain": 'Negative Emotionality', "facet": 'Depression', "reverse": True},
    {"text": 'Stays optimistic after experiencing a setback', "domain": 'Negative Emotionality', "facet": 'Depression', "reverse": True},
    {"text": 'Is temperamental, gets emotional easily', "domain": 'Negative Emotionality', "facet": 'Emotional Volatility', "reverse": False},
    {"text": 'Is moody, has up and down mood swings', "domain": 'Negative Emotionality', "facet": 'Emotional Volatility', "reverse": False},
    {"text": 'Is emotionally stable, not easily upset', "domain": 'Negative Emotionality', "facet": 'Emotional Volatility', "reverse": True},
    {"text": 'Keeps their emotions under control', "domain": 'Negative Emotionality', "facet": 'Emotional Volatility', "reverse": True},
    {"text": 'Is complex, a deep thinker', "domain": 'Open-Mindedness', "facet": 'Intellectual Curiosity', "reverse": False},
    {"text": 'Is curious about many different things', "domain": 'Open-Mindedness', "facet": 'Intellectual Curiosity', "reverse": False},
    {"text": 'Has little interest in abstract ideas', "domain": 'Open-Mindedness', "facet": 'Intellectual Curiosity', "reverse": True},
    {"text": 'Avoids intellectual, philosophical discussions', "domain": 'Open-Mindedness', "facet": 'Intellectual Curiosity', "reverse": True},
    {"text": 'Is fascinated by art, music, or literature', "domain": 'Open-Mindedness', "facet": 'Aesthetic Sensitivity', "reverse": False},
    {"text": 'Values art and beauty', "domain": 'Open-Mindedness', "facet": 'Aesthetic Sensitivity', "reverse": False},
    {"text": 'Has few artistic interests', "domain": 'Open-Mindedness', "facet": 'Aesthetic Sensitivity', "reverse": True},
    {"text": 'Thinks poetry and plays are boring', "domain": 'Open-Mindedness', "facet": 'Aesthetic Sensitivity', "reverse": True},
    {"text": 'Is inventive, finds clever ways to do things', "domain": 'Open-Mindedness', "facet": 'Creative Imagination', "reverse": False},
    {"text": 'Is original, comes up with new ideas', "domain": 'Open-Mindedness', "facet": 'Creative Imagination', "reverse": False},
    {"text": 'Has little creativity', "domain": 'Open-Mindedness', "facet": 'Creative Imagination', "reverse": True},
    {"text": 'Has difficulty imagining things', "domain": 'Open-Mindedness', "facet": 'Creative Imagination', "reverse": True},
]

DOMAINS = ["Extraversion", "Agreeableness", "Conscientiousness",
           "Negative Emotionality", "Open-Mindedness"]


def score_bfi2(responses: dict) -> dict:
    """
    responses: {item_index (0-59): rating (1-5)}. Missing indices are
    allowed (scored on whatever was answered); fully missing domains/facets
    come back as NaN.

    Returns {"domains": {name: mean 1-5}, "facets": {name: mean 1-5},
             "n_items_scored": int, "missing_items": [indices]}
    """
    domain_scores: dict[str, list[float]] = {d: [] for d in DOMAINS}
    facet_scores: dict[str, list[float]] = {}
    missing = []

    for idx, item in enumerate(BFI2_ITEMS):
        if idx not in responses:
            missing.append(idx)
            continue
        raw = responses[idx]
        val = (6 - raw) if item["reverse"] else raw
        domain_scores[item["domain"]].append(val)
        facet_scores.setdefault(item["facet"], []).append(val)

    return {
        "domains": {d: float(np.mean(v)) if v else float("nan") for d, v in domain_scores.items()},
        "facets": {f: float(np.mean(v)) for f, v in facet_scores.items()},
        "n_items_scored": 60 - len(missing),
        "missing_items": missing,
    }


def negative_emotionality_flag(domain_scores: dict, threshold: float = 3.5) -> bool:
    """Consistency-check trigger (report Section 7): flags a respondent
    whose Negative Emotionality is high enough that elicited loss aversion
    / risk aversion should be sanity-checked against it.
    """
    return domain_scores.get("Negative Emotionality", 0.0) >= threshold
