"""
robo_advisory.ingest
=====================
Bridges the live web survey's output (schemaVersion 3 JSON, one file per
respondent, downloaded via the "downloads" capability and sent back by
each peer) into the format the rest of the pipeline consumes.

This replaces `pipeline.simulate_peer_group()` once real data exists --
nothing else in pipeline.py needs to change (see run_full_pipeline_from_real_data
below), because the survey already computed each respondent's posterior
summary (mean + 90% CI per parameter) client-side at submission time.
There is no need to re-run the adaptive engine in Python; ingestion is
pure parsing plus the small amount of re-aggregation (BFI-2 domain/facet
scoring, hierarchical pooling) that only makes sense once the whole group
is assembled.

Expected file: the exact JSON a respondent downloads from the survey's
"done" screen, e.g. `adwaaiit-risk-time-results.json`.
"""
from __future__ import annotations
import json
import glob
from pathlib import Path
import numpy as np

from .personality.bfi2_scoring import score_bfi2, negative_emotionality_flag
from .elicitation.models import PARAM_NAMES

REQUIRED_TOP_LEVEL = ["name", "posterior", "answers"]


def load_respondent_json(path: str) -> dict:
    """Load and lightly validate one respondent's exported JSON file."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    missing = [k for k in REQUIRED_TOP_LEVEL if k not in data]
    if missing:
        raise ValueError(f"{path}: missing expected field(s) {missing} -- "
                          f"is this a real survey export? (schemaVersion={data.get('schemaVersion')})")
    for p in PARAM_NAMES:
        if p not in data["posterior"]:
            raise ValueError(f"{path}: posterior missing parameter '{p}'")
    return data


def load_peer_group(paths: list[str]) -> dict:
    """
    Load several respondents' JSON exports (accepts a list of file paths,
    or use load_peer_group_glob for a directory).

    Returns the same shape pipeline.run_full_pipeline() expects internally:
        {"names": [...], "raw": {name: raw_json_dict}}
    Portfolio construction and BFI-2 scoring are done lazily by
    run_full_pipeline_from_real_data, not here -- this function only parses
    and validates.
    """
    names, raw = [], {}
    for p in paths:
        data = load_respondent_json(p)
        name = data["name"] or Path(p).stem
        if name in raw:
            raise ValueError(f"Duplicate respondent name '{name}' (from {p}) -- "
                              f"rename one of the files or one respondent's `name` field")
        names.append(name)
        raw[name] = data
    if not names:
        raise ValueError("No respondent files provided")
    return {"names": names, "raw": raw}


def load_peer_group_glob(directory: str, pattern: str = "*-risk-time-results.json") -> dict:
    """Convenience wrapper: load every matching JSON file in a directory."""
    paths = sorted(glob.glob(str(Path(directory) / pattern)))
    if not paths:
        raise FileNotFoundError(f"No files matching '{pattern}' found in {directory}")
    return load_peer_group(paths)


def _ci_to_variance(ci90) -> float:
    """Approximate the within-respondent variance of a parameter from its
    reported 90% credible interval, assuming rough normality:
    a 90% CI spans +/- 1.645 SD, so SD ~ (hi - lo) / (2 * 1.645).
    """
    lo, hi = ci90
    if lo is None or hi is None:
        return 1e-6
    sd = max((hi - lo) / (2 * 1.645), 1e-6)
    return float(sd ** 2)


def pool_group_from_summaries(raw: dict, min_individual_weight: float = 0.30) -> dict:
    """
    Real-data counterpart to elicitation.hierarchical.pool_group(), but
    operating on the (mean, ci90) summaries the survey already computed --
    real respondents' raw grid posteriors don't exist in Python (the
    adaptive engine ran client-side in JS), only these summaries do.
    Same empirical-Bayes shrinkage logic and the same disclosed floor
    (report Section 3.5 / 9.3) as the synthetic-data path, so results from
    real and simulated peer groups are directly comparable.
    """
    names = list(raw.keys())
    result = {name: {} for name in names}

    for p in PARAM_NAMES:
        means = np.array([raw[n]["posterior"][p]["mean"] for n in names])
        within_vars = np.array([_ci_to_variance(raw[n]["posterior"][p]["ci90"]) for n in names])
        pop_mean = float(np.mean(means))
        between_var = float(np.var(means, ddof=1)) if len(means) > 1 else 0.0

        for name, m, wv in zip(names, means, within_vars):
            if between_var <= 1e-9:
                w = min_individual_weight
            else:
                w = max(between_var / (between_var + wv), min_individual_weight)
            pooled = w * m + (1 - w) * pop_mean
            result[name][p] = {"raw": float(m), "pooled": float(pooled),
                                "within_var": float(wv), "shrinkage_weight": float(w),
                                "group_mean": pop_mean}
    return result


def score_all_bfi2(raw: dict) -> dict:
    """Re-score each respondent's raw BFI-2 answers through the Python
    scoring engine (rather than trusting the JS-computed domain means
    blindly) -- an independent cross-check that the two implementations
    agree, following the same verify-independently spirit as the rest of
    this project.
    """
    out = {}
    for name, data in raw.items():
        bfi2_raw = data.get("bfi2", {})
        # the survey stores answers as {itemIndex(string): rating}; normalize keys to int
        answers_raw = bfi2_raw.get("rawAnswers") or {}
        if answers_raw:
            answers = {int(k): v for k, v in answers_raw.items()}
            out[name] = score_bfi2(answers)
        else:
            # fall back to the JS-computed summary if raw per-item answers weren't exported
            out[name] = {"domains": bfi2_raw.get("domains", {}), "facets": bfi2_raw.get("facets", {}),
                          "n_items_scored": None, "missing_items": None, "source": "js-computed"}
    return out
