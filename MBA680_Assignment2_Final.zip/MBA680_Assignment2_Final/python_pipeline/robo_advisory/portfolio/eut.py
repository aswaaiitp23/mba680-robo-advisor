"""
robo_advisory.portfolio.eut
============================
Expected Utility Theory portfolio construction (report Section 4.2).

Two-fund separation under joint-normal returns:
    risky fraction  y* = (mu_T - rf) / (gamma * sigma_T^2)
    risky sleeve    T  = the tangency (maximum-Sharpe) portfolio

Every respondent holds the SAME risky sleeve T; gamma only rescales the split
between T and the risk-free asset (G-Secs / T-bills at rf).

Version 2 (position limits)
---------------------------
An unconstrained tangency portfolio can concentrate heavily in a handful of
names -- the "error-maximisation" problem of Michaud (1989). Version 2 solves
the tangency portfolio under a single-stock cap (default 10% in the pipeline),
long-only and fully invested:

    maximise  (w'mu - rf) / sqrt(w' Sigma w)
    s.t.      sum(w) = 1,  0 <= w_i <= cap

This is solved exactly through the standard convex reformulation (y = w / k):

    minimise  y' Sigma y
    s.t.      (mu - rf)' y = 1,  y >= 0,  y_i <= cap * sum(y)

and w = y / sum(y). See `max_ratio_weights`, which also serves the Roy (1952)
safety-first layer in bpt.py (same problem with rf replaced by a threshold H).
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize


def tangency_weights(mu: np.ndarray, sigma: np.ndarray, rf: float) -> np.ndarray:
    """Unconstrained tangency-portfolio weights (sum to 1 within the risky sleeve)."""
    excess = mu - rf
    sigma_inv = np.linalg.pinv(sigma)
    raw = sigma_inv @ excess
    return raw / raw.sum()


def _feasible_start(mu: np.ndarray, threshold: float, cap: float | None) -> np.ndarray:
    """A long-only, cap-respecting starting point with positive excess over threshold."""
    n = len(mu)
    w0 = np.ones(n) / n
    if (mu - threshold) @ w0 > 1e-9 and (cap is None or 1.0 / n <= cap):
        return w0
    # otherwise load the highest-mu names up to the cap
    c = cap if cap is not None else 1.0
    w0 = np.zeros(n)
    remaining = 1.0
    for i in np.argsort(-mu):
        take = min(c, remaining)
        w0[i] = take
        remaining -= take
        if remaining <= 1e-12:
            break
    return w0


def max_ratio_weights(mu: np.ndarray, sigma: np.ndarray, threshold: float,
                       cap: float | None = None) -> np.ndarray:
    """
    Long-only, fully-invested weights maximising (w'mu - threshold) / sigma_p,
    optionally with a per-asset cap. threshold = rf gives the (capped) tangency
    portfolio; threshold = an aspiration level H gives Roy's safety-first
    portfolio for that H. Solved via the convex reformulation described in the
    module docstring (a quadratic programme with linear constraints).
    """
    mu = np.asarray(mu, dtype=float)
    sigma = np.asarray(sigma, dtype=float)
    n = len(mu)
    if cap is not None and cap * n < 1.0 - 1e-12:
        raise ValueError(f"cap={cap} infeasible for {n} assets (need cap*n >= 1)")
    excess = mu - threshold
    if excess.max() <= 0:
        raise ValueError("No asset beats the threshold; ratio maximisation undefined.")

    w0 = _feasible_start(mu, threshold, cap)
    y0 = w0 / max(excess @ w0, 1e-9)

    cons = [{"type": "eq", "fun": lambda y: excess @ y - 1.0, "jac": lambda y: excess}]
    if cap is not None:
        A = cap * np.ones((n, n)) - np.eye(n)          # cap*sum(y) - y_i >= 0
        cons.append({"type": "ineq", "fun": lambda y: A @ y, "jac": lambda y: A})

    res = minimize(lambda y: float(y @ sigma @ y), y0,
                   jac=lambda y: 2.0 * sigma @ y,
                   method="SLSQP", bounds=[(0.0, None)] * n, constraints=cons,
                   options={"maxiter": 2000, "ftol": 1e-14})
    y = np.clip(res.x, 0.0, None)
    w = y / y.sum()
    if cap is not None:
        # tidy numerical dust (e.g. 0.1000000003) without changing the solution
        w = np.minimum(w, cap)
        w = w / w.sum()
    return w


def portfolio_stats(w: np.ndarray, mu: np.ndarray, sigma: np.ndarray) -> tuple[float, float]:
    return float(w @ mu), float(np.sqrt(max(w @ sigma @ w, 0.0)))


def eut_allocation(mu: np.ndarray, sigma: np.ndarray, rf: float, gamma: float,
                    long_only: bool = True, cap: float | None = None) -> dict:
    """
    Returns the full EUT-optimal allocation for one respondent with CRRA gamma.

    Output:
      risky_weights   : weights WITHIN the risky sleeve (sum to 1), i.e. the
                         tangency portfolio -- identical across all respondents
      risky_fraction  : fraction of total wealth in the risky sleeve
      risky_fraction_unclipped : the same before the [0, 1] long-only clip
      cash_fraction   : 1 - risky_fraction (held in G-Secs at rf)
      full_weights    : risky_fraction * risky_weights (fraction of TOTAL wealth)
    """
    if gamma <= 0:
        raise ValueError("EUT two-fund formula requires gamma > 0 (risk-averse); "
                          "risk-neutral/risk-loving gamma needs a corner-solution rule, "
                          "not implemented here.")
    if cap is not None:
        w_tan = max_ratio_weights(mu, sigma, rf, cap=cap)
    else:
        w_tan = tangency_weights(mu, sigma, rf)
        if long_only and np.any(w_tan < 0):
            w_tan = np.clip(w_tan, 0, None)
            w_tan = w_tan / w_tan.sum()

    excess = mu - rf
    tangency_excess_return = float(w_tan @ excess)
    tangency_var = float(w_tan @ sigma @ w_tan)
    risky_fraction_unclipped = tangency_excess_return / (gamma * tangency_var)
    risky_fraction = risky_fraction_unclipped
    if long_only:
        risky_fraction = float(np.clip(risky_fraction, 0.0, 1.0))  # no leverage, no shorting cash

    full_weights = risky_fraction * w_tan
    return {
        "risky_weights": w_tan,
        "risky_fraction": risky_fraction,
        "risky_fraction_unclipped": risky_fraction_unclipped,
        "cash_fraction": 1 - risky_fraction,
        "full_weights": full_weights,
        "expected_return": rf + risky_fraction * tangency_excess_return,
        "volatility": risky_fraction * np.sqrt(tangency_var),
        "tangency_return": rf + tangency_excess_return,
        "tangency_volatility": float(np.sqrt(tangency_var)),
        "tangency_sharpe": tangency_excess_return / np.sqrt(tangency_var),
        "implied_lambda": tangency_excess_return / tangency_var,
    }
