"""
robo_advisory.portfolio.eut
============================
Expected Utility Theory portfolio construction (project report, Section 6.1).

Two-fund solution under joint-normal returns, unconstrained mean-variance:
    w* = (1/gamma) * Sigma^-1 (mu - rf * 1)

Every respondent holds the SAME risky tangency portfolio; gamma only rescales
the split between it and the risk-free asset. w* can exceed 1 (leverage) or
be negative in a subset of names if the unconstrained solution calls for
short positions -- `long_only=True` re-solves under a no-short constraint via
projection onto the simplex-with-cash feasible set (simple clip-and-renormalize;
adequate for a course-project deliverable, not a production QP).
"""
from __future__ import annotations
import numpy as np


def tangency_weights(mu: np.ndarray, sigma: np.ndarray, rf: float) -> np.ndarray:
    """Unconstrained tangency-portfolio weights (sum to 1 within the risky sleeve)."""
    excess = mu - rf
    sigma_inv = np.linalg.pinv(sigma)
    raw = sigma_inv @ excess
    return raw / raw.sum()


def eut_allocation(mu: np.ndarray, sigma: np.ndarray, rf: float, gamma: float,
                    long_only: bool = True) -> dict:
    """
    Returns the full EUT-optimal allocation for one respondent with CRRA gamma.

    Output:
      risky_weights   : weights WITHIN the risky sleeve (sum to 1), i.e. the
                         tangency portfolio -- identical across all respondents
      risky_fraction  : fraction of total wealth in the risky sleeve (1/gamma scaled)
      cash_fraction   : 1 - risky_fraction (can be negative => borrowing to lever up)
      full_weights    : risky_fraction * risky_weights, i.e. weights as a fraction
                         of TOTAL wealth (what actually gets traded)
    """
    if gamma <= 0:
        raise ValueError("EUT two-fund formula requires gamma > 0 (risk-averse); "
                          "risk-neutral/risk-loving gamma needs a corner-solution rule, "
                          "not implemented here.")
    w_tan = tangency_weights(mu, sigma, rf)
    if long_only and np.any(w_tan < 0):
        w_tan = np.clip(w_tan, 0, None)
        w_tan = w_tan / w_tan.sum()

    excess = mu - rf
    tangency_excess_return = float(w_tan @ excess)
    tangency_var = float(w_tan @ sigma @ w_tan)
    risky_fraction = tangency_excess_return / (gamma * tangency_var)

    if long_only:
        risky_fraction = float(np.clip(risky_fraction, 0.0, 1.0))  # no leverage, no shorting cash

    full_weights = risky_fraction * w_tan
    return {
        "risky_weights": w_tan,
        "risky_fraction": risky_fraction,
        "cash_fraction": 1 - risky_fraction,
        "full_weights": full_weights,
        "expected_return": rf + risky_fraction * tangency_excess_return,
        "volatility": risky_fraction * np.sqrt(tangency_var),
    }
