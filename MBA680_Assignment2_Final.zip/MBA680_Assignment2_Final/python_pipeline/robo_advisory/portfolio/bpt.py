"""
robo_advisory.portfolio.bpt
============================
SP/A - Behavioral Portfolio Theory portfolio construction (report Section 4.3),
operationalised as two mental accounts in the spirit of Das, Markowitz, Scheid
& Statman (2010, JFQA), "Portfolio Optimization with Mental Accounts". Each
account has its own threshold and its own tolerance for missing it.

Version 2 (the version used in the report)
------------------------------------------
1. SAFETY account (share s of wealth, sized by elicited loss aversion lambda).
   Goal: "do not lose money in this account in a bad year". It may hold
   G-Secs (risk-free at rf) and the capped tangency portfolio T. Following
   Telser's (1955) safety-first rule, it maximises expected return subject to

        P( r_safety < H_s ) <= alpha          (H_s = 0%, alpha = 5%)

   Under normality, with equity share e in T and (1 - e) in G-Secs,
        mu_s = rf + e (mu_T - rf),   sigma_s = e sigma_T
   and the constraint mu_s - z_alpha sigma_s >= H_s gives the largest feasible
        e* = min( 1, (rf - H_s) / (z_alpha sigma_T - (mu_T - rf)) ).
   Expected return rises with e, so e* is the Telser optimum.

2. ASPIRATION account (share 1 - s). Goal: "give me the best chance of beating
   an ambitious target H_a" (the 75th percentile of the universe's expected
   returns). Roy's (1952) safety-first portfolio for H_a -- maximise
   (mu_p - H_a) / sigma_p, which under normality maximises P(r_p >= H_a) --
   long-only with the same single-stock cap as the EUT portfolio.

Combined holdings (fractions of total wealth):
    G-Secs        = s (1 - e*)
    stock weights = s e* T  +  (1 - s) A

Version 1 (the earlier draft) used the uncapped Roy portfolio above rf as the
safety layer. With an all-equity universe that layer was simply the tangency
portfolio, so the BPT portfolio ended up riskier than the EUT one for every
client; version 2 fixes that by letting the safety account hold G-Secs.
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm

from .eut import max_ratio_weights, portfolio_stats


def safety_first_weights(mu: np.ndarray, sigma: np.ndarray, threshold: float,
                          w0: np.ndarray | None = None, cap: float | None = None) -> dict:
    """Roy (1952): max_w (w'mu - threshold) / sqrt(w'Sigma w)  s.t. sum(w)=1, 0<=w<=cap."""
    if cap is not None or (np.max(mu) > threshold):
        try:
            w = max_ratio_weights(mu, sigma, threshold, cap=cap)
            ret, vol = portfolio_stats(w, mu, sigma)
            return {"weights": w, "expected_return": ret, "volatility": vol,
                    "sf_ratio": (ret - threshold) / vol if vol > 0 else np.nan,
                    "threshold": threshold, "converged": True}
        except ValueError:
            pass
    # fallback: direct SLSQP on the ratio (e.g. threshold above every mu)
    n = len(mu)
    w0 = w0 if w0 is not None else np.ones(n) / n

    def neg_sf_ratio(w):
        ret = w @ mu
        vol = np.sqrt(max(w @ sigma @ w, 1e-12))
        return -(ret - threshold) / vol

    constraints = [{"type": "eq", "fun": lambda w: np.sum(w) - 1.0}]
    bounds = [(0.0, cap if cap is not None else 1.0)] * n
    res = minimize(neg_sf_ratio, w0, method="SLSQP", bounds=bounds,
                    constraints=constraints, options={"maxiter": 500, "ftol": 1e-10})
    w = np.clip(res.x, 0, None)
    w = w / w.sum()
    ret, vol = portfolio_stats(w, mu, sigma)
    sf_ratio = (ret - threshold) / vol if vol > 0 else np.nan
    return {"weights": w, "expected_return": ret, "volatility": vol,
            "sf_ratio": sf_ratio, "threshold": threshold, "converged": bool(res.success)}


def telser_equity_share(mu_T: float, sigma_T: float, rf: float,
                         floor: float = 0.0, alpha: float = 0.05) -> float:
    """Largest share e in the risky portfolio T (rest in G-Secs at rf) such that
    P(r < floor) <= alpha under normality -- Telser's (1955) safety-first rule."""
    if rf < floor:
        return 0.0
    z = float(norm.ppf(1.0 - alpha))
    denom = z * sigma_T - (mu_T - rf)
    if denom <= 0:
        return 1.0
    return float(np.clip((rf - floor) / denom, 0.0, 1.0))


def bpt_layers(mu: np.ndarray, sigma: np.ndarray, rf: float,
               aspiration_threshold: float, cap: float | None = None,
               safety_floor: float = 0.0, safety_alpha: float = 0.05) -> dict:
    """Client-independent building blocks: the capped tangency portfolio T, the
    Telser equity share e* of the safety account, and the Roy aspiration
    portfolio A. Computed once per universe; clients differ only in s."""
    w_T = max_ratio_weights(mu, sigma, rf, cap=cap)
    mu_T, sig_T = portfolio_stats(w_T, mu, sigma)
    e = telser_equity_share(mu_T, sig_T, rf, floor=safety_floor, alpha=safety_alpha)
    asp = safety_first_weights(mu, sigma, aspiration_threshold, cap=cap)
    return {
        "tangency_weights": w_T, "tangency_return": mu_T, "tangency_volatility": sig_T,
        "safety_equity_share": e,
        "safety_return": rf + e * (mu_T - rf), "safety_volatility": e * sig_T,
        "safety_floor": safety_floor, "safety_alpha": safety_alpha,
        "aspiration_layer": asp,
        "aspiration_threshold": aspiration_threshold,
        "cap": cap, "rf": rf,
    }


def bpt_allocation(mu: np.ndarray, sigma: np.ndarray, rf: float,
                    safety_threshold: float, aspiration_threshold: float,
                    safety_capital_frac: float, loss_aversion: float = 2.0,
                    cap: float | None = None, safety_alpha: float = 0.05,
                    layers: dict | None = None) -> dict:
    """
    Two-account SP/A-BPT allocation (version 2).

    safety_threshold     : H_s, the return floor of the safety account (0.0 =
                           "no nominal loss"); missed with probability <= safety_alpha
    aspiration_threshold : H_a, the aspiration account's target return
    safety_capital_frac  : s, share of wealth in the safety account (from lambda)
    layers               : optional precomputed `bpt_layers` output (re-used
                           across clients because it does not depend on them)

    Returns stock weights as fractions of TOTAL wealth ("combined_weights")
    plus the separate G-Sec weight; combined_weights.sum() + gsec_weight == 1.
    """
    if layers is None:
        layers = bpt_layers(mu, sigma, rf, aspiration_threshold, cap=cap,
                            safety_floor=safety_threshold, safety_alpha=safety_alpha)
    s = float(safety_capital_frac)
    e = layers["safety_equity_share"]
    w_T = layers["tangency_weights"]
    w_A = layers["aspiration_layer"]["weights"]

    gsec_weight = s * (1.0 - e)
    combined_weights = s * e * w_T + (1.0 - s) * w_A
    combined_return = float(gsec_weight * rf + combined_weights @ mu)
    combined_vol = float(np.sqrt(max(combined_weights @ sigma @ combined_weights, 0.0)))

    return {
        "safety_layer": {"equity_share": e, "gsec_share": 1.0 - e,
                          "expected_return": layers["safety_return"],
                          "volatility": layers["safety_volatility"],
                          "floor": layers["safety_floor"], "alpha": layers["safety_alpha"],
                          "risky_weights": w_T},
        "aspiration_layer": layers["aspiration_layer"],
        "safety_capital_frac": s,
        "gsec_weight": gsec_weight,
        "equity_weight": 1.0 - gsec_weight,
        "combined_weights": combined_weights,
        "combined_expected_return": combined_return,
        "combined_volatility": combined_vol,
        "loss_aversion_used": loss_aversion,
        "layers": layers,
    }


def safety_capital_fraction_from_lambda(lam: float, lam_lo: float = 1.0, lam_hi: float = 4.0,
                                         frac_lo: float = 0.3, frac_hi: float = 0.8) -> float:
    """Map an elicited loss-aversion coefficient lambda onto the safety-account
    capital fraction, linearly interpolated between (lam_lo -> frac_lo) and
    (lam_hi -> frac_hi), clipped to [frac_lo, frac_hi]. lambda -- not gamma --
    drives the split between mental accounts.
    """
    t = (lam - lam_lo) / (lam_hi - lam_lo)
    t = float(np.clip(t, 0.0, 1.0))
    return frac_lo + t * (frac_hi - frac_lo)


def prob_below(mean: float, vol: float, floor: float = 0.0) -> float:
    """P(one-year return < floor) under normality."""
    if vol <= 0:
        return 0.0 if mean >= floor else 1.0
    return float(norm.cdf((floor - mean) / vol))
