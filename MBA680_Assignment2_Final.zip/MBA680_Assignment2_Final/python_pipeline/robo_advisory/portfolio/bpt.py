"""
robo_advisory.portfolio.bpt
============================
SP/A - Behavioral Portfolio Theory portfolio construction (project report,
Section 6.2), operationalized as mental-account layers per Das, Markowitz,
Scheid & Statman (2010, JFQA) -- "Portfolio Optimization with Mental Accounts"
-- with each layer solved via Roy's (1952, Econometrica) safety-first
criterion rather than a single joint mean-variance optimization:

    maximize   SFRatio(w) = (w'mu - A) / sqrt(w'Sigma w)
    subject to sum(w) = 1, w >= 0                (long-only, fully invested)

A = the account's threshold ("disaster level" for the safety layer, a much
higher "aspiration level" for the potential layer). The SAME optimization
routine serves both layers; only A and the layer's capital allocation differ
-- this is deliberate and mirrors how Das et al. (2010) show a single
mental-accounting objective (probability of missing a threshold) spans both
a conservative and an aggressive account.

Note (from the report's Section 6.2, corrected against Das et al. 2010):
the AGGREGATE of the two layers is mean-variance efficient when short-selling
is unconstrained; it only departs from the single monolithic EUT solution
when (a) a no-short constraint binds on one layer, or (b) the two layers use
different thresholds A, which is the substantive behavioral content here --
different mental accounts are allowed to reflect different risk attitudes,
which a single joint optimization cannot represent.
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize


def safety_first_weights(mu: np.ndarray, sigma: np.ndarray, threshold: float,
                          w0: np.ndarray | None = None) -> dict:
    """Solve max_w (w'mu - threshold) / sqrt(w'Sigma w)  s.t. sum(w)=1, w>=0."""
    n = len(mu)
    w0 = w0 if w0 is not None else np.ones(n) / n

    def neg_sf_ratio(w):
        ret = w @ mu
        vol = np.sqrt(max(w @ sigma @ w, 1e-12))
        return -(ret - threshold) / vol

    constraints = [{"type": "eq", "fun": lambda w: np.sum(w) - 1.0}]
    bounds = [(0.0, 1.0)] * n
    res = minimize(neg_sf_ratio, w0, method="SLSQP", bounds=bounds,
                    constraints=constraints, options={"maxiter": 500, "ftol": 1e-10})
    w = np.clip(res.x, 0, None)
    w = w / w.sum()
    ret = float(w @ mu)
    vol = float(np.sqrt(w @ sigma @ w))
    sf_ratio = (ret - threshold) / vol if vol > 0 else np.nan
    return {"weights": w, "expected_return": ret, "volatility": vol,
            "sf_ratio": sf_ratio, "threshold": threshold, "converged": bool(res.success)}


def bpt_allocation(mu: np.ndarray, sigma: np.ndarray, rf: float,
                    safety_threshold: float, aspiration_threshold: float,
                    safety_capital_frac: float, loss_aversion: float = 2.0) -> dict:
    """
    Two-layer BPT allocation.

    safety_capital_frac : fraction of total wealth allocated to the downside-
                           protection layer; the remainder goes to the
                           aspiration layer. In the converged design (report
                           Section 6.2), higher elicited loss aversion (lambda)
                           should push MORE capital into the safety layer
                           holding CRRA gamma fixed -- `loss_aversion` is
                           accepted here so callers can size this fraction
                           from the respondent's own lambda rather than a
                           fixed assumption (see pipeline.py for the mapping).
    """
    safety = safety_first_weights(mu, sigma, safety_threshold)
    aspiration = safety_first_weights(mu, sigma, aspiration_threshold)

    combined_weights = (safety_capital_frac * safety["weights"] +
                         (1 - safety_capital_frac) * aspiration["weights"])
    combined_return = float(combined_weights @ mu)
    combined_vol = float(np.sqrt(combined_weights @ sigma @ combined_weights))

    return {
        "safety_layer": safety,
        "aspiration_layer": aspiration,
        "safety_capital_frac": safety_capital_frac,
        "combined_weights": combined_weights,
        "combined_expected_return": combined_return,
        "combined_volatility": combined_vol,
        "loss_aversion_used": loss_aversion,
    }


def safety_capital_fraction_from_lambda(lam: float, lam_lo: float = 1.0, lam_hi: float = 4.0,
                                         frac_lo: float = 0.3, frac_hi: float = 0.8) -> float:
    """Map an elicited loss-aversion coefficient lambda onto the safety-layer
    capital fraction, linearly interpolated between (lam_lo -> frac_lo) and
    (lam_hi -> frac_hi), clipped to [frac_lo, frac_hi]. This operationalizes
    the report's Section 6.2 point that lambda -- not gamma -- should drive
    the split between mental-account layers.
    """
    t = (lam - lam_lo) / (lam_hi - lam_lo)
    t = float(np.clip(t, 0.0, 1.0))
    return frac_lo + t * (frac_hi - frac_lo)
