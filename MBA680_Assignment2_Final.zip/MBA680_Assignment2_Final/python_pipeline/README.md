# Robo-Advisory Pipeline — Steps 2–6 Implementation

Working Python implementation of the adaptive elicitation engine, BFI-2
scoring, and EUT / SP-A-BPT portfolio construction described in
`MBA680_RoboAdvisory_Preliminary_Submission.docx`. Currently wired to run
end-to-end on **synthetic data** (simulated peer group + synthetic asset
universe) so the pipeline is validated and ready before real peer responses
and the Markowitz Portfolio Project's stock list / covariance matrix arrive.

## Install

```bash
pip install -r requirements.txt
```

## Run the demo

```bash
python3 demo.py
```

This will:
1. Simulate a 5-person peer group with heterogeneous true preference
   parameters and run each through the adaptive elicitation engine.
2. Report a **parameter recovery check** — since the true parameters are
   known in simulation, this checks whether the adaptive engine's posterior
   actually converges toward them (the single most important correctness
   test available before real data exists).
3. Run the full pipeline (elicitation → hierarchical pooling → BFI-2 scoring
   → EUT portfolio → SP/A-BPT portfolio → Step 6 commentary) and print a
   per-respondent results table.
4. Write `outputs/demo_pipeline_results.csv`.

## Run the tests

```bash
python3 tests/test_pipeline.py
# or, if pytest is installed:
python3 -m pytest tests/ -v
```

## Package layout

```
robo_advisory/
  elicitation/
    models.py        Behavioral primitives: CPT value function, Prelec
                      probability weighting, quasi-hyperbolic discounting,
                      Fechner/Luce stochastic choice rule, parameter grid
    engine.py         Adaptive Bayesian engine: candidate question pool,
                      precomputed likelihood matrix, expected-information-
                      gain question selection, posterior updating
    hierarchical.py   Empirical-Bayes partial pooling across the peer group
                      (with a disclosed shrinkage floor -- see docstring)
  personality/
    bfi2_scoring.py   BFI-2 domain/facet scoring using the real, verified
                       Soto & John (2017) item set (60 items) -- same list
                       embedded in the live survey
  portfolio/
    eut.py            EUT two-fund CRRA-scaled tangency portfolio
    bpt.py             SP/A-BPT mental-account layered portfolio (Roy's
                       safety-first ratio per layer, per Das, Markowitz,
                       Scheid & Statman, 2010)
  ingest.py            Parses real survey JSON exports into the pipeline's
                       internal format; summary-level hierarchical pooling
                       for real data (no raw grid arrays available client-side)
pipeline.py             Orchestration + synthetic-data stand-ins + both
                       run_full_pipeline (synthetic) / run_full_pipeline_from_real_data entry points
sample_real_data/       Fixture JSON files (fictional test personas) shaped
                       exactly like real survey output, for testing the
                       real-data path before any real response exists
demo.py                End-to-end demo / recovery-check script
tests/test_pipeline.py Correctness tests (14 checks, all passing)
```

## What's real vs. what's a placeholder

| Component | Status |
|---|---|
| Adaptive elicitation engine (models, engine, hierarchical) | Real, tested, ready for live respondents |
| BFI-2 scoring engine | Real — uses the actual verified Soto & John (2017) item set (60 items, domain/facet/reverse-keying), same list embedded in the live survey |
| EUT portfolio construction | Real, tested |
| SP/A-BPT portfolio construction | Real, tested |
| Real-data ingestion (`ingest.py`) | Real, tested against sample fixtures — parses the live survey's JSON export format directly |
| Peer group responses | **Simulated** (`simulate_peer_group()`) for the self-test path; **real** once JSON files from the live survey are collected (`run_full_pipeline_from_real_data()`) |
| Asset universe (mu, Sigma, rf) | **Synthetic placeholder** (`synthetic_asset_universe()`) until the Markowitz Portfolio Project's real stock list and covariance matrix are received (`load_real_asset_universe()` is the loader to point at them) |

## Two ways to run it

**Self-test (synthetic data, proves the pipeline is correct):**
```python
from robo_advisory.pipeline import run_full_pipeline
df, universe, peer = run_full_pipeline(n_people=5, n_assets=10)
```

**Real data (once peer responses and the asset universe exist):**
```python
import glob
from robo_advisory.pipeline import run_full_pipeline_from_real_data, load_real_asset_universe

paths = glob.glob("responses/*.json")   # every file your peer group sent back
universe = load_real_asset_universe("markowitz_returns.csv", "markowitz_covariance.csv", rf=0.065)
df = run_full_pipeline_from_real_data(paths, universe)
```
`sample_real_data/` contains four fixture files (fictional test personas, not real submissions) in exactly the shape the live survey produces, used by `tests/test_pipeline.py` to validate this path end-to-end before any real response exists.

## Swapping in real data

1. **Real peer responses**: collect the `.json` files your peer group downloads from the survey's "done" screen (or the combined export from its "Combine responses" view) and pass their paths to `run_full_pipeline_from_real_data()`. No code changes needed — this is already wired and tested against fixture files shaped exactly like real output.
2. **Real asset universe**: once the Markowitz Portfolio Project's stock list and covariance matrix are ready, adjust `load_real_asset_universe()` if their export format differs from the two-CSV shape assumed there (e.g. if it's an Excel workbook instead).

## Known limitations (disclosed, not hidden)

- The parameter grid (7 points per dimension, 16,807 nodes) trades estimation precision for speed; the demo's own recovery-check output shows the resulting MAE.
- A single curvature parameter γ is shared across gains and losses (rather than separate α and β) to keep the grid five-dimensional; revisit if real data suggests gain/loss curvature genuinely differ.
- Each BPT mental-account layer is solved via SLSQP on a non-convex ratio objective, not guaranteed globally optimal; check `result["converged"]` per layer before trusting it in production.
- `pool_group_from_summaries()` approximates each respondent's within-person variance from their reported 90% credible interval (assuming rough normality), since the real ingestion path only has the survey's posterior *summary*, not the full grid array the JS engine computed it from. This is a reasonable approximation, not the exact same computation `pool_group()` does on raw sessions in the synthetic path.
- The BFI-2 item set was reconstructed from the original validation paper's published item table, cross-checked against its scoring-key fragments (13 of 15 facets verified numerically; 2 inferred from the stated 2-true/2-reverse balance rule). Spot-check a few items against the official Colby PDF before treating results as final.
