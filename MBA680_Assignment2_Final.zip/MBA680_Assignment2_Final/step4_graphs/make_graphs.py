"""Step 4 graphical representations: utility function (EUT/CRRA), value function
(prospect theory, exactly as used by the elicitation engine), Prelec probability
weighting, and quasi-hyperbolic discounting -- for all 5 respondents, from the
pooled posterior parameters in pipeline/outputs/real_peers_steps2to4and6.csv.

Usage: python3 make_graphs.py [outdir] [palette_json]
"""
import csv, json, sys, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/step4_graphs/out"
os.makedirs(OUT, exist_ok=True)
PAL = {
    "series": ["#4D62EF", "#FD4C00", "#12A385", "#CA54FB", "#D69E00"],
    "text": "#36393B", "muted": "#5f6266", "grid": "#e7e4e6", "surface": "#ffffff",
    "font": "Liberation Sans",
}
if len(sys.argv) > 2:
    PAL.update(json.load(open(sys.argv[2])))

rows = list(csv.DictReader(open("/home/claude/pipeline/outputs/real_peers_steps2to4and6.csv")))
# fixed, entity-bound order (colour follows the person, never the rank)
ORDER = ["Shree Charan", "Kshitij", "Kartika", "Ayushi", "Adwaaiit Pande"]
P = {r["respondent"]: r for r in rows}
people = []
for i, name in enumerate(ORDER):
    r = P[name]
    people.append(dict(name=name, color=PAL["series"][i],
                       gamma=float(r["gamma_pooled"]), lam=float(r["lambda_pooled"]),
                       alpha=float(r["alpha_w_pooled"]), beta=float(r["beta_hyp_pooled"]),
                       delta=float(r["delta_pooled"])))

plt.rcParams.update({
    "font.family": PAL["font"], "font.size": 10.5, "axes.edgecolor": PAL["muted"],
    "axes.labelcolor": PAL["text"], "xtick.color": PAL["muted"], "ytick.color": PAL["muted"],
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
    "grid.color": PAL["grid"], "grid.linewidth": 0.8, "axes.titleweight": "bold",
    "axes.titlesize": 12, "axes.titlecolor": PAL["text"], "legend.frameon": False,
    "figure.facecolor": PAL["surface"], "axes.facecolor": PAL["surface"],
    "savefig.facecolor": PAL["surface"],
})

def crra(W, g):
    if abs(1 - g) < 1e-9:
        return np.log(W)
    return (np.power(W, 1 - g) - 1) / (1 - g)

def value(x, g, lam):
    e = max(1 - g, 0.05)                      # identical floor to engine/models.py
    return np.where(x >= 0, np.abs(x) ** e, -lam * np.abs(x) ** e)

def prelec(p, a):
    return np.exp(-np.power(-np.log(p), a))

def disc(t, b, d):
    return np.where(t > 0, b * np.power(d, t / 30.0), 1.0)

def legend_label(p, kind):
    if kind == "u":   return f"{p['name']}  (γ = {p['gamma']:.2f})"
    if kind == "v":   return f"{p['name']}  (γ = {p['gamma']:.2f}, λ = {p['lam']:.2f})"
    if kind == "w":   return f"{p['name']}  (α = {p['alpha']:.2f})"
    if kind == "d":   return f"{p['name']}  (β = {p['beta']:.2f}, δ = {p['delta']:.3f})"

# ---------- 1. EUT utility (CRRA) ----------
def plot_utility(ax):
    W = np.linspace(0.3, 2.5, 400)
    for p in people:
        ax.plot(W, crra(W, p["gamma"]), color=p["color"], lw=2, label=legend_label(p, "u"))
    ax.axvline(1, color=PAL["muted"], lw=0.8, ls=":")
    ax.set_xlabel("Wealth relative to today (W / W₀)")
    ax.set_ylabel("Utility  u(W)")
    ax.set_title("Utility function (EUT, CRRA)")
    ax.text(0.02, 0.97, "u(W) = (W^(1−γ) − 1) / (1−γ)", transform=ax.transAxes, va="top", fontsize=9.5, color=PAL["muted"], style="italic")
    ax.set_ylim(-2.2, 2.2)
    ax.annotate("Kshitij: γ < 0 → convex\n(risk-seeking)", xy=(2.2, crra(2.2, -0.5)), xytext=(1.45, 1.75),
                fontsize=9, color=PAL["text"], arrowprops=dict(arrowstyle="-", color=PAL["muted"], lw=0.8))
    ax.annotate("Shree Charan, Ayushi, Adwaaiit:\nγ ≈ 2.2 → strongly concave\n(curves overlap)",
                xy=(0.6, crra(0.6, 2.2)), xytext=(0.75, -1.95), fontsize=9, color=PAL["text"],
                arrowprops=dict(arrowstyle="-", color=PAL["muted"], lw=0.8))

# ---------- 2. Prospect-theory value function ----------
def plot_value(ax):
    x = np.concatenate([np.linspace(-1, -1e-4, 400), np.linspace(1e-4, 1, 400)])
    for p in people:
        y = value(x, p["gamma"], p["lam"])
        ax.plot(x[x < 0], y[x < 0], color=p["color"], lw=2, label=legend_label(p, "v"))
        ax.plot(x[x > 0], y[x > 0], color=p["color"], lw=2)
    ax.axhline(0, color=PAL["muted"], lw=0.8); ax.axvline(0, color=PAL["muted"], lw=0.8)
    ax.set_xlabel("Gain / loss relative to reference point (1 = one reference stake)")
    ax.set_ylabel("Value  v(x)")
    ax.set_title("Value function (prospect theory)")
    ax.text(0.02, 0.97, "v(x) = x^e for gains, −λ·|x|^e for losses,  e = max(1−γ, 0.05)", transform=ax.transAxes, va="top", fontsize=9.5, color=PAL["muted"], style="italic")
    ax.annotate("Shree Charan, Ayushi, Adwaaiit overlap:\ne hits its 0.05 floor → near-step curve,\nextreme diminishing sensitivity", xy=(0.5, 0.965), xytext=(0.12, -0.75), fontsize=9, color=PAL["text"], arrowprops=dict(arrowstyle="-", color=PAL["muted"], lw=0.8))
    ax.annotate("Kshitij: λ = 1.6 →\nlosses loom 1.6× larger", xy=(-0.8, value(np.array([-0.8]), -0.5, 1.6)[0]),
                xytext=(-0.98, 0.45), fontsize=9, color=PAL["text"],
                arrowprops=dict(arrowstyle="-", color=PAL["muted"], lw=0.8))

# ---------- 3. Prelec probability weighting ----------
def plot_weight(ax):
    pp = np.linspace(1e-4, 1, 500)
    ax.plot([0, 1], [0, 1], color=PAL["muted"], lw=1, ls="--", label="Objective (w = p)")
    for p in people:
        ax.plot(pp, prelec(pp, p["alpha"]), color=p["color"], lw=2, label=legend_label(p, "w"))
    ax.set_xlabel("Objective probability  p"); ax.set_ylabel("Decision weight  w(p)")
    ax.set_title("Probability weighting (Prelec, 1998)")
    ax.text(0.02, 0.97, "w(p) = exp(−(−ln p)^α)", transform=ax.transAxes, va="top", fontsize=9.5, color=PAL["muted"], style="italic")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.set_aspect("equal")
    ax.annotate("α < 1: over-weights\nrare outcomes", xy=(0.05, prelec(np.array([0.05]), 0.4)[0]),
                xytext=(0.12, 0.62), fontsize=9, color=PAL["text"],
                arrowprops=dict(arrowstyle="-", color=PAL["muted"], lw=0.8))

# ---------- 4. Quasi-hyperbolic discounting ----------
def plot_discount(ax):
    t = np.linspace(1, 365, 365)
    for p in people:
        ax.plot(t, disc(t, p["beta"], p["delta"]), color=p["color"], lw=2, label=legend_label(p, "d"))
        ax.plot([0], [1], marker="o", ms=5, color=PAL["text"])
        ax.plot([0, 1], [1, p["beta"] * p["delta"] ** (1 / 30)], color=p["color"], lw=1, ls=":")
    ax.set_xlabel("Delay  t (days)"); ax.set_ylabel("Discount weight  D(t)")
    ax.set_title("Time preference (quasi-hyperbolic β–δ)")
    ax.text(0.98, 0.97, "D(0) = 1,  D(t) = β·δ^(t/30) for t > 0", transform=ax.transAxes, va="top", ha="right", fontsize=9.5, color=PAL["muted"], style="italic")
    ax.set_xlim(-5, 365); ax.set_ylim(0, 1.05)
    ax.annotate("drop at t > 0 = present bias (β)", xy=(3, 0.79), xytext=(60, 0.88), fontsize=9,
                color=PAL["text"], arrowprops=dict(arrowstyle="-", color=PAL["muted"], lw=0.8))

# ---------- 5. EUT risky share vs gamma (saturation + identification) ----------
def plot_eut_share(ax):
    LMKT = 2.5
    g = np.linspace(0.05, 3.2, 600)
    ax.axvspan(0.95, 3.0, color=PAL["grid"], alpha=0.6, lw=0)
    ax.text(1.97, 0.18, "Engine's value exponent hits its 0.05 floor here:\n"
            "γ is identified as ≥ ~1, not its exact size", ha="center", fontsize=8.5, color=PAL["muted"])
    ax.plot(g, np.minimum(LMKT / g, 1.0), color=PAL["text"], lw=2, label="Long-only risky share = min(λ_mkt/γ, 100%)")
    ax.plot(g[g > 0.4], (LMKT / g)[g > 0.4], color=PAL["muted"], lw=1, ls="--", label="Unclipped λ_mkt/γ")
    for p in people:
        gg = max(p["gamma"], 0.05)
        ax.plot([gg], [1.0], marker="o", ms=9, ls="none", color=p["color"], mec=PAL["surface"], mew=2, label=p["name"] + (" (γ floored to 0.05)" if p["gamma"] < 0.05 else ""))
    ax.axvline(LMKT, color=PAL["muted"], lw=0.8, ls=":")
    ax.text(LMKT + 0.03, 1.55, "γ = 2.5: first point where\nEUT holds < 100% equity", fontsize=8.5, color=PAL["text"])
    ax.set_xlabel("Risk aversion  γ"); ax.set_ylabel("Share of wealth in tangency portfolio")
    ax.set_ylim(0, 2.0); ax.set_xlim(0, 3.2)
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    ax.set_title("EUT risky share vs. risk aversion (λ_mkt = 2.5)")

def single(fn, fname, size=(8.2, 5.2), legend_loc="best"):
    fig, ax = plt.subplots(figsize=size)
    fn(ax)
    ax.legend(loc=legend_loc, fontsize=8.8)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, fname), dpi=200)
    plt.close(fig)

single(plot_utility, "fig_utility_function.png", legend_loc="lower right")
single(plot_value, "fig_value_function.png", legend_loc="lower right")
single(plot_weight, "fig_probability_weighting.png", size=(6.6, 6.2), legend_loc="lower right")
single(plot_discount, "fig_discount_function.png", legend_loc="lower left")
single(plot_eut_share, "fig_eut_share_vs_gamma.png", legend_loc="upper right")

# combined 2x2 panel
fig, axs = plt.subplots(2, 2, figsize=(13.5, 10))
for ax, fn in zip(axs.flat, [plot_utility, plot_value, plot_weight, plot_discount]):
    fn(ax); ax.title.set_fontsize(10.5)
axs[1, 0].set_aspect("auto")
from matplotlib.lines import Line2D
handles = [Line2D([0], [0], color=p["color"], lw=2.5) for p in people]
fig.legend(handles, [p["name"] for p in people], loc="lower center", ncol=5, fontsize=11, bbox_to_anchor=(0.5, 0.0))
fig.tight_layout(rect=(0, 0.04, 1, 1))
fig.savefig(os.path.join(OUT, "fig_step4_panel.png"), dpi=200)
plt.close(fig)

# numeric table of what was plotted (audit trail)
with open(os.path.join(OUT, "step4_parameters_plotted.csv"), "w", newline="") as f:
    w = csv.writer(f); w.writerow(["respondent", "gamma_pooled", "value_exponent_used(max(1-gamma,0.05))",
                                   "lambda_pooled", "alpha_w_pooled", "beta_hyp_pooled", "delta_pooled",
                                   "D(30d)", "D(365d)", "w(0.05)", "w(0.95)"])
    for p in people:
        w.writerow([p["name"], round(p["gamma"], 3), round(max(1 - p["gamma"], 0.05), 3), round(p["lam"], 3),
                    p["alpha"], p["beta"], p["delta"], round(float(disc(np.array([30]), p["beta"], p["delta"])[0]), 3),
                    round(float(disc(np.array([365]), p["beta"], p["delta"])[0]), 3),
                    round(float(prelec(np.array([0.05]), p["alpha"])[0]), 3), round(float(prelec(np.array([0.95]), p["alpha"])[0]), 3)])
print("done ->", OUT, sorted(os.listdir(OUT)))
