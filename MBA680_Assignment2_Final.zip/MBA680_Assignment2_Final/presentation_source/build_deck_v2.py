"""Fill the template-derived skeleton (skeleton.pptx) with the MBA680 Assignment 2
content: native charts, tables, screenshots, speaker tags and speaker notes."""
import csv, copy
import numpy as np
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.chart.data import XyChartData, CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_MARKER_STYLE, XL_LABEL_POSITION, XL_TICK_LABEL_POSITION
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.oxml.ns import qn
from pptx.opc.constants import RELATIONSHIP_TYPE as RT
from lxml import etree

SRC, OUT = "skeleton2.pptx", "MBA680_Assignment2_RoboAdvisory.pptx"
INK = RGBColor(0x36, 0x39, 0x3B)
MUTED = RGBColor(0x5F, 0x62, 0x66)
GRID = RGBColor(0xE7, 0xE4, 0xE6)
TEAL_DARK = RGBColor(0x0E, 0x8C, 0x74)
ORDER = ["Shree Charan", "Kshitij", "Kartika", "Ayushi", "Adwaaiit Pande"]
COL = {"Shree Charan": "4D62EF", "Kshitij": "FD4C00", "Kartika": "12A385", "Ayushi": "CA54FB", "Adwaaiit Pande": "D69E00"}
SHORT = {"Adwaaiit Pande": "Adwaaiit"}

# ------------------------------------------------------------------ data
R = {r["respondent"]: r for r in csv.DictReader(open("/home/claude/pipeline/outputs/real_peers_steps2to4and6.csv"))}
P5 = {r["respondent"]: r for r in csv.DictReader(open("/home/claude/pipeline/outputs/real_peers_step5b_standard_lambda.csv"))}
D = {}
for n in ORDER:
    r, p = R[n], P5[n]
    D[n] = dict(gamma=float(r["gamma_pooled"]), lam=float(r["lambda_pooled"]), alpha=float(r["alpha_w_pooled"]),
                beta=float(r["beta_hyp_pooled"]), delta=float(r["delta_pooled"]), gl=int(r["grableLytton_total"]),
                gl_band=r["grableLytton_level"], risk=int(r["generalRisk_0to10"]), pat=int(r["generalPatience_0to10"]),
                ne=float(r["bfi2_NegativeEmotionality"]), om=float(r["bfi2_OpenMindedness"]), co=float(r["bfi2_Conscientiousness"]),
                retest=float(r["retestConsistency"]), eut_frac=float(p["EUT_risky_fraction"]), eut_ret=float(p["EUT_expected_return"]),
                eut_vol=float(p["EUT_volatility"]), safety=float(p["BPT_safety_capital_frac"]), bpt_ret=float(p["BPT_combined_return"]),
                bpt_vol=float(p["BPT_combined_volatility"]), unclipped=float(p["EUT_risky_fraction_UNCLIPPED"]))

prs = Presentation(SRC)
S = list(prs.slides)

# ------------------------------------------------------------------ helpers
def shape(slide, name):
    for sh in slide.shapes:
        if sh.name == name:
            return sh
    raise KeyError(name)

def remove(sh):
    sh._element.getparent().remove(sh._element)

def set_title(slide, text, name=None, size=None):
    sh = slide.shapes.title if name is None else shape(slide, name)
    tf = sh.text_frame
    p0 = tf.paragraphs[0]
    for extra in list(tf.paragraphs[1:]):
        extra._p.getparent().remove(extra._p)
    # drop line breaks / extra runs, keep first run's formatting
    for br in p0._p.findall(qn("a:br")):
        p0._p.remove(br)
    runs = p0.runs
    for r in runs[1:]:
        r._r.getparent().remove(r._r)
    lines = text.split("\n")
    runs[0].text = lines[0]
    for ln in lines[1:]:
        br = etree.SubElement(p0._p, qn("a:br"))
        r = copy.deepcopy(runs[0]._r)
        r.find(qn("a:t")).text = ln
        p0._p.append(r)
    if size:
        for r in p0._p.findall(qn("a:r")):
            r.find(qn("a:rPr")).set("sz", str(int(size * 100)))

def fill_paras(sh, items, sizes=None):
    """items: list of (level, text) or (level, [(text, bold), ...]); formatting comes from the layout."""
    tf = sh.text_frame
    txBody = tf._txBody
    for p in list(txBody.findall(qn("a:p"))):
        txBody.remove(p)
    for lvl, content in items:
        p = etree.SubElement(txBody, qn("a:p"))
        if lvl:
            ppr = etree.SubElement(p, qn("a:pPr")); ppr.set("lvl", str(lvl))
        runs = [(content, None)] if isinstance(content, str) else content
        for txt, bold in runs:
            r = etree.SubElement(p, qn("a:r"))
            rpr = etree.SubElement(r, qn("a:rPr")); rpr.set("lang", "en-US"); rpr.set("dirty", "0")
            if sizes and lvl in sizes:
                rpr.set("sz", str(int(sizes[lvl] * 100)))
            if bold is not None:
                rpr.set("b", "1" if bold else "0")
            t = etree.SubElement(r, qn("a:t")); t.text = txt

def textbox(slide, x, y, w, h, paras, size=14, color=INK, bold=False, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, font=None, name=None, space_after=4):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    if name: tb.name = name
    tf = tb.text_frame; tf.word_wrap = True
    tf.margin_left = tf.margin_right = Inches(0.04); tf.margin_top = tf.margin_bottom = Inches(0.02)
    tf.vertical_anchor = anchor
    if isinstance(paras, str): paras = [paras]
    for i, para in enumerate(paras):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align; p.space_after = Pt(space_after)
        runs = para if isinstance(para, list) else [(para, {})]
        for txt, opt in runs:
            r = p.add_run(); r.text = txt
            f = r.font; f.size = Pt(opt.get("size", size)); f.bold = opt.get("bold", bold)
            c = opt.get("color", color); f.color.rgb = c
            fn = opt.get("font", font)
            if fn: f.name = fn
    return tb

def speaker_tag(slide, who):
    textbox(slide, 0.93, 7.06, 3.0, 0.3, who, size=10, color=MUTED, name="Speaker tag")

def notes(slide, text):
    slide.notes_slide.notes_text_frame.text = text

def style_axis(ax, mn, mx, major, fmt=None, title=None):
    ax.minimum_scale, ax.maximum_scale, ax.major_unit = mn, mx, major
    ax.has_major_gridlines = True
    ax.major_gridlines.format.line.color.rgb = GRID
    ax.major_gridlines.format.line.width = Pt(0.75)
    ax.format.line.color.rgb = RGBColor(0xB9, 0xB6, 0xB8)
    ax.tick_labels.font.size = Pt(10); ax.tick_labels.font.color.rgb = MUTED
    ax.tick_label_position = XL_TICK_LABEL_POSITION.LOW
    if fmt:
        ax.tick_labels.number_format = fmt; ax.tick_labels.number_format_is_linked = False
    if title:
        ax.has_title = True
        ax.axis_title.text_frame.text = title
        f = ax.axis_title.text_frame.paragraphs[0].runs[0].font
        f.size = Pt(10.5); f.bold = False; f.color.rgb = MUTED

def chart_title(chart, title, sub):
    chart.has_title = True
    tf = chart.chart_title.text_frame
    tf.text = title
    r = tf.paragraphs[0].runs[0]; r.font.size = Pt(13); r.font.bold = True; r.font.color.rgb = INK
    p = tf.add_paragraph(); rr = p.add_run(); rr.text = sub
    rr.font.size = Pt(10.5); rr.font.italic = True; rr.font.bold = False; rr.font.color.rgb = MUTED

def xy_chart(slide, x, y, w, h, series, xr, yr, title, sub, xtitle, ytitle, xfmt="General", yfmt="General"):
    cd = XyChartData()
    for name, pts in series:
        s = cd.add_series(name)
        for a, b in pts:
            s.add_data_point(float(a), float(b))
    gf = slide.shapes.add_chart(XL_CHART_TYPE.XY_SCATTER_LINES_NO_MARKERS, Inches(x), Inches(y), Inches(w), Inches(h), cd)
    ch = gf.chart
    ch.font.name = "+mn-lt"; ch.font.size = Pt(10); ch.font.color.rgb = INK
    ch.has_legend = False
    chart_title(ch, title, sub)
    style_axis(ch.category_axis, *xr, fmt=xfmt, title=xtitle)
    style_axis(ch.value_axis, *yr, fmt=yfmt, title=ytitle)
    ch.category_axis.has_major_gridlines = False
    return ch

def color_series(ch, colors, width=2.25, dashes=None):
    for i, s in enumerate(ch.plots[0].series):
        c = colors[i]
        if c is None: continue
        s.format.line.color.rgb = RGBColor.from_string(c)
        s.format.line.width = Pt(width if not isinstance(width, list) else width[i])
        if dashes and dashes[i]:
            s.format.line.dash_style = dashes[i]
        s.smooth = False
        s.marker.style = XL_MARKER_STYLE.NONE

def legend_row(slide, x, y, w, names=ORDER, extra=None, compact=False):
    """Shared legend: short coloured rule + name, one row (identity never colour-alone: names everywhere)."""
    n = len(names); step = w / n
    for i, nm in enumerate(names):
        lx = x + i * step
        L = 0.22 if compact else 0.35
        ln = slide.shapes.add_connector(1, Inches(lx), Inches(y + 0.15), Inches(lx + L), Inches(y + 0.15))
        ln.line.color.rgb = RGBColor.from_string(COL[nm]); ln.line.width = Pt(3)
        base = SHORT.get(nm, nm) if step < 1.8 else nm
        lab = base if extra is None else f"{base}{extra(nm)}"
        off = 0.27 if compact else 0.42
        tb = textbox(slide, lx + off, y, step - off - 0.03, 0.3, lab, size=12 if step >= 1.8 else 10.5, color=INK)
        tb.text_frame.word_wrap = False

def make_table(slide, x, y, w, h, header, rows, col_w, size=12, first_col_bold=True, align_first=PP_ALIGN.LEFT):
    gf = slide.shapes.add_table(len(rows) + 1, len(header), Inches(x), Inches(y), Inches(w), Inches(h))
    tbl = gf.table
    for j, cw in enumerate(col_w):
        tbl.columns[j].width = Inches(cw)
    def put(cell, text, bold=False, hdr=False, align=PP_ALIGN.CENTER):
        cell.text = ""
        tf = cell.text_frame; p = tf.paragraphs[0]; p.alignment = align
        r = p.add_run(); r.text = text
        r.font.size = Pt(size if not hdr else size - 1); r.font.bold = bold; r.font.color.rgb = INK
        if hdr:
            r.font.name = "+mj-lt"
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
        cell.margin_left = cell.margin_right = Inches(0.06); cell.margin_top = cell.margin_bottom = Inches(0.03)
    for j, htxt in enumerate(header):
        c = tbl.cell(0, j); put(c, htxt, hdr=True, align=align_first if j == 0 else PP_ALIGN.CENTER)
        tcPr = c._tc.get_or_add_tcPr()
        for old in tcPr.findall(qn("a:solidFill")): tcPr.remove(old)
        sf = etree.SubElement(tcPr, qn("a:solidFill")); sc = etree.SubElement(sf, qn("a:schemeClr")); sc.set("val", "accent1")
        lm = etree.SubElement(sc, qn("a:lumMod")); lm.set("val", "75000")
    for i, row in enumerate(rows, 1):
        for j, v in enumerate(row):
            put(tbl.cell(i, j), v, bold=(first_col_bold and j == 0), align=align_first if j == 0 else PP_ALIGN.CENTER)
    return tbl

def pct(v, d=1): return f"{v*100:.{d}f}%"


# ======================================================================= v2 content
TS = 24          # one title size for every content slide (action titles)
AMBER = RGBColor(0xFF, 0xF1, 0xCC)
TINT = RGBColor(0xEB, 0xFD, 0xF9)

def footer(slide, text):
    textbox(slide, 4.2, 7.06, 8.1, 0.3, text, size=9, color=MUTED, align=PP_ALIGN.RIGHT, name="Sources")

def card(slide, x, y, w, h, fill=TINT, name=None):
    c = slide.shapes.add_shape(1, Inches(x), Inches(y), Inches(w), Inches(h))
    c.fill.solid(); c.fill.fore_color.rgb = fill; c.line.fill.background(); c.shadow.inherit = False
    if name: c.name = name
    return c

def tint_cell(tbl, r, c, rgb):
    cell = tbl.cell(r, c); cell.fill.solid(); cell.fill.fore_color.rgb = rgb

def crra(w, g): return np.log(w) if abs(1 - g) < 1e-9 else (w ** (1 - g) - 1) / (1 - g)
def val(x, g, l):
    e = max(1 - g, 0.05)
    return x ** e if x >= 0 else -l * (-x) ** e
def prelec(p, a): return float(np.exp(-(-np.log(p)) ** a))
def disc(t, b, d): return 1.0 if t <= 0 else b * d ** (t / 30)

def lakh(frac): return f"₹{frac*100:.1f}L"

# ================================================================== 1 TITLE
s = S[0]
set_title(s, "Robo-advisory\nportfolio\ndesign", "Title 1", size=40)
fill_paras(shape(s, "Subtitle 2"), [(0, "Adwaaiit Pande & Ayushi Mishra")])
textbox(s, 0.93, 4.25, 5.6, 0.9, ["MBA680 Behavioral Finance · Assignment 2",
        "EUT vs SP/A Behavioral Portfolio Theory, with personality"], size=16, color=INK)

# ================================================================== 2 EXECUTIVE SUMMARY
s = S[1]
set_title(s, "The answer first: three findings", size=TS)
remove(shape(s, "Table 4"))
findings = [
    ("1", "EUT can't personalise this group",
     "All five: 100% in the same tangency portfolio (13.2% return, 16.1% volatility), because every γ is below λ_mkt = 2.5."),
    ("2", "SP/A-BPT can, through loss aversion",
     "Safety-layer share moves from 30% to 40% with λ. Kshitij, the only loss-averse client, gets the most protection."),
    ("3", "Personality shapes the advice, not the weights",
     "3 of 5 profiles are flagged (say-vs-do gap, straight-lining, inconsistent repeats) and need a human conversation first."),
]
for i, (num, head, body) in enumerate(findings):
    x = 0.93 + i * 3.82
    card(s, x, 1.75, 3.6, 3.9, name=f"Finding {num}")
    textbox(s, x + 0.25, 1.95, 1.0, 0.9, num, size=40, color=TEAL_DARK, font="+mj-lt")
    textbox(s, x + 0.25, 2.8, 3.15, 1.1, head, size=17, bold=True, color=INK)
    textbox(s, x + 0.25, 3.95, 3.15, 1.65, body, size=14, color=INK)
textbox(s, 0.93, 5.85, 11.4, 0.9, [
    [("Scope: ", {"bold": True}), ("a five-person pilot of classmates, including both presenters. Assumed client profile: ₹1 crore corpus (from Problem 1), 5+ year horizon, no near-term liquidity needs. Goals and risk capacity were not surveyed.", {})]],
    size=13, color=MUTED)
speaker_tag(s, "Adwaaiit")

# ================================================================== 3 APPROACH
s = S[2]
set_title(s, "Six steps, three stages: measure, model, recommend", size=TS)
fill_paras(shape(s, "Content Placeholder 2"), [
    (0, "Brief: act as a personal investment adviser to a peer group, then automate it as a robo-advisory product"),
    (0, "Step 5 inputs reused from Problem 1: 66 NSE stocks, 3-year covariance, rf 6.75%"),
], sizes={0: 16})
speaker_tag(s, "Adwaaiit")

# ================================================================== 4 INSTRUMENTS
s = S[3]
set_title(s, "Only the choice task yields the parameters both theories need", size=TS)
fill_paras(shape(s, "Content Placeholder 2"), [
    (0, "WHY NOT ONE STANDARD SURVEY?"), (1, "One score can't give γ, λ, time preference or a plottable utility function"), (0, " "),
    (0, "EVERY PART HAS A JOB"), (1, "Benchmark, context, personality, parameters"), (0, " "),
    (0, "SAY VS. DO"), (1, "Scales show what people say; choices show what they do"),
], sizes={0: 14, 1: 15})
remove(shape(s, "Table 4"))
make_table(s, 5.6, 2.0, 6.75, 4.3, ["INSTRUMENT", "ITEMS", "MEASURES", "WHY WE NEED IT"], [
    ["Self-rating anchors", "2", "Risk, patience (0–10)", "Say-vs-do check"],
    ["Grable & Lytton (1999)", "13", "Financial risk tolerance", "Industry benchmark"],
    ["DOSPERT financial (Blais & Weber, 2006)", "6", "Investing vs. gambling", "Risk-taking is context-specific"],
    ["BFI-2 (Soto & John, 2017)", "60", "Big Five, 15 facets", "Step 3; flags careless answers"],
    ["Adaptive choice engine (ours)", "18 + 2", "γ, λ, α, β, δ", "Only source of the parameters"],
], [2.05, 0.75, 1.85, 2.1], size=11)
textbox(s, 5.6, 6.4, 6.75, 0.4, "About 100 items in one sitting, 20–25 minutes.", size=12, color=MUTED)
speaker_tag(s, "Adwaaiit")

# ================================================================== 5 ENGINE
s = S[4]
set_title(s, "Twenty adaptive choices pin down five parameters", "Title 1", size=TS)
remove(shape(s, "Content Placeholder 9"))
textbox(s, 7.36, 0.75, 5.0, 0.4, "FIVE PARAMETERS, ONE MODEL", size=13, bold=True, color=INK)
from PIL import Image as _Im
rows = [("γ  risk aversion", "eq/eq_gamma.png"), ("λ  loss aversion", "eq/eq_lambda.png"),
        ("α  probability weighting", "eq/eq_alpha.png"), ("β, δ  present bias, patience", "eq/eq_beta.png")]
for i, (lab, img) in enumerate(rows):
    y = 1.25 + i * 0.62
    textbox(s, 7.36, y + 0.04, 2.3, 0.4, lab, size=13, color=INK)
    w0, h0 = _Im.open(img).size
    h = 0.36; w = h * w0 / h0
    s.shapes.add_picture(img, Inches(9.7), Inches(y), Inches(min(w, 2.7)), Inches(h if w <= 2.7 else 2.7 * h0 / w0)).name = f"Equation {i+1}"
fill_paras(shape(s, "Content Placeholder 3"), [
    (0, "EACH OF 18 QUESTIONS"),
    (1, "A gamble vs. a sure amount, or now vs. later"),
    (1, "Mixed gain/loss gambles separate λ from γ"),
    (1, "Bayes update over 7,776 combinations; next question = most informative"),
    (1, "2 hidden repeats test consistency; Empirical-Bayes pooling"),
], sizes={0: 13, 1: 14})
speaker_tag(s, "Adwaaiit")
footer(s, "Kahneman & Tversky (1979); Prelec (1998); Laibson (1997); Toubia et al. (2013)")

# ================================================================== 6 STEP 4 GRAPHS (2x2)
s = S[5]
set_title(s, "Step 4: Kshitij is the outlier", size=TS)
remove(shape(s, "Table 4"))
legend_row(s, 0.93, 1.42, 11.2)
W = np.linspace(0.35, 2.5, 40)
def small(ch):
    ch.font.size = Pt(9)
    for ax in (ch.category_axis, ch.value_axis):
        ax.tick_labels.font.size = Pt(9)
        if ax.has_title:
            ax.axis_title.text_frame.paragraphs[0].runs[0].font.size = Pt(9)
def short_title(ch, t, sub):
    tf = ch.chart_title.text_frame
    tf.paragraphs[0].runs[0].text = t; tf.paragraphs[0].runs[0].font.size = Pt(11)
    tf.paragraphs[1].runs[0].text = sub; tf.paragraphs[1].runs[0].font.size = Pt(9)
GX, GY, GW, GH = [0.85, 6.7], [1.75, 4.33], 5.75, 2.55
ch = xy_chart(s, GX[0], GY[0], GW, GH, [(n, [(w, crra(w, D[n]["gamma"])) for w in W]) for n in ORDER],
              (0.25, 2.5, 0.5), (-2.2, 2.2, 1.0), "Utility (EUT, CRRA)", "concave = risk-averse", "Wealth / today", None, xfmt="0.0#", yfmt="0")
color_series(ch, [COL[n] for n in ORDER]); small(ch)
xs = np.concatenate([-np.logspace(0, -3, 22), [0.0], np.logspace(-3, 0, 22)])
ch = xy_chart(s, GX[1], GY[0], GW, GH, [(n, [(x, val(x, D[n]["gamma"], D[n]["lam"])) for x in xs]) for n in ORDER],
              (-1, 1, 0.5), (-2.0, 1.5, 1.0), "Value (prospect theory)", "steeper for losses = loss-averse", "Gain / loss (stakes)", None, xfmt="0.0", yfmt="0")
color_series(ch, [COL[n] for n in ORDER]); small(ch)
pp = np.concatenate([[0.001, 0.005, 0.01, 0.02, 0.03], np.linspace(0.05, 1, 30)])
ch = xy_chart(s, GX[0], GY[1], GW, GH, [("w = p", [(0, 0), (1, 1)])] + [(n, [(p, prelec(p, D[n]["alpha"])) for p in pp]) for n in ORDER],
              (0, 1, 0.25), (0, 1, 0.5), "Probability weighting (Prelec)", "dashed = objective probability", "Probability p", None, xfmt="0.00", yfmt="0.0")
color_series(ch, ["9A9C9E"] + [COL[n] for n in ORDER], width=[1.0] + [2.0] * 5, dashes=[MSO_LINE_DASH_STYLE.DASH] + [None] * 5); small(ch)
tt = [0, 1] + list(np.linspace(15, 365, 30))
ch = xy_chart(s, GX[1], GY[1], GW, GH, [(n, [(t, disc(t, D[n]["beta"], D[n]["delta"])) for t in tt]) for n in ORDER],
              (0, 365, 90), (0, 1.05, 0.5), "Time preference (β–δ)", "drop at t > 0 = present bias", "Delay (days)", None, xfmt="0", yfmt="0.0")
color_series(ch, [COL[n] for n in ORDER]); small(ch)
speaker_tag(s, "Adwaaiit")
footer(s, "Curves from pooled parameters. Kahneman & Tversky (1979); Prelec (1998); Laibson (1997)")

# ================================================================== 7 DIVIDER
s = S[6]
set_title(s, "Results\n& advice")

# ================================================================== 8 OUTCOMES (flags highlighted)
s = S[7]
set_title(s, "Three of five profiles carry a flag an adviser must act on", size=TS)
remove(shape(s, "Table 4"))
FLAG = {"Shree Charan": "BFI-2 exactly 3.00 on all five domains", "Kshitij": "—", "Kartika": "—",
        "Ayushi": "Hidden repeats inconsistent (0.5)", "Adwaaiit Pande": "Says risk 10/10; choices give γ 2.2"}
rows = [[n, str(D[n]["gl"]), f"{D[n]['risk']} / {D[n]['pat']}", f"{D[n]['gamma']:.2f}", f"{D[n]['lam']:.3f}", f"{D[n]['retest']:.1f}", FLAG[n]] for n in ORDER]
tbl = make_table(s, 0.93, 1.75, 11.4, 3.6, ["RESPONDENT", "GRABLE-LYTTON", "SELF RISK / PATIENCE", "γ", "λ", "RETEST", "FLAG"],
                 rows, [2.0, 1.45, 1.75, 0.9, 1.0, 1.0, 3.3], size=13)
for r, n in enumerate(ORDER, 1):
    if FLAG[n] != "—":
        tint_cell(tbl, r, 6, AMBER)
tint_cell(tbl, 4, 5, AMBER)                       # Ayushi retest
tint_cell(tbl, 5, 1, AMBER); tint_cell(tbl, 5, 2, AMBER); tint_cell(tbl, 5, 3, AMBER)   # Adwaaiit gap
textbox(s, 0.93, 5.55, 11.4, 1.2, [
    [("γ and λ drive the portfolios ", {"bold": True}), ("(pooled by Empirical Bayes). Kshitij's γ = −0.50 is floored to 0.05 for portfolio maths. α, β, δ are on the Step 4 graphs.", {})],
    [("Pilot sample: five classmates, including both presenters.", {"color": MUTED, "size": 12})]], size=13)
speaker_tag(s, "Ayushi")

# ================================================================== 9 EUT + sensitivity
s = S[8]
set_title(s, "EUT: all five, 100%, one portfolio", size=TS)
remove(shape(s, "Table 4"))
g = np.linspace(0.05, 3.2, 64)
ser = [("Long-only risky share", [(x, min(2.5 / x, 1.0)) for x in g]), ("Unclipped 2.5/γ", [(x, 2.5 / x) for x in np.linspace(1.25, 3.2, 20)])]
for n in ORDER:
    ser.append((n, [(max(D[n]["gamma"], 0.05), 1.0)]))
ch = xy_chart(s, 0.85, 1.6, 6.6, 4.6, ser, (0, 3.2, 0.5), (0, 2.0, 0.25), "EUT risky share vs. risk aversion",
              "share = min(λ_mkt / γ, 100%), λ_mkt = 2.5; Kshitij plotted at floored γ = 0.05", "Risk aversion γ", "Share in tangency portfolio", xfmt="0.0", yfmt="0%")
color_series(ch, ["36393B", "9A9C9E"] + [None] * 5, width=[2.5, 1.25] + [2] * 5, dashes=[None, MSO_LINE_DASH_STYLE.DASH] + [None] * 5)
for i, n in enumerate(ORDER):
    sr = ch.plots[0].series[2 + i]
    sr.format.line.fill.background()
    sr.marker.style = XL_MARKER_STYLE.CIRCLE; sr.marker.size = 11
    sr.marker.format.fill.solid(); sr.marker.format.fill.fore_color.rgb = RGBColor.from_string(COL[n])
    sr.marker.format.line.color.rgb = RGBColor(0xFF, 0xFF, 0xFF); sr.marker.format.line.width = Pt(1.5)
legend_row(s, 0.93, 6.3, 7.2, names=ORDER, extra=None, compact=True)
textbox(s, 0.93, 6.62, 6.6, 0.35, "Three dots overlap near γ = 2.2 (Shree Charan, Ayushi, Adwaaiit).", size=10, color=MUTED)
textbox(s, 7.75, 1.75, 4.6, 0.75, "100%", size=34, color=TEAL_DARK, font="+mj-lt")
textbox(s, 7.75, 2.5, 4.6, 0.75, "in equities for all five, in the same tangency portfolio: 13.21% return, 16.08% volatility", size=13, color=INK)
trio = [D[n]["gamma"] for n in ("Shree Charan", "Ayushi", "Adwaaiit Pande")]
def rng(lm):
    v = [min(lm / gg, 1.0) for gg in trio]
    lo, hi = round(min(v) * 100), round(max(v) * 100)
    return "100%" if lo == 100 else (f"{lo}%" if lo == hi else f"{lo}–{hi}%")
textbox(s, 7.75, 3.45, 4.6, 0.4, "Robustness: risky share vs. market price of risk", size=12, bold=True, color=INK)
make_table(s, 7.75, 3.85, 4.55, 1.9, ["λ_MKT", "MKT SHARPE", "γ ≈ 2.2 (×3)", "KARTIKA, KSHITIJ"],
           [[f"{lm:.1f}" + (" (base)" if lm == 2.5 else ""), f"{lm * 0.16:.2f}", rng(lm), "100%"] for lm in (1.5, 2.0, 2.5, 3.0)],
           [1.15, 1.1, 1.2, 1.1], size=11)
textbox(s, 7.75, 5.85, 4.6, 1.0, "Also conditional on γ: the engine identifies γ only as above ~1 (at γ = 3.0 the share is 83%), and γ comes from small-stakes choices (Rabin, 2000).", size=11, color=MUTED)
speaker_tag(s, "Ayushi")
footer(s, "Two-fund separation; He & Litterman (1999); Rabin (2000). Sharpe = λ_mkt × σ_mkt (σ ≈ 16%)")

# ================================================================== 10 BPT + honest reframe
s = S[9]
set_title(s, "SP/A-BPT personalises the mix through loss aversion", size=TS)
remove(shape(s, "Table 4"))
cd = CategoryChartData()
cd.categories = [SHORT.get(n, n) for n in ORDER]
cd.add_series("Safety-layer capital", [D[n]["safety"] for n in ORDER])
gf = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(0.85), Inches(1.6), Inches(5.9), Inches(4.7), cd)
ch = gf.chart
ch.font.name = "+mn-lt"; ch.font.size = Pt(11); ch.font.color.rgb = INK
ch.has_legend = False
chart_title(ch, "Capital in the safety layer", "safety = 30% + 16.7% × (λ − 1)")
plot = ch.plots[0]; plot.gap_width = 70; plot.vary_by_categories = False
ser = plot.series[0]
for i, n in enumerate(ORDER):
    pt = ser.points[i]; pt.format.fill.solid(); pt.format.fill.fore_color.rgb = RGBColor.from_string(COL[n])
plot.has_data_labels = True
dl = plot.data_labels; dl.number_format = "0.0%"; dl.number_format_is_linked = False
dl.position = XL_LABEL_POSITION.OUTSIDE_END; dl.font.size = Pt(12); dl.font.bold = True; dl.font.color.rgb = INK
style_axis(ch.value_axis, 0, 0.5, 0.1, fmt="0%")
ch.category_axis.tick_labels.font.size = Pt(11); ch.category_axis.tick_labels.font.color.rgb = INK
ch.category_axis.format.line.color.rgb = RGBColor(0xB9, 0xB6, 0xB8)
make_table(s, 7.0, 1.7, 5.3, 2.9, ["RESPONDENT", "λ", "SAFETY", "RETURN", "VOL. (EUT 16.1%)"],
           [[SHORT.get(n, n), f"{D[n]['lam']:.3f}", pct(D[n]["safety"]), pct(D[n]["bpt_ret"], 2), pct(D[n]["bpt_vol"], 2)] for n in ORDER],
           [1.35, 0.75, 0.9, 1.0, 1.3], size=11)
card(s, 7.0, 4.8, 5.3, 2.05, fill=AMBER, name="Caveat card")
textbox(s, 7.2, 4.92, 4.95, 1.85, [
    [("Honest catch: BPT is riskier than EUT here. ", {"bold": True}),
     ("Our universe is all equity, so the safety layer is the tangency portfolio itself, and 60–70% sits in a concentrated aspiration layer: 27–29% volatility vs. 16% under EUT.", {})],
    [("Fix: hold G-Secs or liquid funds in the safety account, and cap single stocks.", {"bold": True})]], size=12, space_after=6)
speaker_tag(s, "Ayushi")
footer(s, "Das, Markowitz, Scheid & Statman (2010); Roy (1952)")

# ================================================================== 11 CLIENT CARDS
s = S[10]
set_title(s, "What we would tell each client", size=TS)
remove(shape(s, "Table 4"))
textbox(s, 0.93, 1.45, 11.4, 0.45, [[("Per ₹1 crore. EUT gives every client the same answer: 100% in the tangency portfolio (13.2% return, 16.1% vol). SP/A-BPT splits each client's money:", {})]], size=13, color=MUTED)
CLIENTS = [
    ("Kshitij", "Loss-averse (λ 1.6), risk-seeking in gains, most impatient",
     "Frame advice in drawdown terms; use SIPs and lock-ins to curb impatience."),
    ("Kartika", "Near risk-neutral; gambling appetite above investing (6.67 vs 4.67)",
     "Automate rebalancing; ring-fence speculation inside the aspiration sleeve."),
    ("Shree Charan", "Overweights long shots (α 0.57); flat BFI-2 profile",
     "Re-run the BFI-2 before finalising; cap lottery-type picks."),
    ("Ayushi", "Open to new framing (Openness 4.0); inconsistent repeats",
     "Confirm preferences in a five-minute follow-up before investing."),
    ("Adwaaiit Pande", "Says 10/10 risk, chooses γ 2.2; most patient",
     "Discuss the say-vs-do gap before going all-in; long horizon suits him."),
]
cw, gap = 2.16, 0.15
for i, (n, trait, advice) in enumerate(CLIENTS):
    x = 0.93 + i * (cw + gap); y = 2.05
    card(s, x, y, cw, 4.2, name=f"Client {n}")
    bar = s.shapes.add_shape(1, Inches(x), Inches(y), Inches(cw), Inches(0.12))
    bar.fill.solid(); bar.fill.fore_color.rgb = RGBColor.from_string(COL[n]); bar.line.fill.background(); bar.shadow.inherit = False
    d = D[n]; sf = round(d["safety"] * 100, 1) / 100
    textbox(s, x + 0.12, y + 0.22, cw - 0.24, 0.4, SHORT.get(n, n), size=15, bold=True, color=INK)
    textbox(s, x + 0.12, y + 0.65, cw - 0.24, 0.85, trait, size=10.5, color=TEAL_DARK)
    textbox(s, x + 0.12, y + 1.55, cw - 0.24, 0.35, "SAFETY · ASPIRATION", size=9, bold=True, color=MUTED)
    textbox(s, x + 0.12, y + 1.85, cw - 0.24, 0.45, f"{lakh(sf)} · {lakh(1 - sf)}", size=15, bold=True, color=INK)
    textbox(s, x + 0.12, y + 2.35, cw - 0.24, 0.35, f"{d['bpt_ret']*100:.1f}% return · {d['bpt_vol']*100:.1f}% vol", size=10.5, color=INK)
    textbox(s, x + 0.12, y + 2.85, cw - 0.24, 1.8, advice, size=11.5, color=INK)
speaker_tag(s, "Ayushi")

# ================================================================== 12 PERSONALITY (Title-and-Content layout)
s = S[11]
lay = [l for l in prs.slide_layouts if l.name == "Title and Content"][0]
for rel in s.part.rels.values():
    if rel.reltype == RT.SLIDE_LAYOUT:
        rel._target = lay.part
set_title(s, "Personality should shape the advice, not the weights", "Title 3", size=TS)
tsh = shape(s, "Title 3"); tsh.left, tsh.top, tsh.width, tsh.height = Emu(850392), Emu(0), Emu(10122632), Emu(1307592)
remove(shape(s, "Text Placeholder 6"))
textbox(s, 0.93, 1.5, 11.4, 0.5, [[("Principle: ", {"bold": True}), ("personality changes how we advise and how much we trust the numbers; γ and λ alone set the weights.", {})]], size=15)
cards4 = [
    ("NEGATIVE EMOTIONALITY × λ", "Both high → lead with drawdown alerts and reassurance. They disagree → human follow-up.", "None of our five crosses the 3.5 threshold; the rule is built in for a larger cohort."),
    ("SAY VS. DO GAPS", "Self-report far from revealed γ → a short conversation before investing, never a silent average.", "Adwaaiit: risk 10/10, top Grable-Lytton score (40), yet γ ≈ 2.2."),
    ("DATA-QUALITY SIGNALS", "Flat BFI-2 or low retest → lower confidence: re-survey, or a more conservative default.", "Shree Charan: 3.00 on all five domains. Ayushi: retest 0.5."),
    ("OPENNESS & CONSCIENTIOUSNESS", "Openness → comfort with two mental accounts. Conscientiousness → will they keep rebalancing?", "Kartika: open (3.17) but less conscientious (2.83) → automate rebalancing."),
]
for i, (hd, body, ex) in enumerate(cards4):
    cx = 0.93 + (i % 2) * 5.8; cy = 2.2 + (i // 2) * 2.35
    card(s, cx, cy, 5.5, 2.15, name=f"Card {i+1}")
    textbox(s, cx + 0.2, cy + 0.12, 5.1, 0.4, hd, size=13, bold=True, color=INK, font="+mj-lt")
    textbox(s, cx + 0.2, cy + 0.55, 5.1, 0.95, body, size=14, color=INK)
    textbox(s, cx + 0.2, cy + 1.48, 5.1, 0.6, ex, size=12, color=TEAL_DARK)
speaker_tag(s, "Ayushi")
footer(s, "BFI-2: Soto & John (2017)")

# ================================================================== 13 PORTAL (legible, no holdings table)
s = S[12]
set_title(s, "A working robo-advisor: survey to portfolio in one sitting", size=TS)
remove(shape(s, "Table 4"))
pq = s.shapes.add_picture("shots/p_question.png", Inches(0.93), Inches(1.6), width=Inches(5.6)); pq.name = "Screenshot question"
pr = s.shapes.add_picture("shots/p_results.png", Inches(0.93), Inches(3.95), width=Inches(5.6)); pr.name = "Screenshot results"
for p_ in (pq, pr):
    p_.line.color.rgb = RGBColor(0xC9, 0xC6, 0xC8); p_.line.width = Pt(0.75)
steps = [("1", "Client takes the survey", "4 scales + 20 adaptive choices, 20–25 minutes"),
         ("2", "Instant, in-browser result", "EUT and BPT portfolios, the client's own utility and value curves, personality-aware advice"),
         ("3", "Evaluator view", "All five clients, every instrument and the full maths pre-loaded (#evaluate)")]
for i, (num, head, body) in enumerate(steps):
    y = 1.6 + i * 1.05
    textbox(s, 6.85, y, 0.5, 0.6, num, size=26, color=TEAL_DARK, font="+mj-lt")
    textbox(s, 7.35, y + 0.02, 5.0, 0.35, head, size=14, bold=True, color=INK)
    textbox(s, 7.35, y + 0.38, 5.0, 0.65, body, size=12, color=INK)
card(s, 6.85, 4.85, 5.45, 1.35, fill=TINT, name="Roadmap card")
textbox(s, 7.0, 4.93, 5.2, 1.25, [
    [("Production roadmap: ", {"bold": True}), ("adaptive engine + 15-item BFI-2-XS + goals, horizon and income questions → onboarding under 10 minutes, in line with SEBI risk profiling.", {})]], size=12)
textbox(s, 6.85, 6.3, 5.45, 0.6, [[("Live: ", {}), ("mba680-robo-advisor.vercel.app", {"color": TEAL_DARK, "bold": True}),
                                    ("  ·  matches our Python model to 3+ decimals", {})]], size=11, color=MUTED)
speaker_tag(s, "Ayushi")

# ================================================================== 14 SUMMARY
s = S[13]
set_title(s, "Summary", "Title 4")
fill_paras(shape(s, "Content Placeholder 5"), [
    (0, "EUT alone can't personalise a young, risk-tolerant group: all five get 100% of the same portfolio."),
    (0, "SP/A-BPT can, through loss aversion, once the safety account holds genuinely safe assets."),
    (0, "Personality belongs in how advice is delivered and how much the numbers are trusted."),
])
fill_paras(shape(s, "Content Placeholder 24"), [
    (0, "Next: debt in the safety account; stock caps"),
    (0, "Goals and risk-capacity questions"),
    (0, "Larger stakes to pin down γ"),
    (0, "Bigger, independent sample"),
])
speaker_tag(s, "Ayushi")

# ================================================================== 15 THANK YOU + QR
s = S[14]
set_title(s, "Thank you", "Title 3")
fill_paras(shape(s, "Text Placeholder 14"), [
    (0, "Adwaaiit Pande · Ayushi Mishra"),
    (0, "Robo-advisory portal:"),
    (0, "mba680-robo-advisor.vercel.app"),
    (0, "Questions?"),
])
qr_bg = s.shapes.add_shape(5, Inches(10.05), Inches(2.55), Inches(2.4), Inches(2.85))
qr_bg.fill.solid(); qr_bg.fill.fore_color.rgb = RGBColor(0xFF, 0xFF, 0xFF); qr_bg.line.fill.background(); qr_bg.shadow.inherit = False
qr_bg.name = "QR card"
s.shapes.add_picture("shots/qr_evaluate.png", Inches(10.25), Inches(2.7), Inches(2.0), Inches(2.0)).name = "QR evaluate view"
textbox(s, 10.1, 4.8, 2.3, 0.45, "Scan: full project view", size=12, color=INK, bold=True, align=PP_ALIGN.CENTER)

# notes are attached from notes_v2.json (the spoken script)
import json
for i, t in json.load(open("notes_v2.json")).items():
    notes(S[int(i)], t)
prs.save(OUT)
print("saved", OUT)
