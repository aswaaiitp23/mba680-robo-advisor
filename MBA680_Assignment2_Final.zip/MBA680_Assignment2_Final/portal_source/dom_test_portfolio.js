const fs = require("fs");
const { JSDOM } = require("jsdom");

const html = fs.readFileSync(__dirname + "/survey.html", "utf8");

function newWindow() {
  const dom = new JSDOM(html, { runScripts: "dangerously", resources: "usable", url: "https://example.com/" });
  const { window } = dom;
  window.claude = {
    use: async (name) => {
      if (name === "downloads") {
        return { save: async ({ filename, data }) => { window.__lastDownload = { filename, data }; return { status: "saved" }; } };
      }
      return null;
    },
  };
  return window;
}
function click(el) { el.dispatchEvent(new (el.ownerDocument.defaultView.Event)("click", { bubbles: true })); }
function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }

async function testIndividualFlow() {
  const window = newWindow();
  await wait(50);
  const doc = window.document;

  const nameInput = doc.getElementById("nameInput");
  nameInput.value = "Test Respondent";
  nameInput.dispatchEvent(new window.Event("input", { bubbles: true }));
  click(doc.getElementById("startBtn"));

  click(doc.querySelectorAll(".scale-btn")[7]); // anchor1 -> 7
  click(doc.querySelectorAll(".scale-btn")[3]); // anchor2 -> 3

  for (let i = 0; i < 13; i++) {
    const opt = doc.querySelector(".option-card");
    if (!opt) throw new Error(`Grable-Lytton item ${i}: no option-card found`);
    click(opt);
  }

  for (let i = 0; i < 6; i++) {
    const btns = doc.querySelectorAll(".scale-btn");
    if (btns.length < 4) throw new Error(`DOSPERT item ${i}: not enough scale buttons`);
    click(btns[3]);
  }

  for (let d = 0; d < 5; d++) {
    const rows = doc.querySelectorAll(".scale-row[data-idx]");
    if (rows.length !== 12) throw new Error(`BFI2 domain ${d}: expected 12 items, got ${rows.length}`);
    rows.forEach((row) => { click(row.querySelectorAll(".scale-btn")[2]); });
    const nextBtn = doc.getElementById("bfi2Next");
    if (nextBtn.disabled) throw new Error(`BFI2 domain ${d}: Continue still disabled after answering all items`);
    click(nextBtn);
  }

  for (let i = 0; i < 20; i++) {
    const optA = doc.getElementById("optA");
    const optB = doc.getElementById("optB");
    if (!optA || !optB) throw new Error(`Adaptive question ${i}: option buttons missing`);
    click(i % 2 === 0 ? optB : optA);
  }

  await wait(50);

  const doneHtml = doc.getElementById("app").innerHTML;
  if (!doneHtml.includes("That's everything")) throw new Error("Did not reach the 'done' screen after 20 adaptive questions");
  if (!doneHtml.includes("Your recommended portfolio")) throw new Error("Portfolio section not rendered on done screen");
  if (!doneHtml.includes("Top holdings")) throw new Error("Top holdings table not rendered on done screen");
  if (!doneHtml.includes("Expected Utility Theory")) throw new Error("EUT block not rendered on done screen");
  if (!doneHtml.includes("Behavioral Portfolio Theory")) throw new Error("BPT block not rendered on done screen");
  const indivCurves = doc.querySelectorAll("#app svg.pref-curve").length;
  if (indivCurves !== 4) throw new Error(`Expected 4 Step-4 curve charts on done screen, got ${indivCurves}`);
  const badPaths = [...doc.querySelectorAll("#app svg.pref-curve path")].filter((p) => /NaN|Infinity/.test(p.getAttribute("d") || "")).length;
  if (badPaths) throw new Error(`${badPaths} curve paths contain NaN/Infinity`);
  console.log("[individual flow] reached 'done' and rendered EUT + BPT + top-holdings + commentary + 4 Step-4 curve charts.");
}

async function testResearcherView() {
  const window = newWindow();
  await wait(50);
  const doc = window.document;

  const link = doc.getElementById("researcherLink");
  if (!link) throw new Error("researcherLink not found on intro screen");
  click(link);
  await wait(20);

  if (!doc.getElementById("fileInput")) throw new Error("Did not navigate to researcher screen");

  const path = require("path");
  const realDir = fs.existsSync(path.join(__dirname, "..", "python_pipeline")) ? path.join(__dirname, "..", "python_pipeline", "real_peer_data") : "/home/claude/pipeline/real_peer_data";
  const realFiles = ["shree-charan-risk-time-results.json", "kshitij-risk-time-results.json",
    "kartika-risk-time-results.json", "ayushi-risk-time-results.json", "adwaaiit-risk-time-results.json"];
  const fileObjs = realFiles.map((f) => {
    const text = fs.readFileSync(`${realDir}/${f}`, "utf8");
    return new window.File([text], f, { type: "application/json" });
  });

  const fileInput = doc.getElementById("fileInput");
  Object.defineProperty(fileInput, "files", { value: fileObjs, writable: false, configurable: true });
  fileInput.dispatchEvent(new window.Event("change", { bubbles: true }));
  await wait(150);

  const tableHtml = doc.getElementById("tableHost").innerHTML;
  const dashboardHtml = doc.getElementById("dashboardHost").innerHTML;
  if (!tableHtml.includes("Shree Charan")) throw new Error("Researcher table missing Shree Charan row");
  if (!tableHtml.includes("Kshitij")) throw new Error("Researcher table missing Kshitij row");
  if (!dashboardHtml.includes("Group portfolio dashboard")) throw new Error("Group dashboard header missing");
  if (!dashboardHtml.includes("Kshitij")) throw new Error("Group dashboard missing Kshitij");
  if (!dashboardHtml.includes("Adwaaiit Pande")) throw new Error("Group dashboard missing Adwaaiit Pande");
  const detailCount = doc.querySelectorAll("#dashboardHost details").length;
  if (detailCount !== 5) throw new Error(`Expected 5 per-person detail blocks, got ${detailCount}`);

  // Spot-check a known numeric value appears (Kshitij pooled gamma = -0.500)
  if (!dashboardHtml.includes("-0.500")) throw new Error("Kshitij's pooled gamma=-0.500 not found in dashboard table");

  console.log("[researcher view] loaded 5 real respondents, dashboard rendered with", detailCount, "detail blocks, numeric spot-check passed.");
}

async function testEvaluateView() {
  const window = newWindow();
  await wait(50);
  const doc = window.document;

  const link = doc.getElementById("evaluateLink");
  if (!link) throw new Error("evaluateLink not found on intro screen");
  click(link);
  await wait(20);

  const html = doc.getElementById("app").innerHTML;
  if (!html.includes("Full project walkthrough")) throw new Error("Evaluate screen did not render");
  if (!html.includes("Grable")) throw new Error("Grable-Lytton instrument section missing");
  if (!html.includes("DOSPERT")) throw new Error("DOSPERT instrument section missing");
  if (!html.includes("BFI-2")) throw new Error("BFI-2 instrument section missing");
  if (!html.includes("Prelec")) throw new Error("Adaptive engine math section missing");
  // all 5 embedded respondents must appear
  for (const name of ["Shree Charan", "Kshitij", "Kartika", "Ayushi", "Adwaaiit Pande"]) {
    if (!html.includes(name)) throw new Error(`Evaluate view missing respondent ${name}`);
  }
  // spot-check a known pooled numeric value (Kshitij pooled gamma = -0.500)
  if (!html.includes("-0.500")) throw new Error("Kshitij's pooled gamma=-0.500 not found in evaluate view");
  // per-person detail blocks
  const detailCount = doc.querySelectorAll("#app details").length;
  if (detailCount < 5 + 9) throw new Error(`Expected at least 14 <details> blocks (4 instrument/math + 1 BFI-2 domain x5 + 5 respondent breakdowns), got ${detailCount}`);

  // Key findings section present
  if (!html.includes("EUT saturates")) throw new Error("Key findings section (EUT saturation) missing");
  if (!html.includes("SP/A-BPT differentiates")) throw new Error("Key findings section (BPT differentiation) missing");
  if (!html.includes("G-Secs (risk-free")) throw new Error("BPT holdings table should list the G-Sec position (model v2)");
  if (!html.includes("loses money in at most 1 year in 20")) throw new Error("Safety-account description (Telser rule) missing");

  const evalCurves = doc.querySelectorAll("#app svg.pref-curve").length;
  if (evalCurves !== 4) throw new Error(`Expected 4 Step-4 curve charts in evaluate view, got ${evalCurves}`);
  const curvePaths = doc.querySelectorAll("#app svg.pref-curve path").length;
  // utility 5 + value 10 (gain+loss segments) + weighting 5 + discount 10 (jump + curve) = 30
  if (curvePaths !== 30) throw new Error(`Expected 30 curve paths for 5 respondents, got ${curvePaths}`);
  const badP = [...doc.querySelectorAll("#app svg.pref-curve path")].filter((p) => /NaN|Infinity/.test(p.getAttribute("d") || "")).length;
  if (badP) throw new Error(`${badP} evaluate-view curve paths contain NaN/Infinity`);
  if (!html.includes("identification caveat")) throw new Error("gamma identification caveat missing");
  if (html.includes("not yet submitted")) throw new Error("stale 'not yet submitted' text still present");
  console.log("[evaluate view] rendered instruments, math, all 5 embedded respondents, 4 Step-4 curve charts (30 paths), and key findings with", detailCount, "<details> blocks.");

  // Direct-link (hash) entry: a fresh load with #evaluate in the URL should
  // land straight on the evaluate screen, for sharing a direct link.
  const dom2 = new (require("jsdom").JSDOM)(html_source(), { runScripts: "dangerously", resources: "usable", url: "https://example.com/#evaluate" });
  dom2.window.claude = { use: async () => ({ save: async () => ({ status: "saved" }) }) };
  await wait(50);
  const html2 = dom2.window.document.getElementById("app").innerHTML;
  if (!html2.includes("Full project walkthrough")) throw new Error("#evaluate direct-link entry did not land on the evaluate screen");
  console.log("[evaluate view] #evaluate direct link lands on the evaluate screen without any clicks.");
}
function html_source() { return fs.readFileSync(__dirname + "/survey.html", "utf8"); }

(async () => {
  await testIndividualFlow();
  await testResearcherView();
  await testEvaluateView();
  console.log("\nALL DOM TESTS PASSED");
})().catch((e) => { console.error("DOM TEST FAILED:", e); process.exit(1); });
