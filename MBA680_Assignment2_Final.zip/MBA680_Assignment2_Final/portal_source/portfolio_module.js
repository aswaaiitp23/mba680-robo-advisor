/* =========================================================================
   PORTFOLIO — EUT (Expected Utility Theory) and SP/A-BPT (Behavioral
   Portfolio Theory / mental accounts) construction, ported faithfully from
   robo_advisory/portfolio/{eut,bpt}.py. Operates on the REAL 66-stock
   Markowitz Portfolio Project asset universe (mu, Sigma, rf), embedded as
   UNIVERSE_DATA below (see real_asset_universe_standard_lambda/meta.json
   in the Python pipeline for full derivation and disclosure).
   ========================================================================= */

// ---- Linear algebra: Cholesky decomposition + solve (Sigma is symmetric PD) ----
function cholesky(A) {
  const n = A.length;
  const L = Array.from({ length: n }, () => new Float64Array(n));
  for (let i = 0; i < n; i++) {
    for (let j = 0; j <= i; j++) {
      let sum = 0;
      for (let k = 0; k < j; k++) sum += L[i][k] * L[j][k];
      if (i === j) {
        const val = A[i][i] - sum;
        L[i][j] = Math.sqrt(Math.max(val, 1e-14));
      } else {
        L[i][j] = (A[i][j] - sum) / L[j][j];
      }
    }
  }
  return L;
}
function choleskySolve(L, b) {
  const n = L.length;
  const y = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    let sum = b[i];
    for (let k = 0; k < i; k++) sum -= L[i][k] * y[k];
    y[i] = sum / L[i][i];
  }
  const x = new Float64Array(n);
  for (let i = n - 1; i >= 0; i--) {
    let sum = y[i];
    for (let k = i + 1; k < n; k++) sum -= L[k][i] * x[k];
    x[i] = sum / L[i][i];
  }
  return x;
}
function matVec(A, v) {
  const n = A.length;
  const out = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0;
    const row = A[i];
    for (let j = 0; j < n; j++) s += row[j] * v[j];
    out[i] = s;
  }
  return out;
}
function dot(a, b) {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += a[i] * b[i];
  return s;
}

/**
 * Long-only, fully-invested tangency-style weights: maximize
 * (w'mu - threshold) / sqrt(w'Sigma w)  s.t. sum(w)=1, w>=0.
 *
 * threshold=rf gives the classic tangency portfolio (eut.py's
 * tangency_weights); any other threshold gives the safety-first /
 * SF-ratio-maximizing portfolio for that threshold (bpt.py's
 * safety_first_weights). Both share the SAME objective shape, so one
 * routine serves both, exactly mirroring how the Python bpt.py reuses the
 * same optimization for both mental-account layers.
 *
 * Solved by active-set elimination, not a crude clip-and-renormalize: this
 * problem is a linear-fractional program that a Charnes-Cooper substitution
 * turns into a convex QP (minimize w'Sigma w s.t. w'(mu-threshold)=1, w>=0),
 * and repeatedly dropping the most-negative-weight asset and re-solving the
 * equality-constrained subproblem on the remaining assets is a standard
 * active-set method for that QP -- it converges to the SAME constrained
 * optimum scipy's SLSQP finds in bpt.py (verified against the Python
 * pipeline's own output in test_portfolio_parity.js), unlike a simple clip.
 */
function tangencyStyleWeights(mu, Sigma, threshold) {
  const n = mu.length;
  let active = Array.from({ length: n }, (_, i) => i);
  for (let iter = 0; iter < n; iter++) {
    const m = active.length;
    const subExcess = active.map((i) => mu[i] - threshold);
    const subSigma = active.map((i) => active.map((j) => Sigma[i][j]));
    const subL = cholesky(subSigma);
    const raw = choleskySolve(subL, subExcess);
    let minVal = Infinity, minPos = -1;
    for (let k = 0; k < m; k++) if (raw[k] < minVal) { minVal = raw[k]; minPos = k; }
    if (minVal >= -1e-9 || m === 1) {
      // all non-negative (within tolerance): normalize and map back to full n-vector
      let sum = 0;
      for (let k = 0; k < m; k++) sum += Math.max(raw[k], 0);
      const full = new Array(n).fill(0);
      if (sum <= 1e-12) {
        // degenerate fallback: equal-weight the active set
        for (let k = 0; k < m; k++) full[active[k]] = 1 / m;
      } else {
        for (let k = 0; k < m; k++) full[active[k]] = Math.max(raw[k], 0) / sum;
      }
      return full;
    }
    // drop the most-negative-weight asset, resolve on the shrunk active set
    active = active.filter((_, k) => k !== minPos);
  }
  // should not reach here, but fail safe to equal weight
  return mu.map(() => 1 / n);
}

function eutAllocation(mu, Sigma, rf, gamma) {
  gamma = Math.max(gamma, 0.05); // EUT two-fund formula requires gamma>0
  const wTan = tangencyStyleWeights(mu, Sigma, rf);
  const excess = mu.map((m) => m - rf);
  const tangencyExcessReturn = dot(wTan, excess);
  const SigmaWtan = matVec(Sigma, wTan);
  const tangencyVar = dot(wTan, SigmaWtan);
  let riskyFraction = tangencyExcessReturn / (gamma * tangencyVar);
  const riskyFractionUnclipped = riskyFraction;
  riskyFraction = Math.min(Math.max(riskyFraction, 0), 1); // long-only, no leverage
  return {
    riskyWeights: wTan,
    riskyFraction,
    riskyFractionUnclipped,
    cashFraction: 1 - riskyFraction,
    expectedReturn: rf + riskyFraction * tangencyExcessReturn,
    volatility: riskyFraction * Math.sqrt(tangencyVar),
  };
}

function safetyFirstWeights(mu, Sigma, threshold) {
  const w = tangencyStyleWeights(mu, Sigma, threshold);
  const ret = dot(w, mu);
  const SigmaW = matVec(Sigma, w);
  const vol = Math.sqrt(Math.max(dot(w, SigmaW), 1e-12));
  return { weights: w, expectedReturn: ret, volatility: vol, sfRatio: (ret - threshold) / vol, threshold };
}

function safetyCapitalFractionFromLambda(lam, lamLo = 1.0, lamHi = 4.0, fracLo = 0.3, fracHi = 0.8) {
  let t = (lam - lamLo) / (lamHi - lamLo);
  t = Math.min(Math.max(t, 0), 1);
  return fracLo + t * (fracHi - fracLo);
}

function percentile(arr, p) {
  const sorted = [...arr].sort((a, b) => a - b);
  const idx = (p / 100) * (sorted.length - 1);
  const lo = Math.floor(idx), hi = Math.ceil(idx);
  if (lo === hi) return sorted[lo];
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
}

function bptAllocation(mu, Sigma, rf, aspirationThreshold, safetyCapitalFrac, lossAversion) {
  const safety = safetyFirstWeights(mu, Sigma, rf);
  const aspiration = safetyFirstWeights(mu, Sigma, aspirationThreshold);
  const combinedWeights = safety.weights.map(
    (w, i) => safetyCapitalFrac * w + (1 - safetyCapitalFrac) * aspiration.weights[i]
  );
  const combinedReturn = dot(combinedWeights, mu);
  const SigmaC = matVec(Sigma, combinedWeights);
  const combinedVol = Math.sqrt(dot(combinedWeights, SigmaC));
  return {
    safetyLayer: safety, aspirationLayer: aspiration, safetyCapitalFrac,
    combinedWeights, combinedExpectedReturn: combinedReturn, combinedVolatility: combinedVol,
    lossAversionUsed: lossAversion,
  };
}

/**
 * Full personalized portfolio construction for one respondent's pooled
 * (gamma, lambda), against the embedded real asset universe. Mirrors
 * pipeline.py's _construct_portfolios exactly.
 */
function constructPortfolios(universe, gamma, lam) {
  const { mu, Sigma, rf } = universe;
  const eut = eutAllocation(mu, Sigma, rf, gamma);
  const safetyCapitalFrac = safetyCapitalFractionFromLambda(lam);
  const aspirationThreshold = percentile(mu, 75);
  const bpt = bptAllocation(mu, Sigma, rf, aspirationThreshold, safetyCapitalFrac, lam);
  return { eut, bpt, gamma, lam };
}

function prepareUniverse(raw) {
  return { tickers: raw.tickers, mu: raw.mu, Sigma: raw.sigma, rf: raw.rf };
}
