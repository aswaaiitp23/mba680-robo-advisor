const fs = require("fs");
const universeRaw = JSON.parse(fs.readFileSync(__dirname + "/universe_data.json", "utf8"));
eval(fs.readFileSync(__dirname + "/portfolio_module.js", "utf8"));

const universe = prepareUniverse(universeRaw);

// Known real respondents' pooled (gamma, lambda) from the Python run
// (outputs/real_peers_steps2to4and6.csv), and the Python-computed Step 5b
// results (outputs/real_peers_step5b_standard_lambda.csv) to check against.
const respondents = [
  { name: "Shree Charan", gamma: 2.211866, lam: 1.000, py_riskyFrac: 1.0, py_safetyFrac: 0.3000, py_bptRet: 0.161926, py_bptVol: 0.294563, py_unclipped: 1.130267 },
  { name: "Kshitij",      gamma: 0.050000, lam: 1.600, py_riskyFrac: 1.0, py_safetyFrac: 0.4000, py_bptRet: 0.157669, py_bptVol: 0.271155, py_unclipped: 50.000000 },
  { name: "Kartika",      gamma: 0.200000, lam: 1.000, py_riskyFrac: 1.0, py_safetyFrac: 0.3000, py_bptRet: 0.161926, py_bptVol: 0.294563, py_unclipped: 12.500000 },
  { name: "Ayushi",       gamma: 2.206402, lam: 1.009, py_riskyFrac: 1.0, py_safetyFrac: 0.3015, py_bptRet: 0.161863, py_bptVol: 0.294207, py_unclipped: 1.133066 },
  { name: "Adwaaiit Pande", gamma: 2.187278, lam: 1.015, py_riskyFrac: 1.0, py_safetyFrac: 0.3025, py_bptRet: 0.161820, py_bptVol: 0.293969, py_unclipped: 1.142973 },
];

let allOk = true;
for (const r of respondents) {
  const result = constructPortfolios(universe, r.gamma, r.lam);
  const checks = [
    ["riskyFraction", result.eut.riskyFraction, r.py_riskyFrac, 1e-4],
    ["safetyCapitalFrac", result.bpt.safetyCapitalFrac, r.py_safetyFrac, 1e-3],
    ["bptCombinedReturn", result.bpt.combinedExpectedReturn, r.py_bptRet, 1e-3],
    ["bptCombinedVol", result.bpt.combinedVolatility, r.py_bptVol, 1e-3],
    ["riskyFractionUnclipped", result.eut.riskyFractionUnclipped, r.py_unclipped, Math.abs(r.py_unclipped) * 0.01 + 1e-3],
  ];
  console.log(`\n${r.name} (gamma=${r.gamma}, lam=${r.lam}):`);
  for (const [label, jsVal, pyVal, tol] of checks) {
    const diff = Math.abs(jsVal - pyVal);
    const ok = diff <= tol;
    allOk = allOk && ok;
    console.log(`  ${label.padEnd(24)} JS=${jsVal.toFixed(6).padStart(12)}  PY=${String(pyVal).padStart(12)}  diff=${diff.toExponential(2)}  ${ok ? "OK" : "MISMATCH"}`);
  }
  // sanity: weights sum to 1, are non-negative
  const wsum = result.eut.riskyWeights.reduce((a, b) => a + b, 0);
  const wmin = Math.min(...result.eut.riskyWeights);
  console.log(`  EUT risky weights sum=${wsum.toFixed(6)} min=${wmin.toExponential(2)}`);
  const bsum = result.bpt.combinedWeights.reduce((a, b) => a + b, 0);
  console.log(`  BPT combined weights sum=${bsum.toFixed(6)}`);
}

console.log("\n" + (allOk ? "ALL CHECKS PASSED" : "SOME CHECKS FAILED"));
process.exit(allOk ? 0 : 1);
