/* Parity test: the portal's in-browser portfolio engine (survey.html) against
   the Python reference pipeline (model version 2: 10% single-stock cap,
   G-Sec + tangency safety account sized by Telser's rule, capped Roy
   aspiration account). Python results are read from the pipeline's outputs. */
const fs = require("fs");
const path = require("path");

const html = fs.readFileSync(__dirname + "/survey.html", "utf8");
let script = html.match(/<script>([\s\S]*)<\/script>/)[1];
script = script.replace(/\nrender\(\);\s*$/, "\n");
script = "const document = { getElementById: () => null, createElement: () => ({}) };\nconst location = { hash: \"\" };\n" + script;
script += "\nmodule.exports = { constructPortfolios, universeLayers, UNIVERSE, POSITION_CAP };\n";
fs.writeFileSync(__dirname + "/_parity_test_module.js", script);
const { constructPortfolios, universeLayers, UNIVERSE, POSITION_CAP } = require("./_parity_test_module.js");

const PIPE = fs.existsSync(path.join(__dirname, "..", "python_pipeline")) ? path.join(__dirname, "..", "python_pipeline") : "/home/claude/pipeline";
const outDir = path.join(PIPE, "outputs");
const csv = fs.readFileSync(path.join(outDir, "real_peers_step5b_standard_lambda.csv"), "utf8").trim().split("\n");
const head = csv[0].split(",");
const py = csv.slice(1).map((line) => Object.fromEntries(line.split(",").map((v, i) => [head[i], i === 0 ? v : Number(v)])));
const layers = JSON.parse(fs.readFileSync(path.join(outDir, "portfolio_layers_standard_lambda.json"), "utf8"));

let allOk = true;
const check = (label, jsVal, pyVal, tol) => {
  const diff = Math.abs(jsVal - pyVal), ok = diff <= tol;
  allOk = allOk && ok;
  console.log(`  ${label.padEnd(26)} JS=${jsVal.toFixed(6).padStart(12)}  PY=${pyVal.toFixed(6).padStart(12)}  diff=${diff.toExponential(2)}  ${ok ? "OK" : "MISMATCH"}`);
};

console.log("Universe-level building blocks:");
const t0 = Date.now();
const L = universeLayers(UNIVERSE);
console.log(`  (solved in browser code in ${Date.now() - t0} ms)`);
const maxDiff = (a, b) => Math.max(...a.map((v, i) => Math.abs(v - b[i])));
check("tangency weights maxdiff", maxDiff(L.wT, layers.T.weights), 0, 2e-5);
check("aspiration weights maxdiff", maxDiff(L.wA, layers.A.weights), 0, 2e-5);
check("tangency return", L.T.ret, layers.T.ret, 1e-6);
check("tangency vol", L.T.vol, layers.T.vol, 1e-6);
check("aspiration return", L.A.ret, layers.A.ret, 1e-6);
check("aspiration vol", L.A.vol, layers.A.vol, 1e-6);
check("aspiration threshold", L.aspirationThreshold, layers.A.threshold, 1e-6);
check("safety equity share", L.safetyEquityShare, layers.safety_equity_share, 1e-6);
const capOk = Math.max(...L.wT, ...L.wA) <= POSITION_CAP + 1e-9 && Math.min(...L.wT, ...L.wA) >= 0;
console.log(`  cap respected & long-only: ${capOk ? "OK" : "FAIL"}`); allOk = allOk && capOk;

for (const r of py) {
  const res = constructPortfolios(UNIVERSE, r.gamma_pooled, r.lambda_pooled);
  console.log(`\n${r.respondent} (gamma=${r.gamma_pooled.toFixed(3)}, lambda=${r.lambda_pooled.toFixed(3)}):`);
  check("EUT risky fraction", res.eut.riskyFraction, r.EUT_risky_fraction, 1e-6);
  check("EUT unclipped", res.eut.riskyFractionUnclipped, r.EUT_risky_fraction_UNCLIPPED, Math.abs(r.EUT_risky_fraction_UNCLIPPED) * 1e-5);
  check("EUT return", res.eut.expectedReturn, r.EUT_expected_return, 1e-6);
  check("EUT vol", res.eut.volatility, r.EUT_volatility, 1e-6);
  check("EUT P(loss)", res.eut.probLoss, r.EUT_prob_loss, 1e-5);
  check("BPT safety fraction", res.bpt.safetyCapitalFrac, r.BPT_safety_capital_frac, 1e-6);
  check("BPT G-Sec weight", res.bpt.gsecWeight, r.BPT_gsec_weight, 1e-6);
  check("BPT return", res.bpt.combinedExpectedReturn, r.BPT_combined_return, 1e-6);
  check("BPT vol", res.bpt.combinedVolatility, r.BPT_combined_volatility, 1e-6);
  check("BPT P(loss)", res.bpt.probLoss, r.BPT_prob_loss, 1e-5);
  check("BPT max single stock", Math.max(...res.bpt.combinedWeights), r.BPT_max_single_stock, 2e-5);
  const total = res.bpt.combinedWeights.reduce((a, b) => a + b, 0) + res.bpt.gsecWeight;
  check("BPT stocks + G-Secs", total, 1, 1e-9);
}
console.log("\n" + (allOk ? "ALL CHECKS PASSED" : "SOME CHECKS FAILED"));
process.exit(allOk ? 0 : 1);
