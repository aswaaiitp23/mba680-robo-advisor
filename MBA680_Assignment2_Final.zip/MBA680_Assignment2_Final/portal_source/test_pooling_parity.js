const fs = require("fs");
const path = require("path");

// Load the extracted script (same as syntax-check does) so we get poolGroup,
// constructPortfolios, UNIVERSE etc. in this Node context without a DOM.
const html = fs.readFileSync(__dirname + "/survey.html", "utf8");
const scriptMatch = html.match(/<script>([\s\S]*)<\/script>/);
let script = scriptMatch[1];
// The real script calls render() at module load time and references `document`;
// stub those out for a headless Node run of just the math functions.
script = script.replace(/\nrender\(\);\s*$/, "\n");
script = "const document = { getElementById: () => null, createElement: () => ({}) };\nconst location = { hash: \"\" };\n" + script;
// Expose the functions/consts we need onto module.exports at the end.
script += "\nmodule.exports = { poolGroup, constructPortfolios, UNIVERSE, ciToVariance };\n";
fs.writeFileSync(__dirname + "/_pooling_test_module.js", script);

const { poolGroup, constructPortfolios, UNIVERSE } = require("./_pooling_test_module.js");

// Load the 5 real (corrected-attribution) respondent files exactly as the
// Python pipeline's real_peer_data/ does.
const dataDir = "/home/claude/pipeline/real_peer_data";
const files = [
  "shree-charan-risk-time-results.json",
  "kshitij-risk-time-results.json",
  "kartika-risk-time-results.json",
  "ayushi-risk-time-results.json",
  "adwaaiit-risk-time-results.json",
];
const rows = files.map((f) => JSON.parse(fs.readFileSync(path.join(dataDir, f), "utf8")));

const pooled = poolGroup(rows, 0.30);

// Expected pooled (gamma, lambda) from the Python run (outputs/real_peers_steps2to4and6.csv)
const expected = {
  "Shree Charan": { gamma: 2.211866, lam: 1.000 },
  "Kshitij": { gamma: -0.500000, lam: 1.600 },
  "Kartika": { gamma: 0.200000, lam: 1.000 },
  "Ayushi": { gamma: 2.206402, lam: 1.009 },
  "Adwaaiit Pande": { gamma: 2.187278, lam: 1.015 },
};

let allOk = true;
rows.forEach((r, i) => {
  const exp = expected[r.name];
  const gDiff = Math.abs(pooled[i].gamma.pooled - exp.gamma);
  const lDiff = Math.abs(pooled[i].lam.pooled - exp.lam);
  const ok = gDiff < 1e-3 && lDiff < 1e-3;
  allOk = allOk && ok;
  console.log(`${r.name.padEnd(16)} gamma_pooled JS=${pooled[i].gamma.pooled.toFixed(6)} PY=${exp.gamma.toFixed(6)} diff=${gDiff.toExponential(2)} | lam_pooled JS=${pooled[i].lam.pooled.toFixed(6)} PY=${exp.lam.toFixed(6)} diff=${lDiff.toExponential(2)} ${ok ? "OK" : "MISMATCH"}`);
});

// Also sanity-check the portfolio construction runs end to end for the pooled group
rows.forEach((r, i) => {
  const port = constructPortfolios(UNIVERSE, pooled[i].gamma.pooled, pooled[i].lam.pooled);
  const wsum = port.bpt.combinedWeights.reduce((a, b) => a + b, 0);
  if (Math.abs(wsum - 1) > 1e-6) { console.log(`  BPT weights for ${r.name} do not sum to 1: ${wsum}`); allOk = false; }
});

console.log("\nUniverse loaded:", UNIVERSE.tickers.length, "tickers, rf=", UNIVERSE.rf);
console.log(allOk ? "ALL POOLING CHECKS PASSED" : "SOME CHECKS FAILED");
process.exit(allOk ? 0 : 1);
