const fs = require("fs");
const { TextRun, Paragraph, AlignmentType, ImageRun } = require("docx");
const { H1, H2, H3, P, PR, bullet, caption, table, hrParagraph, pageBreak, pct, num } = require("./build.js");
const { PORTFOLIO_RESULTS, TOP_HOLDINGS, RESPONDENTS, LAYERS, ASPIRATION_HOLDINGS } = require("./data.js");
const LAM_BY_NAME = Object.fromEntries(RESPONDENTS.map(r => [r.name, r.lamPooled]));

function eq(text) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 160 },
    children: [new TextRun({ text, italics: true, size: 22 })],
  });
}

const section4 = [
  H1("4. Portfolio Recommendations (Step 5)"),
  P("We construct a personalized portfolio for each of the five respondents under both Expected Utility Theory and SP/A Behavioral Portfolio Theory, against the same 66-stock NSE asset universe, three-year annualized covariance matrix, and risk-free rate (6.75%) we used in our Markowitz Portfolio Project."),

  H2("4.1 Deriving expected returns for the asset universe"),
  P("Our Markowitz Portfolio Project workbook (MBA680_Portfolio_Workbook_Final.xlsx) exposes the full 66×66 covariance matrix and the final weights, expected return (48.41%), and volatility (18.89%) of that project's own optimized max-Sharpe portfolio P, but does not expose a per-asset expected-return (μ) vector directly — only Σ and an already-optimized outcome. We therefore back-solved μ via Black-Litterman-style reverse optimization, μ = rf·1 + λ_mkt·Σ·w_ref, and built and disclosed two versions:"),
  bullet([new TextRun({ text: "As-implied version ", bold: true }), new TextRun({ text: "— uses portfolio P itself as the reference weight vector, with λ_mkt = (E[R_P]−rf)/σ²_P = 11.68 (self-consistent, but P's Sharpe ratio of 2.21 is in-sample-optimized — the classic Michaud (1989) “Markowitz optimization enigma” — so this λ_mkt is unrealistically high)." })]),
  bullet([new TextRun({ text: "Standard-λ version (used for all results below) ", bold: true }), new TextRun({ text: "— uses a market-cap-weighted 66-stock portfolio as the reference and a conventional λ_mkt = 2.5 (He & Litterman (1999)'s standard “representative investor” default), giving a realistic implied market Sharpe ratio of 0.40 and a μ range of 9.05%–17.6% (cross-sectional mean 13.7%). All portfolio figures in this report use this version." })]),
  P("We document this derivation and both versions in our pipeline's real_asset_universe_standard_lambda/meta.json.", { spacingAfter: 240 }),

  H2("4.2 EUT results and the two-fund separation finding"),
  P("Under EUT, the risky sleeve is the tangency portfolio — the portfolio maximizing the Sharpe ratio (w'μ − rf)/√(w'Σw) — and the two-fund separation theorem says every investor holds the SAME tangency composition, differing only in how much wealth goes to it versus the risk-free asset (G-Secs at rf), via risky fraction = (tangency excess return)/(γ·tangency variance), clipped to [0, 1] for a long-only, no-leverage investor."),
  P("We impose two constraints on the tangency portfolio: long-only and fully invested, and no single stock above 10%. The 10% cap follows the single-company limit SEBI places on mutual fund schemes (SEBI Mutual Funds Regulations, 1996, Seventh Schedule) and guards against the error-maximization problem of Michaud (1989). Without it, the tangency portfolio puts 12.97% in TCS. We solve the capped problem exactly through its convex reformulation, minimize y'Σy subject to (μ − rf)'y = 1, y ≥ 0 and y_i ≤ 0.10·Σy, with w = y/Σy. The cap binds only on TCS, holds all 66 stocks, and costs almost nothing: the Sharpe ratio falls from 0.4019 to 0.4017."),
  table(
    ["Respondent", "Equity share", "Expected return", "Volatility", "P(losing year)", "Unclipped share"],
    PORTFOLIO_RESULTS.map(r => [r.name, pct(r.riskyFrac, 0), pct(r.eutRet, 2), pct(r.eutVol, 2), pct(r.eutPLoss, 1), num(r.unclipped, 2) + "×"]),
    [1880, 1500, 1700, 1500, 1700, 1800]
  ),
  caption("Table 4.1 — EUT allocation results (standard-λ universe, 10% single-stock cap). P(losing year) is the probability of a negative one-year return assuming normal returns. “Unclipped share” is λ_T/γ before the long-only ceiling of 100% is applied."),
  P("Every respondent's clipped risky fraction is 100%, and — because the tangency portfolio's composition is fixed by the universe alone (μ, Σ, rf), not by any respondent's parameters — the EUT expected return (13.24%) and volatility (16.17%) are identical for all five respondents too. The unclipped column shows why. The capped tangency portfolio's market price of risk is λ_T = (μ_T − rf)/σ_T² = 2.48, so the unclipped risky fraction is λ_T/γ for each respondent's pooled γ (e.g. Kartika: 2.48/0.20 = 12.4×; Adwaaiit Pande: 2.48/2.187 ≈ 1.14×). Every pooled γ in this group (0.05–2.2) is below 2.48, so the long-only constraint binds identically for everyone, and EUT prescribes the same portfolio to the entire peer group regardless of how different their elicited risk aversion is. Kshitij's case is the most extreme: his raw elicited γ is negative (−0.50, formally outside the domain of concave EUT), floored to 0.05 for the arithmetic, which mechanically produces the largest unclipped ratio (49.7×) in the table — a genuine EUT/CRRA boundary case, not a rounding error."),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 40 }, keepNext: true,
    children: [new ImageRun({ type: "png", data: fs.readFileSync("/home/claude/step4_graphs/out/fig_eut_share_vs_gamma.png"), transformation: { width: 520, height: Math.round(520 * 1040 / 1639) },
      altText: { title: "EUT risky share vs gamma", description: "EUT risky share vs gamma", name: "fig_eut_share" } })] }),
  caption("Figure 4.1 — Long-only EUT risky share, min(λ_T/γ, 100%), against risk aversion γ (λ_T = 2.48 for the 10%-capped tangency portfolio). All five respondents sit on the flat 100% segment; the shaded band is the range in which the elicitation engine cannot pin down γ's exact size (Section 7)."),
  P("We read this saturation as itself a substantive Step 6-relevant finding: for a peer group of moderately risk-tolerant young investors evaluated against a realistically-calibrated market Sharpe ratio, EUT with a long-only constraint is a poor basis for a personalized robo-advisory recommendation — it collapses to the same “put everything into the tangency portfolio” advice for everyone. This is what motivates our use of SP/A-BPT (Section 4.3), which does differentiate this same group.", { spacingAfter: 0 }),
  pageBreak(),

  H2("4.3 SP/A-BPT results: two mental accounts"),
  P("SP/A-BPT (Das, Markowitz, Scheid & Statman, 2010) builds the portfolio from mental accounts, each defined by its own goal: a threshold return and the largest probability of missing it that the investor will accept. We use two accounts:"),
  bullet([new TextRun({ text: "Safety account ", bold: true }), new TextRun({ text: "— goal: do not lose money in a bad year. It may hold G-Secs (risk-free at rf = 6.75%) and the capped tangency portfolio T. Following Telser's (1955) safety-first rule, it maximizes expected return subject to P(r < 0%) ≤ 5%. With a share e in T, the account's return is rf + e(μ_T − rf) and its volatility e·σ_T, so under normality the largest feasible share is:" })]),
  eq("e* = min( 1, (rf − 0) / (1.645·σ_T − (μ_T − rf)) ) = 0.0675 / (1.645 × 16.17% − 6.49%) = 33.6%"),
  P("The safety account therefore holds 66.4% G-Secs and 33.6% in T, with an expected return of 8.93% and volatility of 5.43%; by construction it loses money in at most 1 year in 20.", { spacingAfter: 100 }),
  bullet([new TextRun({ text: "Aspiration account ", bold: true }), new TextRun({ text: "— goal: the best chance of beating an ambitious target, H_a = 15.31% (the 75th percentile of the universe's expected returns). This is Roy's (1952) safety-first portfolio for H_a — maximize (w'μ − H_a)/√(w'Σw), which under normality maximizes P(r ≥ H_a) — long-only and with the same 10% cap. It holds 11 stocks, with an expected return of 16.53% and volatility of 27.18%." })]),
  bullet([new TextRun({ text: "Split between the accounts ", bold: true }), new TextRun({ text: "— set by each respondent's own loss aversion: safety share s = 0.30 + 0.1667×(λ−1), clipped to [0.30, 0.80], so 30% at λ = 1.0 rising to 80% at λ = 4.0. The client's holdings are then G-Secs = s(1 − e*) and stocks = s·e*·T + (1 − s)·A." })]),
  table(
    ["Respondent", "λ pooled", "Safety account", "G-Secs", "Expected return", "Volatility", "P(losing year)"],
    PORTFOLIO_RESULTS.map(r => [r.name, num(LAM_BY_NAME[r.name], 3), pct(r.safetyFrac, 1), pct(r.gsec, 1), pct(r.bptRet, 2), pct(r.bptVol, 2), pct(r.bptPLoss, 1)]),
    [1780, 1100, 1450, 1150, 1600, 1400, 1600],
  ),
  caption("Table 4.2 — SP/A-BPT allocation results (standard-λ universe). “G-Secs” is the share of total wealth; the rest is in stocks."),
  P("Unlike EUT, BPT differentiates this peer group, and in the direction SP/A theory intends. Because the split is driven by loss aversion λ rather than risk aversion γ, Kshitij — whose λ = 1.6 is the highest in the group — receives the most protective recommendation: 40% in the safety account, 26.6% of his wealth in G-Secs, and the lowest volatility (18.28%) and expected return (13.49%). Shree Charan and Kartika (both λ = 1.0, the grid minimum) receive the least protective one (30% safety, 19.9% G-Secs, 20.50% volatility, 14.25% expected return), and Ayushi and Adwaaiit Pande sit just between, tracking their λ of 1.009 and 1.015. In rupees, Kshitij's ₹1 crore splits into a ₹40 lakh safety account (₹26.6 lakh in G-Secs, ₹13.4 lakh in the tangency portfolio) and a ₹60 lakh aspiration account; the safety account is expected to end any year above ₹40 lakh in 19 years out of 20."),
  P("Our first version of this model did not achieve this, and we changed it. That version solved both accounts with Roy's ratio over an all-equity universe and no position limits. Its safety layer was simply the tangency portfolio (16.1% volatility), and its aspiration layer put 60% in Central Bank of India and 34% in IRFC. The combined portfolio had 27–29% volatility for every respondent — riskier than EUT even for the loss-averse Kshitij — and about 42% of a typical client's wealth in one stock. Two changes fixed both problems: letting the safety account hold G-Secs under an explicit shortfall rule, as Das et al. (2010) define mental accounts, and the 10% cap. BPT volatility fell to 18–21%, the largest single-stock position fell from about 42% to 7.6% of wealth, and risk now falls steadily as λ rises."),
  P("BPT still carries more total risk than the EUT portfolio (18–21% against 16.17% volatility; a 23–24% chance of a losing year against 21%), and we think this is consistent rather than a flaw. Four of our five respondents are barely loss-averse (λ ≈ 1), so about 70% of their money goes to the aspiration account. And EUT only looks safer because the no-leverage rule pins it at 100% equities: without that rule, EUT would put 112–114% in equities for the three γ ≈ 2.2 respondents, a volatility of 18.2–18.4%, close to BPT's; for Kartika and Kshitij it would want 12× and 50× leverage. What BPT adds is not lower total risk but a ring-fenced account with an explicit floor, which is the kind of protection a loss-averse client actually asks for."),
  table(
    ["Design setting", "G-Secs in safety account", "BPT volatility, λ = 1.0", "BPT volatility, Kshitij (λ = 1.6)"],
    [
      ["Base: H_a at 75th percentile, P(loss) ≤ 5%", "66.4%", "20.50%", "18.28%"],
      ["Aspiration target at the median", "66.4%", "20.40%", "18.20%"],
      ["Aspiration target at the 90th percentile", "66.4%", "20.65%", "18.40%"],
      ["Safety account P(loss) ≤ 1%", "78.3%", "19.98%", "17.58%"],
      ["Safety account P(loss) ≤ 10%", "52.6%", "21.12%", "19.11%"],
    ],
    [3780, 2100, 2100, 2100],
  ),
  caption("Table 4.3 — Sensitivity of the BPT results to our two design choices (from outputs/real_peers_step5b_bpt_sensitivity.csv). The aspiration target barely matters; the safety account's shortfall probability moves volatility by about one percentage point either way."),
  P("A further structural point: like the EUT tangency portfolio, the three building blocks — G-Secs, the capped tangency portfolio T and the aspiration portfolio A — are fixed by the universe alone and do not depend on any respondent's γ or λ. What is personalized is the capital allocation between them: γ sets the EUT equity share and λ sets the BPT split. Personalization in this asset universe therefore never works by picking different stocks for different people.", { spacingAfter: 0 }),
  pageBreak(),

  H2("4.4 Holdings and diversification"),
  P("Because the tangency portfolio is the same for all five respondents (it is the whole EUT equity sleeve and the equity part of every BPT safety account), its top holdings are reported once. Weights are shares of the tangency portfolio itself."),
  table(
    ["Rank", "Ticker", "Weight in tangency portfolio"],
    TOP_HOLDINGS.map((h, i) => [String(i + 1), h.ticker, pct(h.weight, 2)]),
    [1200, 4600, 4280]
  ),
  caption("Table 4.4 — Top 10 of the 66 holdings of the 10%-capped tangency portfolio (standard-λ universe). TCS sits at the 10% cap (12.97% uncapped)."),
  P("The aspiration account is more concentrated, as a growth account should be, but the cap now forces at least ten names:"),
  table(
    ["Rank", "Ticker", "Weight in aspiration account"],
    ASPIRATION_HOLDINGS.map((h, i) => [String(i + 1), h.ticker, pct(h.weight, 2)]),
    [1200, 4600, 4280]
  ),
  caption("Table 4.5 — Holdings of the aspiration account (capped Roy safety-first portfolio, H_a = 15.31%)."),
  P("For a typical respondent (λ = 1.0), the largest positions in the combined BPT portfolio are G-Secs (19.9%) and then Adani Ports, Shriram Finance, Lodha, IRFC and Vedanta at about 7.2–7.6% each. Two concentrations remain and we disclose them in Section 7: half of the aspiration account is in financials (Shriram Finance, CDSL, Bank of Maharashtra, Central Bank of India and IRFC), and 20% sits in three stocks (Apollo, Indo Tech and Gabriel) whose implied returns rest on our median market-cap assumption in Section 4.1.", { spacingAfter: 0 }),
  pageBreak(),
];

module.exports = { section4 };
