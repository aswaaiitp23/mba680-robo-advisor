const fs = require("fs");
const { TextRun, Paragraph, AlignmentType, ImageRun } = require("docx");
const { H1, H2, H3, P, PR, bullet, caption, table, hrParagraph, pageBreak, pct, num } = require("./build.js");
const { PORTFOLIO_RESULTS, TOP_HOLDINGS, RESPONDENTS } = require("./data.js");
const LAM_BY_NAME = Object.fromEntries(RESPONDENTS.map(r => [r.name, r.lamPooled]));

function eq(text) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 160 },
    children: [new TextRun({ text, italics: true, size: 22 })],
  });
}

const section4 = [
  H1("4. Portfolio Recommendations (Step 5)"),
  P("We construct a personalized portfolio for each of the five respondents under both Expected Utility Theory and SP/A Behavioral Portfolio Theory, against the same 66-stock NSE asset universe, three-year annualized covariance matrix, and risk-free rate (6.75%) we used in our Markowitz Portfolio Project."),

  H2("4.1 Deriving expected returns for the asset universe"),
  P("Our Markowitz Portfolio Project workbook (MBA680_Portfolio_Workbook_Final.xlsx) exposes the full 66×66 covariance matrix and the final weights, expected return (48.41%), and volatility (18.89%) of that project's own optimized max-Sharpe portfolio P, but does not expose a per-asset expected-return (μ) vector directly — only Σ and an already-optimized outcome. We therefore back-solved μ via Black-Litterman-style reverse optimization, μ = rf·1 + λ_mkt·Σ·w_ref, and built and disclosed two versions:"),
  bullet([new TextRun({ text: "As-implied version ", bold: true }), new TextRun({ text: "— uses portfolio P itself as the reference weight vector, with λ_mkt = (E[R_P]−rf)/σ²_P = 11.68 (self-consistent, but P's Sharpe ratio of 2.21 is in-sample-optimized — the classic Michaud (1989) “Markowitz optimization enigma” — so this λ_mkt is unrealistically high)." })]),
  bullet([new TextRun({ text: "Standard-λ version (used for all results below) ", bold: true }), new TextRun({ text: "— uses a market-cap-weighted 66-stock portfolio as the reference and a conventional λ_mkt = 2.5 (He & Litterman (1999)'s standard “representative investor” default), giving a realistic implied market Sharpe ratio of 0.40 and a μ range of 9.05%–17.6% (cross-sectional mean 13.7%). All portfolio figures in this report use this version." })]),
  P("We document this derivation and both versions in our pipeline's real_asset_universe_standard_lambda/meta.json.", { spacingAfter: 240 }),

  H2("4.2 EUT results and the two-fund separation finding"),
  P("Under EUT, the long-only, fully-invested risky sleeve is the tangency portfolio — the portfolio maximizing (w'μ − rf)/√(w'Σw) subject to Σw = 1, w ≥ 0 — and the classic two-fund separation theorem says every investor should hold the SAME tangency-portfolio composition, differing only in how much of their wealth they allocate to it versus cash, via risky fraction = (tangency excess return)/(γ·tangency variance), clipped to [0, 1] for a long-only, no-leverage investor."),
  table(
    ["Respondent", "EUT risky fraction", "EUT expected return", "EUT volatility", "Unclipped risky fraction"],
    PORTFOLIO_RESULTS.map(r => [r.name, pct(r.riskyFrac, 0), pct(r.eutRet, 2), pct(r.eutVol, 2), num(r.unclipped, 2) + "×"]),
    [1900, 1970, 1970, 1970, 2270]
  ),
  caption("Table 4.1 — EUT allocation results (standard-λ universe). The “unclipped risky fraction” column is the pre-clip value λ_mkt/γ — the fraction the formula would prescribe before the long-only ceiling of 100% is applied."),
  P("Every respondent's clipped risky fraction is 100%, and — because the tangency portfolio's composition is fixed by the universe alone (μ, Σ, rf), not by any respondent's parameters — the EUT expected return (13.21%) and volatility (16.08%) are identical for all five respondents too. This is not a coding artifact: the unclipped column shows why. The implied market price of risk in the standard-λ universe is λ_mkt = 2.5, so the unclipped risky fraction is exactly λ_mkt/γ for each respondent's pooled γ (e.g. Kartika: 2.5/0.20 = 12.5×; Adwaaiit Pande: 2.5/2.187 ≈ 1.14×). Because every respondent's pooled γ in this group is low (0.05–2.2, i.e. mildly risk-averse to risk-seeking) relative to a realistic market Sharpe ratio, the unclipped preferred risky fraction exceeds 100% for all five — so the long-only constraint binds identically for everyone, and EUT alone prescribes the same portfolio to the entire peer group regardless of how different their elicited risk aversion actually is. Kshitij's case is the most extreme: his raw elicited γ is negative (−0.50, formally outside the domain of concave EUT), floored to 0.05 for the arithmetic, which mechanically produces the largest unclipped ratio (50×) in the table — a genuine EUT/CRRA boundary case, not a rounding error."),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 40 }, keepNext: true,
    children: [new ImageRun({ type: "png", data: fs.readFileSync("/home/claude/step4_graphs/out/fig_eut_share_vs_gamma.png"), transformation: { width: 520, height: Math.round(520 * 1040 / 1639) },
      altText: { title: "EUT risky share vs gamma", description: "EUT risky share vs gamma", name: "fig_eut_share" } })] }),
  caption("Figure 4.1 — Long-only EUT risky share, min(λ_mkt/γ, 100%), against risk aversion γ (λ_mkt = 2.5). All five respondents sit on the flat 100% segment; the shaded band is the range in which the elicitation engine cannot pin down γ's exact size (Section 7)."),
  P("We read this saturation as itself a substantive Step 6-relevant finding: for a peer group of moderately risk-tolerant young investors evaluated against a realistically-calibrated market Sharpe ratio, EUT with a long-only constraint is a poor basis for a personalized robo-advisory recommendation — it collapses to the same “put everything into the tangency portfolio” advice for everyone. This is what motivates our use of SP/A-BPT (Section 4.3), which does differentiate this same group.", { spacingAfter: 0 }),
  pageBreak(),

  H2("4.3 SP/A-BPT results and mental-account differentiation"),
  P("SP/A-BPT (Das, Markowitz, Scheid & Statman, 2010) recommends a portfolio built from two “mental account” layers, each solved as a Roy (1952) safety-first ratio maximization — maximize (w'μ − threshold)/√(w'Σw) subject to Σw=1, w≥0 — but with two different thresholds and then blended:"),
  bullet([new TextRun({ text: "Safety layer ", bold: true }), new TextRun({ text: "— threshold = rf (6.75%): a capital-preservation-oriented sub-portfolio. (This threshold is identical to the EUT tangency portfolio's, so the safety layer's holdings are, by construction, the same tangency portfolio as Section 4.2.)" })]),
  bullet([new TextRun({ text: "Aspiration layer ", bold: true }), new TextRun({ text: "— threshold = 75th percentile of the universe's μ vector: a higher, more growth-oriented bar." })]),
  bullet([new TextRun({ text: "Combination ", bold: true }), new TextRun({ text: "— the two layers are blended by a safety-capital fraction derived from each respondent's own elicited loss aversion λ (linearly interpolated between 30% at λ=1.0 and 80% at λ=4.0): safety_capital_frac = 0.30 + 0.1667×(λ−1), clipped to [0.30, 0.80]." })]),
  table(
    ["Respondent", "λ pooled", "Safety-capital %", "BPT expected return", "BPT volatility"],
    PORTFOLIO_RESULTS.map(r => [r.name, num(LAM_BY_NAME[r.name], 3), pct(r.safetyFrac, 1), pct(r.bptRet, 2), pct(r.bptVol, 2)]),
    [2200, 1500, 2100, 2200, 2100],
  ),
  caption("Table 4.2 — SP/A-BPT allocation results (standard-λ universe)."),
  P("Unlike EUT, BPT does differentiate this peer group. Because the blend is driven by loss aversion λ rather than risk aversion γ, and λ varies more across this group (1.0–1.6) than γ does in the region that matters, Kshitij — whose λ = 1.6 is the highest in the group — receives the most conservative BPT recommendation (40.0% safety-layer capital, the lowest BPT expected return, 15.77%, and lowest volatility, 27.12%). Shree Charan and Kartika (both λ = 1.0, the grid minimum) receive the least conservative recommendation (30.0% safety-layer capital, 16.19% expected return, 29.46% volatility). Ayushi and Adwaaiit Pande sit in between, tracking their intermediate λ of 1.009 and 1.015 respectively — a small but genuine, individualized difference EUT could not produce for this group."),
  P("A further structural point worth making explicit: like the EUT tangency portfolio, both mental-account layers' holdings (the safety layer and the aspiration layer) are themselves fixed by the universe alone — they do not depend on any respondent's own γ or λ. What is genuinely personalized under BPT for this group is only the mixing weight between the two layers (the safety-capital fraction, driven by λ), not the underlying building-block portfolios themselves. This is a second, more subtle instance of the same two-fund-separation-style logic that produces the EUT saturation in Section 4.2 — personalization in this project's asset universe operates entirely through capital allocation between a small number of universe-level building-block portfolios, never through picking different individual stocks for different people.", { spacingAfter: 0 }),
  pageBreak(),

  H2("4.4 Risky-sleeve top holdings"),
  P("Because the tangency portfolio (the EUT risky sleeve and the BPT safety layer alike) is identical for all five respondents (Section 4.2–4.3), its top holdings are reported once rather than per respondent. Weights below are shares of the risky/tangency sleeve itself, not of total wealth."),
  table(
    ["Rank", "Ticker", "Weight within risky sleeve"],
    TOP_HOLDINGS.map((h, i) => [String(i + 1), h.ticker, pct(h.weight, 2)]),
    [1200, 4600, 4280]
  ),
  caption("Table 4.3 — Top 10 holdings of the tangency (risky-sleeve) portfolio, standard-λ universe. TCS, HINDUNILVR, and SUNPHARMA together account for over 27% of the risky sleeve."),
  P("This concentration is a direct, disclosed consequence of the Black-Litterman-style μ derivation in Section 4.1 (stocks with the largest, most-favorable-relative-to-risk implied excess returns dominate the mean-variance-optimal sleeve) and mirrors the concentration already present in our companion Markowitz Portfolio Project's own optimized portfolio P.", { spacingAfter: 0 }),
  pageBreak(),
];

module.exports = { section4 };
