const { TextRun, Paragraph, AlignmentType } = require("docx");
const { H1, H2, H3, P, PR, bullet, caption, table, hrParagraph, pageBreak } = require("./build.js");

function ref(text) {
  return new Paragraph({
    spacing: { after: 160, line: 264 },
    indent: { left: 360, hanging: 360 },
    children: [new TextRun({ text })],
  });
}

const section8 = [
  H1("8. Conclusion"),
  P("We delivered both required outputs: a full risk-, time-, and personality-preference survey instrument with real, cited items (Section 2); measured outcomes for five peer-group members (Section 3); a personalized portfolio recommendation for each of them under both Expected Utility Theory and SP/A Behavioral Portfolio Theory against our own real asset universe (Section 4); and an interactive robo-advisory portal that automates the entire pipeline live, with its numerical correctness independently verified against our Python reference implementation (Section 6)."),
  P("The most consequential finding is not a specific number but a contrast: EUT, applied with a realistic market-price-of-risk calibration and a long-only constraint, prescribes the identical portfolio to every member of our peer group, while SP/A-BPT's mental-accounts structure differentiates them through their own elicited loss aversion — and, once its safety account is allowed to hold G-Secs under an explicit shortfall rule, does so in the protective direction the theory intends. Read together with Section 5's personality-dimension analysis, we believe the practical recommendation for a robo-advisory platform serving a similar client base is not to choose one framework over the other in the abstract, but to recognize that EUT and BPT answer different questions — EUT sizes the risky/safe split, BPT gives each goal its own account with its own floor — and that personality data belongs primarily to the communication and trust layer around both, not as a further input blended into either framework's weights.", { spacingAfter: 0 }),
  pageBreak(),

  H1("References"),
  ref("Blais, A.-R., & Weber, E. U. (2006). A domain-specific risk-taking (DOSPERT) scale for adult populations. Judgment and Decision Making, 1, 33–47."),
  ref("Das, S., Markowitz, H., Scheid, J., & Statman, M. (2010). Portfolio optimization with mental accounts. Journal of Financial and Quantitative Analysis, 45(2), 311–334."),
  ref("Dohmen, T., Falk, A., Huffman, D., Sunde, U., Schupp, J., & Wagner, G. G. (2011). Individual risk attitudes: Measurement, determinants, and behavioral consequences. Journal of the European Economic Association, 9(3), 522–550."),
  ref("Grable, J. E., & Lytton, R. H. (1999). Financial risk tolerance revisited: The development of a risk assessment instrument. Financial Services Review, 8, 163–181."),
  ref("He, G., & Litterman, R. (1999). The intuition behind Black-Litterman model portfolios. Goldman Sachs Investment Management Research."),
  ref("Kahneman, D., & Tversky, A. (1979). Prospect theory: An analysis of decision under risk. Econometrica, 47(2), 263–291."),
  ref("Laibson, D. (1997). Golden eggs and hyperbolic discounting. Quarterly Journal of Economics, 112(2), 443–478."),
  ref("Michaud, R. O. (1989). The Markowitz optimization enigma: Is ‘optimized’ optimal? Financial Analysts Journal, 45(1), 31–42."),
  ref("Prelec, D. (1998). The probability weighting function. Econometrica, 66(3), 497–527."),
  ref("Rabin, M. (2000). Risk aversion and expected-utility theory: A calibration theorem. Econometrica, 68(5), 1281–1292."),
  ref("Roy, A. D. (1952). Safety first and the holding of assets. Econometrica, 20(3), 431–449."),
  ref("Securities and Exchange Board of India. (1996). SEBI (Mutual Funds) Regulations, 1996, Seventh Schedule: Restrictions on investments (as amended)."),
  ref("Soto, C. J., & John, O. P. (2017). The next Big Five Inventory (BFI-2): Developing and assessing a hierarchical model with 15 facets to enhance bandwidth, fidelity, and predictive power. Journal of Personality and Social Psychology, 113(1), 117–143."),
  ref("Telser, L. G. (1955). Safety first and hedging. Review of Economic Studies, 23(1), 1–16."),
  ref("Toubia, O., Johnson, E., Evgeniou, T., & Delquié, P. (2013). Dynamic experiments for estimating preferences: An adaptive method of eliciting time and risk parameters. Management Science, 59(3), 613–640."),
  pageBreak(),
];

module.exports = { section8 };
