const { H1, H2, P, caption, table, pageBreak } = require("./build.js");
const { BFI2_ITEMS } = require("./data.js");

const appendixA = [
  H1("Appendix A: Full BFI-2 Item List"),
  P("All 60 items of the BFI-2 (Soto & John, 2017), in administration order, with domain and facet assignment and reverse-keying. Each item is presented in the form “I am someone who …”, rated 1 (Disagree strongly) to 5 (Agree strongly). Domain scores reported in Table 3.3 are the mean of each domain's 12 items after reverse-scoring the items marked “Yes” below. Reproduced for non-commercial academic use per the authors' stated policy."),
  table(
    ["#", "Item (“I am someone who …”)", "Domain", "Facet", "Reverse-keyed"],
    BFI2_ITEMS.map((it, i) => [String(i + 1), it.text, it.domain, it.facet, it.reverse ? "Yes" : "No"]),
    [500, 3700, 2200, 2400, 1280]
  ),
  caption("Table A.1 — BFI-2 60-item list with domain, facet, and reverse-keying."),
];

module.exports = { appendixA };
