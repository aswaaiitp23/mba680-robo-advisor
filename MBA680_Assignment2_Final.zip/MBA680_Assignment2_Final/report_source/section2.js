const { TextRun, Paragraph, AlignmentType } = require("docx");
const { H1, H2, H3, P, PR, bullet, caption, table, hrParagraph, pageBreak } = require("./build.js");
const { GRABLE_LYTTON_ITEMS, DOSPERT_FIN_ITEMS } = require("./data.js");

const section2 = [
  H1("2. Survey and Questionnaire Instruments (Steps 2–4)"),
  P("We deployed the survey instrument as a single online form — the interactive portal described in Section 6 — that every respondent completes in one sitting (about 100 items, roughly 20–25 minutes). It chains four components in sequence: two general self-report anchors, two validated third-party psychometric scales, and a purpose-built adaptive elicitation engine. We describe all four components below, including the full item text for the two short scales and the complete mathematical formulation of the adaptive engine, which is our own Step 4 design."),
  H2("2.1 General risk and time-preference anchors"),
  P("Before any scale is administered, each respondent rates their own general risk tolerance and general patience on a 0–10 slider (“On a scale of 0 to 10, how willing are you to take financial risk?” and the analogous patience question). Modelled on the validated single-item general risk question of Dohmen et al. (2011), we use these only as a cheap, single-item cross-check later against the psychometrically-derived and adaptively-elicited measures — not as inputs to the portfolio construction itself — precisely because self-report and revealed preference can diverge, as Section 3 shows for our group."),

  H2("2.2 Grable & Lytton (1999) Financial Risk Tolerance Scale"),
  P("Source: Grable, J. E., & Lytton, R. H. (1999). Financial risk tolerance revisited: The development of a risk assessment instrument. Financial Services Review, 8, 163–181. This 13-item scale is one of the most widely used financial risk-tolerance instruments in both practice and academic research, freely distributed by the authors for advisory and research use with citation. Respondents choose one option per item; each option carries an integer score, and the sum across all 13 items yields a total risk-tolerance score used to classify respondents into a qualitative band (e.g. “Average/moderate,” “Above-average,” “High”)."),
  ...GRABLE_LYTTON_ITEMS.map((it, i) => PR([
    new TextRun({ text: `${i + 1}. `, bold: true }),
    new TextRun({ text: it.q }),
    new TextRun({ text: "  —  " + it.opts.join(" / "), italics: true, color: "595959", size: 18 }),
  ], { spacingAfter: 110 })),

  pageBreak(),
  H2("2.3 DOSPERT financial subscale (Blais & Weber, 2006)"),
  P("Source: Blais, A.-R., & Weber, E. U. (2006). A domain-specific risk-taking (DOSPERT) scale for adult populations. Judgment and Decision Making, 1, 33–47. The full DOSPERT instrument measures risk-taking propensity across several life domains; this survey uses only its financial subscale, split into two three-item sub-domains — gambling and investing — to separate a respondent's general appetite for risk-as-play from their appetite for risk-as-investment. Each item is rated on a 1 (“Extremely unlikely”) to 7 (“Extremely likely”) scale, and each sub-domain's mean is reported separately (see Section 3)."),
  table(
    ["#", "Item", "Sub-domain"],
    DOSPERT_FIN_ITEMS.map((it, i) => [String(i + 1), it.text, it.domain]),
    [700, 7480, 1900]
  ),
  caption("Table 2.1 — DOSPERT financial subscale items (Blais & Weber, 2006), rated 1–7 on likelihood of engaging in the behavior."),

  H2("2.4 BFI-2 Personality Inventory (Soto & John, 2017)"),
  P("Source: Soto, C. J., & John, O. P. (2017). The next Big Five Inventory (BFI-2): Developing and assessing a hierarchical model with 15 facets to enhance bandwidth, fidelity, and predictive power. Journal of Personality and Social Psychology, 113(1), 117–143. The BFI-2 is a 60-item hierarchical Big Five inventory: 5 broad domains (Extraversion, Agreeableness, Conscientiousness, Negative Emotionality, Open-Mindedness), each measured by 3 facets of 4 items apiece (12 items per domain), with roughly half the items reverse-keyed within each facet. Respondents rate each item on a 1 (“Disagree strongly”) to 5 (“Agree strongly”) scale describing themselves (“I am someone who …”). Domain scores are the mean of their 12 constituent items after reverse-scoring. The full 60-item list, with domain and facet assignment, is reproduced in Appendix A."),
  P("Negative Emotionality (the BFI-2's label for what earlier Big Five instruments called Neuroticism) is the domain most directly relevant to our financial-preference constructs, since it captures a general disposition toward anxiety, worry, and emotional volatility — traits with an obvious a priori link to loss aversion and to how a client reacts to portfolio drawdowns. Section 5 develops this link using our own data.", { spacingAfter: 0 }),

  pageBreak(),
];

module.exports = { section2 };
