const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  TableOfContents, PageBreak, PageOrientation, LevelFormat,
  PositionalTab, PositionalTabAlignment, PositionalTabLeader, PositionalTabRelativeTo,
  Header, Footer, PageNumber, VerticalAlign, TabStopType, TabStopPosition, LeaderType,
} = require("docx");

const { GRABLE_LYTTON_ITEMS, DOSPERT_FIN_ITEMS, BFI2_ITEMS, RESPONDENTS, PORTFOLIO_RESULTS, TOP_HOLDINGS } = require("./data.js");

// ---------------------------------------------------------------------------
// Layout constants (US Letter, DXA)
// ---------------------------------------------------------------------------
const PAGE_W = 12240, PAGE_H = 15840;
const MARGIN = 1080; // 0.75in
const CONTENT_W = PAGE_W - 2 * MARGIN; // 10080

const NAVY = "1F3864";
const ACCENT = "2E5395";
const LIGHT = "DCE6F1";
const MED = "B8CCE4";
const GREY = "595959";

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------
function H1(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_1, spacing: { before: 400, after: 200 } });
}
function H2(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 150 } });
}
function H3(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_3, spacing: { before: 220, after: 100 } });
}
function P(text, opts = {}) {
  const { bold, italics, size, color, spacingAfter = 160, alignment } = opts;
  return new Paragraph({
    alignment,
    spacing: { after: spacingAfter, line: 276 },
    children: [new TextRun({ text, bold, italics, size, color })],
  });
}
function PR(runs, opts = {}) {
  const { spacingAfter = 160, alignment } = opts;
  return new Paragraph({ alignment, spacing: { after: spacingAfter, line: 276 }, children: runs });
}
function bullet(text, opts = {}) {
  return new Paragraph({
    numbering: { reference: "bullet-list", level: opts.level || 0 },
    spacing: { after: 90, line: 270 },
    children: Array.isArray(text) ? text : [new TextRun({ text })],
  });
}
function caption(text) {
  return new Paragraph({
    spacing: { before: 60, after: 240 },
    children: [new TextRun({ text, italics: true, size: 18, color: GREY })],
  });
}
function cell(text, opts = {}) {
  const { bold, header, width, color, align = AlignmentType.LEFT, size = 18, shading, rowSpan, columnSpan } = opts;
  return new TableCell({
    width: width ? { size: width, type: WidthType.DXA } : undefined,
    shading: shading ? { type: ShadingType.CLEAR, fill: shading } : (header ? { type: ShadingType.CLEAR, fill: NAVY } : undefined),
    verticalAlign: VerticalAlign.CENTER,
    rowSpan, columnSpan,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: [new Paragraph({
      alignment: align,
      children: [new TextRun({ text: String(text), bold: bold || header, color: header ? "FFFFFF" : (color || "000000"), size })],
    })],
  });
}
function table(headers, rows, widths) {
  const total = widths.reduce((a, b) => a + b, 0);
  const headerRow = new TableRow({
    tableHeader: true,
    children: headers.map((h, i) => cell(h, { header: true, width: widths[i], align: i === 0 ? AlignmentType.LEFT : AlignmentType.CENTER })),
  });
  const bodyRows = rows.map((r, ri) => new TableRow({
    children: r.map((v, i) => cell(v, {
      width: widths[i],
      align: i === 0 ? AlignmentType.LEFT : AlignmentType.CENTER,
      shading: ri % 2 === 1 ? "F2F6FB" : undefined,
    })),
  }));
  return new Table({
    width: { size: total, type: WidthType.DXA },
    columnWidths: widths,
    rows: [headerRow, ...bodyRows],
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: "B8CCE4" },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: "B8CCE4" },
      left: { style: BorderStyle.SINGLE, size: 4, color: "B8CCE4" },
      right: { style: BorderStyle.SINGLE, size: 4, color: "B8CCE4" },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: "D9D9D9" },
      insideVertical: { style: BorderStyle.SINGLE, size: 2, color: "D9D9D9" },
    },
  });
}
function hrParagraph() {
  return new Paragraph({
    spacing: { before: 60, after: 240 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: MED, space: 1 } },
    children: [],
  });
}
function pageBreak() {
  return new Paragraph({ children: [new PageBreak()] });
}
function tocEntry(title, page, opts = {}) {
  const { level = 0, bold = false } = opts;
  const indentLeft = level * 360;
  return new Paragraph({
    spacing: { after: level === 0 ? 140 : 90 },
    indent: { left: indentLeft },
    tabStops: [{ type: TabStopType.RIGHT, position: CONTENT_W - indentLeft, leader: LeaderType.DOT }],
    children: [
      new TextRun({ text: title, bold, size: level === 0 ? 22 : 20, color: level === 0 ? NAVY : "000000" }),
      new TextRun({ text: "\t" + String(page), bold, size: level === 0 ? 22 : 20 }),
    ],
  });
}
function pct(x, dp = 1) { return `${(x * 100).toFixed(dp)}%`; }
function num(x, dp = 3) { return x.toFixed(dp); }

// ---------------------------------------------------------------------------
// COVER PAGE
// ---------------------------------------------------------------------------
const cover = [
  new Paragraph({ spacing: { before: 1600, after: 0 }, children: [] }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 120 },
    children: [new TextRun({ text: "MBA680 — BEHAVIORAL FINANCE", bold: true, size: 24, color: GREY })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 400 },
    children: [new TextRun({ text: "Robo-Advisory Portfolio Recommendations", bold: true, size: 44, color: NAVY })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 100 },
    children: [new TextRun({ text: "Risk & Time Preferences, Personality, and Portfolio Choice Under", size: 26, color: ACCENT })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 700 },
    children: [new TextRun({ text: "Expected Utility Theory and SP/A Behavioral Portfolio Theory", bold: true, size: 26, color: ACCENT })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 60 },
    children: [new TextRun({ text: "MBA680 Group Project — Adwaaiit Pande & Ayushi Mishra", size: 22 })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 700 },
    children: [new TextRun({ text: "Peer group surveyed: Shree Charan, Kshitij, Kartika, Ayushi Mishra, Adwaaiit Pande", size: 22, color: GREY })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 40 },
    children: [new TextRun({ text: "Prepared by Adwaaiit Pande and Ayushi Mishra", size: 22, bold: true })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 1200 },
    children: [new TextRun({ text: "September 2026", size: 22, color: GREY })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 40 },
    children: [new TextRun({ text: "Interactive robo-advisory portal:", size: 20, color: GREY })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 40 },
    children: [new TextRun({ text: "https://mba680-robo-advisor.vercel.app", size: 20, color: ACCENT })],
  }),
  pageBreak(),
];

// ---------------------------------------------------------------------------
// TOC
// ---------------------------------------------------------------------------
const toc = [
  H1("Table of Contents"),
  tocEntry("Executive Summary", 3),
  tocEntry("1. Introduction", 4),
  tocEntry("1.1 Peer group", 4, { level: 1 }),
  tocEntry("1.2 Structure of this report", 4, { level: 1 }),
  tocEntry("2. Survey and Questionnaire Instruments (Steps 2–4)", 5),
  tocEntry("2.1 General risk and time-preference anchors", 5, { level: 1 }),
  tocEntry("2.2 Grable & Lytton (1999) Financial Risk Tolerance Scale", 5, { level: 1 }),
  tocEntry("2.3 DOSPERT financial subscale (Blais & Weber, 2006)", 7, { level: 1 }),
  tocEntry("2.4 BFI-2 Personality Inventory (Soto & John, 2017)", 7, { level: 1 }),
  tocEntry("2.5 Step 4: Adaptive utility/value-function elicitation engine", 8, { level: 1 }),
  tocEntry("3. Survey Outcomes", 10),
  tocEntry("3.1 Risk tolerance and time-preference scales", 10, { level: 1 }),
  tocEntry("3.2 Pooled structural preference parameters", 10, { level: 1 }),
  tocEntry("3.3 BFI-2 personality domain scores", 10, { level: 1 }),
  tocEntry("3.4 Respondent-level notes", 11, { level: 1 }),
  tocEntry("3.5 Graphical representation of the elicited functions (Step 4)", 12, { level: 1 }),
  tocEntry("4. Portfolio Recommendations (Step 5)", 15),
  tocEntry("4.1 Deriving expected returns for the asset universe", 15, { level: 1 }),
  tocEntry("4.2 EUT results and the two-fund separation finding", 15, { level: 1 }),
  tocEntry("4.3 SP/A-BPT results: two mental accounts", 17, { level: 1 }),
  tocEntry("4.4 Holdings and diversification", 19, { level: 1 }),
  tocEntry("5. Step 6: How Personality Dimensions Should Inform Robo-Advisory Design", 20),
  tocEntry("6. The Interactive Robo-Advisory Portal (Deliverable b)", 22),
  tocEntry("7. Limitations and Data-Quality Disclosures", 24),
  tocEntry("8. Conclusion", 26),
  tocEntry("References", 27, { bold: false }),
  tocEntry("Appendix A: Full BFI-2 Item List", 28),
  pageBreak(),
];

// ---------------------------------------------------------------------------
// EXECUTIVE SUMMARY
// ---------------------------------------------------------------------------
const execSummary = [
  H1("Executive Summary"),
  P("In this report, we document Steps 2 through 6 of the MBA680 robo-advisory / behavioral portfolio project: designing and deploying a risk-, time-, and personality-preference survey; eliciting and pooling each peer's structural preference parameters; constructing a personalized portfolio recommendation for each peer under both Expected Utility Theory (EUT) and SP/A Behavioral Portfolio Theory (BPT); and commenting on how personality dimensions should factor into robo-advisory design. We also document the interactive robo-advisory portal we built to automate this entire pipeline end to end, satisfying the project's second deliverable."),
  P("Five members of our peer group completed the full survey instrument: Shree Charan, Kshitij, Kartika, Ayushi Mishra, and Adwaaiit Pande. We report their results in full below."),
  P("Three findings stand out:", { spacingAfter: 80 }),
  bullet([new TextRun({ text: "Under EUT, our peer group is fully saturated. ", bold: true }), new TextRun({ text: "Every respondent's elicited risk aversion is low relative to the asset universe's implied market price of risk, so the long-only-constrained EUT risky-fraction hits its 100% ceiling for all five respondents — and by the two-fund separation theorem, everyone is prescribed the identical risky-sleeve composition. EUT alone does not differentiate our peer group at all (subject to one identification caveat on γ, discussed in Section 7)." })]),
  bullet([new TextRun({ text: "SP/A-BPT does differentiate the group. ", bold: true }), new TextRun({ text: "Because the mental-accounts framework splits capital between a safety account and an aspiration account in proportion to elicited loss aversion (λ) rather than risk aversion (γ), respondents put 30%–40% of capital in the safety account — which holds G-Secs and is built to lose money in at most 1 year in 20 — and 20–27% of their wealth in G-Secs, tracking each person's own λ. Kshitij, the only clearly loss-averse respondent, gets the most protection and the lowest volatility. With every stock capped at 10%, no client has more than 7.6% of wealth in any single stock." })]),
  bullet([new TextRun({ text: "Personality and elicited preferences do not always agree. ", bold: true }), new TextRun({ text: "Two of five respondents show a flagged inconsistency between self-reported risk tolerance / Grable-Lytton score and the adaptively-elicited γ, and one respondent's BFI-2 profile is suspiciously flat across all five domains — both directly relevant to how a robo-advisor should communicate with, not just compute for, each client." })]),
  P("We present the full instruments, outcomes, portfolio recommendations, and Step 6 commentary below, followed by documentation of the interactive portal in Section 6.", { spacingAfter: 0 }),
  pageBreak(),
];

// ---------------------------------------------------------------------------
// SECTION 1 -- INTRODUCTION
// ---------------------------------------------------------------------------
const intro = [
  H1("1. Introduction"),
  P("The MBA680 robo-advisory / behavioral portfolio project asks each group to (1) identify a peer group, (2) design a risk- and time-preference questionnaire, (3) obtain each peer's BFI-2 personality dimensions, (4) design a utility/value-function questionnaire with an explicit mathematical formulation, (5) recommend each peer a portfolio under both Expected Utility Theory and SP/A Behavioral Portfolio Theory, and (6) comment on how personality dimensions should factor into robo-advisory design. We completed this assignment as a two-person MBA680 group: Adwaaiit Pande and Ayushi Mishra."),
  P("We reuse the 66-stock NSE asset universe, three-year daily covariance matrix, and risk-free rate assumption (6.75%, an India 10-year G-Sec proxy) we built for our companion Markowitz Portfolio Project, so that the behavioral recommendations in Section 4 are directly comparable to the mean-variance-optimal portfolio we already constructed there."),
  H2("1.1 Peer group"),
  P("The peer group we surveyed for Steps 2–6 is distinct from our two-person authoring group above: it draws on a wider set of classmates whose risk-, time-, and personality-preference data feed the Section 3–5 analysis. Five of them completed the full survey instrument described in Section 2: Shree Charan, Kshitij, Kartika, Ayushi Mishra, and Adwaaiit Pande, and it is their results we report throughout this document."),
  H2("1.2 Structure of this report"),
  P("In Section 2, we document the four survey instruments (the general risk/time anchors, the Grable & Lytton financial risk tolerance scale, the DOSPERT financial subscale, and the BFI-2 personality inventory) and the adaptive Bayesian utility/value-function elicitation engine we built for Step 4, including its full mathematical formulation. Section 3 reports the survey outcomes for all five respondents. Section 4 presents the personalized portfolio recommendation for each respondent under EUT and SP/A-BPT. Section 5 is our Step 6 commentary on personality and robo-advisory design. Section 6 documents the interactive robo-advisory portal we built (our second deliverable). Section 7 discloses data-quality limitations, and Section 8 concludes."),
  pageBreak(),
];

module.exports = { PAGE_W, PAGE_H, MARGIN, CONTENT_W, NAVY, ACCENT, LIGHT, MED, GREY,
  H1, H2, H3, P, PR, bullet, caption, cell, table, hrParagraph, pageBreak, pct, num, tocEntry,
  cover, toc, execSummary, intro };
