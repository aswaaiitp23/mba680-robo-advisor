const { TextRun, Paragraph, AlignmentType } = require("docx");
const { H1, H2, H3, P, PR, bullet, caption, table, hrParagraph, pageBreak } = require("./build.js");

function eq(text) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 160 },
    children: [new TextRun({ text, italics: true, size: 22 })],
  });
}

const section2b = [
  H2("2.5 Step 4: Adaptive utility/value-function elicitation engine"),
  P("Rather than asking respondents to self-report abstract parameters such as “What is your risk aversion coefficient?”, we implemented Step 4 as a short (18-question, plus 2 hidden repeat questions) adaptive choice task: respondents repeatedly pick between a described pair of monetary outcomes (either a risky gamble vs. a sure amount, or a smaller-sooner vs. larger-later payment), and each answer updates a Bayesian belief over five structural preference parameters. The next question shown is always the one expected to be most informative given everything answered so far. This adaptive design follows the logic of Toubia et al. (2013). We give the full mathematical formulation below."),

  H3("2.5.1 The five structural parameters"),
  P("Every choice a respondent faces is scored under a five-parameter behavioral-economic model:", { spacingAfter: 100 }),
  bullet([new TextRun({ text: "γ (gamma) — risk aversion ", bold: true }), new TextRun({ text: "in a power (CRRA-style) value function, grid range [−0.5, 3.0]." })]),
  bullet([new TextRun({ text: "λ (lambda) — loss aversion ", bold: true }), new TextRun({ text: "in the sense of Kahneman & Tversky (1979) prospect theory, grid range [1.0, 4.0]." })]),
  bullet([new TextRun({ text: "α_w (alpha_w) — probability-weighting curvature ", bold: true }), new TextRun({ text: "(Prelec, 1998), grid range [0.4, 1.4]." })]),
  bullet([new TextRun({ text: "β (beta_hyp) — present-bias ", bold: true }), new TextRun({ text: "in a quasi-hyperbolic (β-δ) discounting model (Laibson, 1997), grid range [0.5, 1.0]." })]),
  bullet([new TextRun({ text: "δ (delta) — exponential discount factor ", bold: true }), new TextRun({ text: "(per 30-day period), grid range [0.90, 1.00]." })]),
  P("Each parameter is discretized on a 6-point grid over its range, and the engine maintains a joint posterior over the full Cartesian product (7,776 grid cells) rather than treating the parameters independently.", { spacingAfter: 200 }),

  H3("2.5.2 Value function, probability weighting, and discounting"),
  P("For a monetary outcome x, the value function is a loss-averse power function:"),
  eq("v(x; γ, λ) = x^(1−γ)  if x ≥ 0,     v(x; γ, λ) = −λ·|x|^(1−γ)  if x < 0"),
  P("(with the exponent floored at 0.05 to keep it well-defined as γ → 1). For a risky prospect offering outcome ‘high’ with probability p and ‘low’ otherwise, the decision weight uses Prelec's (1998) one-parameter probability-weighting function:"),
  eq("w(p; α_w) = exp(−(−ln p)^α_w)"),
  P("so the prospect's utility is U = w(p)·v(high) + (1−w(p))·v(low). For an intertemporal choice between an amount now (t = 0) and a larger amount at a future date t (in days), the quasi-hyperbolic discount weight applied to the later payoff is:"),
  eq("D(t; β, δ) = β·δ^(t/30)   for t > 0,   D(0) = 1"),
  P("so the discounted utility of a delayed payoff x at time t is D(t)·v(x). Every question the engine can ask is one of these two forms — a risky-choice prompt or a time-delay prompt — drawn from a bank of 90 risky-choice combinations (9 probability levels × 6 payoff/probability combinations) and 40 time-delay combinations (4 delay-pair windows × 10 payoff-growth percentages), giving 130 distinct candidate questions in total.", { spacingAfter: 200 }),

  H3("2.5.3 Choice probability and Bayesian updating"),
  P("Given a candidate question with utilities U_A and U_B for its two options, the engine does not assume respondents choose deterministically; it models choice as a logistic (softmax) function of the utility difference, with a fixed noise scale τ = 0.35:"),
  eq("P(choose B) = 1 / (1 + exp(−(U_B − U_A) / τ))"),
  P("This choice probability is computed at every one of the 7,776 grid cells simultaneously (i.e. “what would each hypothetical parameter combination have predicted for this question?”) and cached in advance for all 130 candidate questions. After a respondent answers, the log-posterior over the grid is updated by Bayes' rule in log form:"),
  eq("log π(θ) ← log π(θ) + log P(observed choice | θ),  for every grid cell θ"),
  P("and renormalized. The next question presented is chosen to maximize expected information gain: for each remaining candidate question, the engine computes the expected reduction in posterior (Shannon) entropy it would produce, averaging over the two possible answers weighted by their current posterior-predictive probability, and asks the question with the largest expected entropy reduction. After the 18 adaptively-chosen questions, two additional questions are silently repeated (without informing the respondent) purely as a retest-reliability check — this is the basis of the retestConsistency figure reported in Section 3.", { spacingAfter: 200 }),

  H3("2.5.4 Posterior summary and hierarchical pooling"),
  P("Each respondent's final individual estimate for a parameter is the posterior mean over the grid, together with a 90% credible interval read off the posterior's 5th and 95th percentiles. Because a single respondent's 20-question session leaves genuine estimation uncertainty (and, for several respondents in our group, a posterior that has collapsed onto a single grid cell — see Section 7), we additionally apply an Empirical-Bayes (Efron–Morris-style) hierarchical shrinkage across the peer group in the researcher/group view: each respondent's individual posterior mean is pooled toward the group mean, with more shrinkage applied to respondents whose individual posterior is wide (uncertain) and less shrinkage applied to those whose posterior is tight (confident), subject to a floor of at least 30% weight always remaining on the individual's own estimate so that no one respondent's preferences are ever fully overwritten by the group average:"),
  eq("w_i = max( between-respondent variance / (between-respondent variance + within-respondent variance), 0.30 );    pooled_i = w_i · individual_i + (1 − w_i) · group mean"),
  P("The pooled (γ, λ) values — not the raw individual posterior means — are what feed the portfolio construction in Section 4, and are the values reported throughout Section 3.", { spacingAfter: 0 }),
  pageBreak(),
];

module.exports = { section2b };
