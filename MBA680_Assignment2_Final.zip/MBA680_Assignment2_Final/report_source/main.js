const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  LevelFormat, Header, Footer, PageNumber, BorderStyle,
} = require("docx");

const {
  PAGE_W, PAGE_H, MARGIN, NAVY, GREY,
  cover, toc, execSummary, intro,
} = require("./build.js");
const { section2 } = require("./section2.js");
const { section2b } = require("./section2b.js");
const { section3 } = require("./section3.js");
const { section4 } = require("./section4.js");
const { section5 } = require("./section5.js");
const { section6 } = require("./section6.js");
const { section7 } = require("./section7.js");
const { section8 } = require("./section8.js");
const { appendixA } = require("./appendixA.js");

const allChildren = [
  ...cover,
  ...toc,
  ...execSummary,
  ...intro,
  ...section2,
  ...section2b,
  ...section3,
  ...section4,
  ...section5,
  ...section6,
  ...section7,
  ...section8,
  ...appendixA,
];

const doc = new Document({
  creator: "Adwaaiit Pande",
  title: "Robo-Advisory Portfolio Recommendations — MBA680 Behavioral Finance",
  description: "EUT and SP/A-BPT portfolio recommendations, survey instruments, outcomes, and personality-dimension commentary for the MBA680 robo-advisory / behavioral portfolio project.",
  styles: {
    default: {
      document: { run: { font: "Calibri", size: 22 } },
    },
    paragraphStyles: [
      {
        id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: "Calibri", size: 32, bold: true, color: NAVY },
        paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0,
          border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: NAVY, space: 4 } } },
      },
      {
        id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: "Calibri", size: 26, bold: true, color: "2E5395" },
        paragraph: { spacing: { before: 280, after: 140 }, outlineLevel: 1 },
      },
      {
        id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: "Calibri", size: 23, bold: true, italics: false, color: "404040" },
        paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 2 },
      },
    ],
  },
  numbering: {
    config: [
      {
        reference: "bullet-list",
        levels: [
          { level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 540, hanging: 270 } } } },
          { level: 1, format: LevelFormat.BULLET, text: "–", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 900, hanging: 270 } } } },
        ],
      },
    ],
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: PAGE_W, height: PAGE_H },
          margin: { top: MARGIN, bottom: MARGIN, left: MARGIN, right: MARGIN },
        },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({
            alignment: AlignmentType.RIGHT,
            border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "B8CCE4", space: 4 } },
            children: [new TextRun({ text: "MBA680 — Robo-Advisory Portfolio Project", size: 16, color: GREY })],
          })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: "Page ", size: 16, color: GREY }),
              new TextRun({ children: [PageNumber.CURRENT], size: 16, color: GREY }),
              new TextRun({ text: " of ", size: 16, color: GREY }),
              new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 16, color: GREY }),
            ],
          })],
        }),
      },
      children: allChildren,
    },
  ],
});

Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync("/home/claude/roboadvisory_report/MBA680_RoboAdvisory_Report.docx", buffer);
  console.log("Wrote MBA680_RoboAdvisory_Report.docx,", buffer.length, "bytes");
}).catch((e) => {
  console.error("BUILD FAILED:", e);
  process.exit(1);
});
