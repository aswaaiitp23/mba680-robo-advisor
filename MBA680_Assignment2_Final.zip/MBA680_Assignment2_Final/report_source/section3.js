const fs = require("fs");
const { TextRun, Paragraph, AlignmentType, ImageRun } = require("docx");
const FIG_DIR = "/home/claude/step4_graphs/out/";
function figure(file, pxW, pxH, widthPx) {
  const h = Math.round(widthPx * pxH / pxW);
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 40 },
    keepNext: true,
    children: [new ImageRun({ type: "png", data: fs.readFileSync(FIG_DIR + file), transformation: { width: widthPx, height: h },
      altText: { title: file, description: file, name: file } })],
  });
}
const { H1, H2, H3, P, PR, bullet, caption, table, hrParagraph, pageBreak, GREY } = require("./build.js");
const { RESPONDENTS } = require("./data.js");

const section3 = [
  H1("3. Survey Outcomes"),
  P("Five members of our peer group completed the full instrument: Shree Charan, Kshitij, Kartika, Ayushi, and Adwaaiit Pande. We report their results across all four instruments — the general anchors, Grable-Lytton, DOSPERT, and BFI-2 — followed by the pooled structural parameters (γ, λ, α_w, β, δ) that feed the Section 4 portfolio construction, and close with per-respondent data-quality notes."),

  H2("3.1 Risk tolerance and time-preference scales"),
  table(
    ["Respondent", "General risk (0–10)", "General patience (0–10)", "Grable-Lytton total", "G-L band", "DOSPERT investing (1–7)", "DOSPERT gambling (1–7)"],
    RESPONDENTS.map(r => [r.name, String(r.generalRisk), String(r.generalPatience), String(r.glTotal), r.glLevel, r.dospertInv.toFixed(2), r.dospertGamb.toFixed(2)]),
    [1800, 1300, 1300, 1300, 1500, 1440, 1440]
  ),
  caption("Table 3.1 — Self-report and psychometric-scale scores for all five respondents."),

  H2("3.2 Pooled structural preference parameters"),
  P("These are the Empirical-Bayes hierarchically-pooled values (Section 2.5.4) used for the Section 4 portfolio construction, alongside each respondent's raw (unpooled) individual posterior mean for γ and λ for comparison."),
  table(
    ["Respondent", "γ raw", "γ pooled", "λ raw", "λ pooled", "α_w pooled", "β pooled", "δ pooled", "Retest consist."],
    RESPONDENTS.map(r => [r.name, r.gammaRaw.toFixed(3), r.gammaPooled.toFixed(3), r.lamRaw.toFixed(3), r.lamPooled.toFixed(3), r.alphaW.toFixed(3), r.betaHyp.toFixed(3), r.delta.toFixed(3), r.retest.toFixed(1)]),
    [1580, 850, 950, 850, 950, 1000, 950, 950, 1000]
  ),
  caption("Table 3.2 — Pooled structural parameters (risk aversion γ, loss aversion λ, probability-weighting α_w, present-bias β, discount factor δ) and retest consistency (fraction of the 2 hidden repeat questions answered consistently with the original)."),

  H2("3.3 BFI-2 personality domain scores"),
  table(
    ["Respondent", "Extraversion", "Agreeableness", "Conscientious.", "Neg. Emotionality", "Open-Mindedness"],
    RESPONDENTS.map(r => [r.name, r.bfi2.Extraversion.toFixed(2), r.bfi2.Agreeableness.toFixed(2), r.bfi2.Conscientiousness.toFixed(2), r.bfi2["Negative Emotionality"].toFixed(2), r.bfi2["Open-Mindedness"].toFixed(2)]),
    [1830, 1650, 1650, 1650, 1650, 1650]
  ),
  caption("Table 3.3 — BFI-2 domain scores (1–5 scale, mean of 12 items per domain after reverse-scoring)."),

  H2("3.4 Respondent-level notes"),
  P("Each respondent's data carries at least one notable feature worth flagging explicitly rather than passing silently into the portfolio recommendation:", { spacingAfter: 120 }),
  ...RESPONDENTS.map(r => PR([
    new TextRun({ text: `${r.name}. `, bold: true }),
    new TextRun({ text: r.flag }),
  ], { spacingAfter: 140 })),
  P("We carry these notes forward into Section 5's discussion of how a robo-advisor should treat personality and data-quality signals jointly with the numerical outputs, and into Section 7's limitations.", { spacingAfter: 0 }),
  pageBreak(),
  H2("3.5 Graphical representation of the elicited functions (Step 4)"),
  P("Step 4 asks for both the mathematical formulation and a graphical representation of each respondent's utility and value functions. Figures 3.1–3.4 plot all four elicited functions for all five respondents, using the pooled parameters in Table 3.2 and exactly the functional forms set out in Section 2.5.2. Each respondent keeps the same colour across all four figures."),
  figure("fig_utility_function.png", 1639, 1040, 560),
  caption("Figure 3.1 — Utility function under EUT (CRRA), u(W) = (W^(1−γ) − 1)/(1−γ), over wealth relative to today."),
  P("Shree Charan, Ayushi and Adwaaiit Pande (γ ≈ 2.2) have strongly concave utility: a 50% fall in wealth costs them far more utility than a 50% rise adds, and their three curves lie almost on top of one another. Kartika (γ = 0.20) is close to risk-neutral. Kshitij's elicited γ = −0.50 gives a convex, risk-seeking utility curve, which is why we floor his γ at 0.05 for the portfolio arithmetic in Section 4."),
  figure("fig_value_function.png", 1639, 1040, 560),
  caption("Figure 3.2 — Prospect-theory value function over gains and losses, v(x) = x^e for gains and −λ|x|^e for losses, with e = max(1−γ, 0.05) as used by the elicitation engine."),
  P("Kshitij is the only respondent with clear loss aversion (λ = 1.6: a loss weighs 1.6× an equal-sized gain); the other four have λ ≈ 1.0. For the three γ ≈ 2.2 respondents the curvature exponent 1−γ is negative, so the engine's floor of 0.05 binds and their value functions become near-step functions: almost all of the value of a gain or a loss is felt in its first rupee (extreme diminishing sensitivity). Kshitij's curve is convex for gains and concave for losses, the mirror image of the standard Kahneman–Tversky S-shape."),
  figure("fig_probability_weighting.png", 1320, 1240, 360),
  caption("Figure 3.3 — Prelec (1998) probability-weighting function, w(p) = exp(−(−ln p)^α); the dashed diagonal is objective weighting."),
  P("Kshitij (α = 0.40) and Shree Charan (α = 0.57) show the classic inverse-S: they treat a 5% chance as if it were roughly 21% and 16% respectively, the lottery-ticket effect. Kartika (α = 1.00) weights probabilities objectively, while Ayushi (α = 1.09) and Adwaaiit Pande (α = 1.25) slightly under-weight rare outcomes."),
  figure("fig_discount_function.png", 1639, 1040, 560),
  caption("Figure 3.4 — Quasi-hyperbolic (β–δ) discount weight on a payment t days away: D(0) = 1, D(t) = β·δ^(t/30) for t > 0."),
  P("The drop just after t = 0 is present bias (β). Kshitij is both the most present-biased (β = 0.63) and the most impatient (δ = 0.90 per 30 days): a payment one year away is worth only about 18% of the same payment today to him. Adwaaiit Pande is the most patient of the group (β = 0.94, δ = 0.976; a one-year-away payment keeps about 70% of its value), notably at odds with his self-reported patience of 4/10 — a second self-report vs. revealed-preference gap alongside the risk gap discussed in Section 5.2.", { spacingAfter: 0 }),
  pageBreak(),
];

module.exports = { section3 };
