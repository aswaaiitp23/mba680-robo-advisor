const { TextRun, Paragraph, AlignmentType, ExternalHyperlink } = require("docx");
const { H1, H2, H3, P, PR, bullet, caption, table, hrParagraph, pageBreak } = require("./build.js");

const PORTAL_URL = "https://mba680-robo-advisor.vercel.app";

function linkPar(url) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 100, after: 260 },
    children: [new ExternalHyperlink({
      link: url,
      children: [new TextRun({ text: url, style: "Hyperlink", size: 22 })],
    })],
  });
}

const section6 = [
  H1("6. The Interactive Robo-Advisory Portal (Deliverable b)"),
  P("Our second deliverable is a single interactive web portal that automates the entire Steps 2–6 pipeline — both the traditional (EUT) and behavioral (SP/A-BPT) portfolio-theory paths — end to end, functioning as a genuine robo-advisory offering rather than a data-collection form that feeds an offline analysis script."),
  linkPar(PORTAL_URL),

  H2("6.1 What the portal does"),
  H3("Respondent flow"),
  P("A respondent opens the link, enters their name, and is walked through all four survey instruments from Section 2 in sequence (general anchors → Grable-Lytton → DOSPERT → BFI-2 → the 18-question adaptive elicitation engine, plus its 2 hidden retest questions). Immediately on completion — with no separate download-and-reupload step — the portal computes that respondent's own personalized portfolio recommendation live in the browser and displays it on the results screen: their EUT allocation (risky fraction, expected return, volatility), their SP/A-BPT allocation (safety-capital fraction, combined expected return and volatility), the top-10 risky-sleeve holdings, the Step 6 personality-linked commentary from Section 5's rules, and graphs of their own utility, value, probability-weighting and discount functions (the Step 4 graphical representation, drawn live from their posterior parameters), all generated from their own answers. A JSON export of the full raw response remains available for the researcher view."),
  H3("Researcher / group view"),
  P("A separate view lets us load some or all respondents' exported JSON files at once. It renders both the per-respondent results table (matching Section 3's tables) and a full group portfolio dashboard: the Empirical-Bayes pooled parameters for every loaded respondent (Section 2.5.4), and an expandable per-person detail panel reproducing the same EUT/BPT/top-holdings/commentary view each respondent saw individually, plus a CSV export carrying both raw and pooled parameters alongside every portfolio-construction output field used in Section 4."),

  H3("Full-project evaluation view"),
  P("A third view, reachable from the portal's start screen, walks an evaluator through the whole project without taking the survey or uploading anything: every instrument with its full item list, the elicitation engine's mathematics, the portfolio methodology, the pre-loaded results and portfolio dashboard for all five respondents, the Step 4 utility/value/weighting/discount graphs for the whole group (Figures 3.1–3.4, drawn live), and the key findings, with a CSV export of the results. It opens directly at https://mba680-robo-advisor.vercel.app/#evaluate."),
  H2("6.2 How it is implemented"),
  P("We built the portal as a single self-contained HTML/JavaScript page, hosted as a static site on Vercel. We had already implemented the survey and elicitation-engine logic (Section 2.5) in JavaScript; for this deliverable, we ported the portfolio-construction logic — the EUT tangency-portfolio and SP/A-BPT safety-first optimizations described mathematically in Section 4 — from our Python reference implementation (robo_advisory/portfolio/{eut,bpt}.py) into the same page, together with the real 66-stock asset universe (μ, Σ, rf) from Section 4.1, which we embedded directly in the page so that every computation runs client-side with no server round-trip."),
  P("The long-only, fully-invested safety-first optimization at the heart of both the EUT tangency portfolio and both SP/A-BPT mental-account layers is a linear-fractional program. We ported it using an active-set elimination method — justified by a Charnes-Cooper transformation that turns the problem into an equivalent convex quadratic program — rather than a cruder “solve unconstrained, clip negative weights to zero, renormalize” heuristic, because we found the cruder approach diverged materially from our Python reference implementation's constrained optimum specifically for the BPT aspiration layer (whose high threshold leaves many assets with negative unconstrained weight)."),

  H2("6.3 Verification"),
  P("Because this port re-implements numerical optimization logic in a second language, we verified it against our Python pipeline's own reference output through three independent automated test suites before publishing it, rather than trusting it on inspection alone:", { spacingAfter: 100 }),
  bullet([new TextRun({ text: "Portfolio-construction parity ", bold: true }), new TextRun({ text: "— we checked the JavaScript port's EUT and BPT outputs (risky fraction, safety-capital fraction, expected return, volatility, unclipped risky fraction) against our Python pipeline's outputs/real_peers_step5b_standard_lambda.csv for all five respondents; all values matched to within 10⁻³–10⁻⁶." })]),
  bullet([new TextRun({ text: "Hierarchical-pooling parity ", bold: true }), new TextRun({ text: "— we checked the JavaScript group-dashboard pooling logic (Section 2.5.4) against our Python pipeline's pooled (γ, λ) for all five respondents; all values matched to within 10⁻³." })]),
  bullet([new TextRun({ text: "End-to-end interaction testing ", bold: true }), new TextRun({ text: "— we ran a headless-browser (jsdom) test suite that drives the full respondent flow (all four instruments plus the adaptive engine) and separately the researcher/group-dashboard flow with the five respondents' real exported files, and asserts on the rendered page content — confirming the live portfolio recommendation, top-holdings table, and group dashboard actually render correctly for a real user, not just that the underlying functions return correct numbers." })]),
  P("All three suites passed before we published the portal to the link above.", { spacingAfter: 0 }),
  pageBreak(),
];

module.exports = { section6 };
