const { TextRun, Paragraph, AlignmentType, ExternalHyperlink } = require("docx");
const { H1, H2, H3, P, PR, bullet, caption, table, hrParagraph, pageBreak } = require("./build.js");

const PORTAL_URL = "https://mba680-robo-advisor.vercel.app";

function linkPar(url) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 100, after: 260 },
    children: [new ExternalHyperlink({
      link: url,
      children: [new TextRun({ text: url, style: "Hyperlink", size: 22 })],
    })],
  });
}

const section6 = [
  H1("6. The Interactive Robo-Advisory Portal (Deliverable b)"),
  P("Our second deliverable is a single interactive web portal that automates the entire Steps 2–6 pipeline — both the traditional (EUT) and behavioral (SP/A-BPT) portfolio-theory paths — end to end, functioning as a genuine robo-advisory offering rather than a data-collection form that feeds an offline analysis script."),
  linkPar(PORTAL_URL),

  H2("6.1 What the portal does"),
  H3("Respondent flow"),
  P("A respondent opens the link, enters their name, and is walked through all four survey instruments from Section 2 in sequence (general anchors → Grable-Lytton → DOSPERT → BFI-2 → the 18-question adaptive elicitation engine, plus its 2 hidden retest questions). Immediately on completion — with no separate download-and-reupload step — the portal computes that respondent's own personalized portfolio recommendation live in the browser and displays it on the results screen: their EUT allocation (equity share, expected return, volatility, chance of a losing year), their SP/A-BPT allocation (the safety and aspiration accounts, the G-Sec share, combined expected return, volatility and chance of a losing year), the top BPT holdings including G-Secs, the Step 6 personality-linked commentary from Section 5's rules, and graphs of their own utility, value, probability-weighting and discount functions (the Step 4 graphical representation, drawn live from their posterior parameters), all generated from their own answers. A JSON export of the full raw response remains available for the researcher view."),
  H3("Researcher / group view"),
  P("A separate view lets us load some or all respondents' exported JSON files at once. It renders both the per-respondent results table (matching Section 3's tables) and a full group portfolio dashboard: the Empirical-Bayes pooled parameters for every loaded respondent (Section 2.5.4), and an expandable per-person detail panel reproducing the same EUT/BPT/top-holdings/commentary view each respondent saw individually, plus a CSV export carrying both raw and pooled parameters alongside every portfolio-construction output field used in Section 4."),

  H3("Full-project evaluation view"),
  P("A third view, reachable from the portal's start screen, walks an evaluator through the whole project without taking the survey or uploading anything: every instrument with its full item list, the elicitation engine's mathematics, the portfolio methodology, the pre-loaded results and portfolio dashboard for all five respondents, the Step 4 utility/value/weighting/discount graphs for the whole group (Figures 3.1–3.4, drawn live), and the key findings, with a CSV export of the results. It opens directly at https://mba680-robo-advisor.vercel.app/#evaluate."),
  H2("6.2 How it is implemented"),
  P("We built the portal as a single self-contained HTML/JavaScript page, hosted as a static site on Vercel. We had already implemented the survey and elicitation-engine logic (Section 2.5) in JavaScript; for this deliverable, we ported the portfolio-construction logic described in Section 4 from our Python reference implementation (robo_advisory/portfolio/{eut,bpt}.py) into the same page, together with the real 66-stock asset universe (μ, Σ, rf) from Section 4.1, which we embedded directly in the page so that every computation runs client-side with no server round-trip."),
  P("The two optimizations at the heart of the model — the 10%-capped tangency portfolio and the capped Roy aspiration portfolio — are ratio-maximization problems. The page solves both exactly in the browser through the same convex reformulation our Python code uses (minimize y'Σy subject to (μ − H)'y = 1, y ≥ 0 and y_i ≤ 0.10·Σy), with an ADMM iteration of the kind used by the OSQP solver: one Cholesky factorization, then cheap iterations until the residuals fall below 10⁻¹⁰, which takes about 0.2 seconds. Because these two portfolios do not depend on the client, the page solves them once and then, for each client, applies the closed-form steps: the EUT equity share from γ, Telser's G-Sec/equity split for the safety account, and the λ-driven split between the accounts."),

  H2("6.3 Verification"),
  P("Because this port re-implements numerical optimization logic in a second language, we verified it against our Python pipeline's own reference output through three independent automated test suites before publishing it, rather than trusting it on inspection alone:", { spacingAfter: 100 }),
  bullet([new TextRun({ text: "Portfolio-construction parity ", bold: true }), new TextRun({ text: "— we checked the browser's capped tangency and aspiration weights against the Python solution (largest difference 5×10⁻⁶ in any weight), and every client-level output — equity share, unclipped share, safety-account share, G-Sec weight, expected return, volatility, chance of a losing year and largest single-stock position — against our Python pipeline's outputs/real_peers_step5b_standard_lambda.csv for all five respondents; all matched to within 10⁻⁵. Our Python test suite separately checks that the capped solver reproduces the closed-form tangency portfolio when the cap does not bind and beats 200 random feasible portfolios when it does." })]),
  bullet([new TextRun({ text: "Hierarchical-pooling parity ", bold: true }), new TextRun({ text: "— we checked the JavaScript group-dashboard pooling logic (Section 2.5.4) against our Python pipeline's pooled (γ, λ) for all five respondents; all values matched to within 10⁻³." })]),
  bullet([new TextRun({ text: "End-to-end interaction testing ", bold: true }), new TextRun({ text: "— we ran a headless-browser (jsdom) test suite that drives the full respondent flow (all four instruments plus the adaptive engine) and separately the researcher/group-dashboard flow with the five respondents' real exported files, and asserts on the rendered page content — confirming the live portfolio recommendation, top-holdings table, and group dashboard actually render correctly for a real user, not just that the underlying functions return correct numbers." })]),
  P("All three suites passed before we published the portal to the link above.", { spacingAfter: 0 }),
  pageBreak(),
];

module.exports = { section6 };
