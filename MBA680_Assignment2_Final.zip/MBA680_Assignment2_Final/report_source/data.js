// Structured data feeding the report build script. All figures are the
// authoritative final numbers from the Python pipeline's outputs/*.csv
// (real_peers_steps2to4and6.csv, real_peers_step5b_standard_lambda.csv,
// real_peers_step5b_top_holdings.csv), reproduced exactly.

const GRABLE_LYTTON_ITEMS = [
  { q: "In general, how would your best friend describe you as a risk taker?",
    opts: ["A real gambler", "Willing to take risks after completing adequate research", "Cautious", "A real risk avoider"] },
  { q: "You are on a TV game show and can choose one of the following. Which would you take?",
    opts: ["$1,000 in cash", "A 50% chance at winning $5,000", "A 25% chance at winning $10,000", "A 5% chance at winning $100,000"] },
  { q: "You have just finished saving for a “once-in-a-lifetime” vacation. Three weeks before you plan to leave, you lose your job. You would:",
    opts: ["Cancel the vacation", "Take a much more modest vacation", "Go as scheduled, reasoning that you need the time to prepare for a job search", "Extend your vacation, because this might be your last chance to go first-class"] },
  { q: "If you unexpectedly received $20,000 to invest, what would you do?",
    opts: ["Deposit it in a bank account, money market account, or insured CD", "Invest it in safe high-quality bonds or bond mutual funds", "Invest it in stocks or stock mutual funds"] },
  { q: "In terms of experience, how comfortable are you investing in stocks or stock mutual funds?",
    opts: ["Not at all comfortable", "Somewhat comfortable", "Very comfortable"] },
  { q: "When you think of the word “risk,” which of the following words comes to mind first?",
    opts: ["Loss", "Uncertainty", "Opportunity", "Thrill"] },
  { q: "Most of your investment assets are now in high-interest government bonds. Hard assets (gold, jewels, collectibles, real estate) are expected to rise; bond prices may fall. What would you do?",
    opts: ["Hold the bonds", "Sell the bonds, put half into money market accounts, half into hard assets", "Sell the bonds and put the total proceeds into hard assets", "Sell the bonds, put all the money into hard assets, and borrow additional money to buy more"] },
  { q: "Given the best and worst case returns of the four investment choices below, which would you prefer?",
    opts: ["$200 gain best case; $0 gain/loss worst case", "$800 gain best case, $200 loss worst case", "$2,600 gain best case, $800 loss worst case", "$4,800 gain best case, $2,400 loss worst case"] },
  { q: "In addition to whatever you own, you have been given $1,000. You are now asked to choose between:",
    opts: ["A sure gain of $500", "A 50% chance to gain $1,000 and a 50% chance to gain nothing"] },
  { q: "In addition to whatever you own, you have been given $2,000. You are now asked to choose between:",
    opts: ["A sure loss of $500", "A 50% chance to lose $1,000 and a 50% chance to lose nothing"] },
  { q: "Suppose a relative left you an inheritance of $100,000, stipulating that you invest ALL the money in ONE of the following. Which would you select?",
    opts: ["A savings account or money market mutual fund", "A mutual fund that owns stocks and bonds", "A portfolio of 15 common stocks", "Commodities like gold, silver, and oil"] },
  { q: "If you had to invest $20,000, which of the following investment choices would you find most appealing?",
    opts: ["60% low-risk / 30% medium-risk / 10% high-risk", "30% low-risk / 40% medium-risk / 30% high-risk", "10% low-risk / 40% medium-risk / 50% high-risk"] },
  { q: "Your trusted friend, an experienced geologist, is putting together a group of investors for an exploratory gold mining venture (20% chance of success; 50-100x payoff if successful, total loss if not). How much would you invest?",
    opts: ["Nothing", "One month's salary", "Three months' salary", "Six months' salary"] },
];

const DOSPERT_FIN_ITEMS = [
  { text: "Betting a day's income at the horse races.", domain: "Gambling" },
  { text: "Investing 10% of your annual income in a moderate growth mutual fund.", domain: "Investing" },
  { text: "Betting a day's income at a high-stake poker game.", domain: "Gambling" },
  { text: "Investing 5% of your annual income in a very speculative stock.", domain: "Investing" },
  { text: "Betting a day's income on the outcome of a sporting event.", domain: "Gambling" },
  { text: "Investing 10% of your annual income in a new business venture.", domain: "Investing" },
];

const BFI2_ITEMS = [
  { text: "Is outgoing, sociable", domain: "Extraversion", facet: "Sociability", reverse: false },
  { text: "Tends to be quiet", domain: "Extraversion", facet: "Sociability", reverse: true },
  { text: "Is sometimes shy, introverted", domain: "Extraversion", facet: "Sociability", reverse: true },
  { text: "Is talkative", domain: "Extraversion", facet: "Sociability", reverse: false },
  { text: "Has an assertive personality", domain: "Extraversion", facet: "Assertiveness", reverse: false },
  { text: "Is dominant, acts as a leader", domain: "Extraversion", facet: "Assertiveness", reverse: false },
  { text: "Prefers to have others take charge", domain: "Extraversion", facet: "Assertiveness", reverse: true },
  { text: "Finds it hard to influence people", domain: "Extraversion", facet: "Assertiveness", reverse: true },
  { text: "Is full of energy", domain: "Extraversion", facet: "Energy Level", reverse: false },
  { text: "Shows a lot of enthusiasm", domain: "Extraversion", facet: "Energy Level", reverse: false },
  { text: "Rarely feels excited or eager", domain: "Extraversion", facet: "Energy Level", reverse: true },
  { text: "Is less active than other people", domain: "Extraversion", facet: "Energy Level", reverse: true },
  { text: "Is compassionate, has a soft heart", domain: "Agreeableness", facet: "Compassion", reverse: false },
  { text: "Is helpful and unselfish with others", domain: "Agreeableness", facet: "Compassion", reverse: false },
  { text: "Can be cold and uncaring", domain: "Agreeableness", facet: "Compassion", reverse: true },
  { text: "Feels little sympathy for others", domain: "Agreeableness", facet: "Compassion", reverse: true },
  { text: "Is respectful, treats others with respect", domain: "Agreeableness", facet: "Respectfulness", reverse: false },
  { text: "Is polite, courteous to others", domain: "Agreeableness", facet: "Respectfulness", reverse: false },
  { text: "Is sometimes rude to others", domain: "Agreeableness", facet: "Respectfulness", reverse: true },
  { text: "Starts arguments with others", domain: "Agreeableness", facet: "Respectfulness", reverse: true },
  { text: "Assumes the best about people", domain: "Agreeableness", facet: "Trust", reverse: false },
  { text: "Has a forgiving nature", domain: "Agreeableness", facet: "Trust", reverse: false },
  { text: "Tends to find fault with others", domain: "Agreeableness", facet: "Trust", reverse: true },
  { text: "Is suspicious of others' intentions", domain: "Agreeableness", facet: "Trust", reverse: true },
  { text: "Is systematic, likes to keep things in order", domain: "Conscientiousness", facet: "Organization", reverse: false },
  { text: "Keeps things neat and tidy", domain: "Conscientiousness", facet: "Organization", reverse: false },
  { text: "Tends to be disorganized", domain: "Conscientiousness", facet: "Organization", reverse: true },
  { text: "Leaves a mess, doesn't clean up", domain: "Conscientiousness", facet: "Organization", reverse: true },
  { text: "Is efficient, gets things done", domain: "Conscientiousness", facet: "Productiveness", reverse: false },
  { text: "Is persistent, works until the task is finished", domain: "Conscientiousness", facet: "Productiveness", reverse: false },
  { text: "Tends to be lazy", domain: "Conscientiousness", facet: "Productiveness", reverse: true },
  { text: "Has difficulty getting started on tasks", domain: "Conscientiousness", facet: "Productiveness", reverse: true },
  { text: "Is reliable, can always be counted on", domain: "Conscientiousness", facet: "Responsibility", reverse: false },
  { text: "Is dependable, steady", domain: "Conscientiousness", facet: "Responsibility", reverse: false },
  { text: "Can be somewhat careless", domain: "Conscientiousness", facet: "Responsibility", reverse: true },
  { text: "Sometimes behaves irresponsibly", domain: "Conscientiousness", facet: "Responsibility", reverse: true },
  { text: "Worries a lot", domain: "Negative Emotionality", facet: "Anxiety", reverse: false },
  { text: "Can be tense", domain: "Negative Emotionality", facet: "Anxiety", reverse: false },
  { text: "Is relaxed, handles stress well", domain: "Negative Emotionality", facet: "Anxiety", reverse: true },
  { text: "Rarely feels anxious or afraid", domain: "Negative Emotionality", facet: "Anxiety", reverse: true },
  { text: "Often feels sad", domain: "Negative Emotionality", facet: "Depression", reverse: false },
  { text: "Tends to feel depressed, blue", domain: "Negative Emotionality", facet: "Depression", reverse: false },
  { text: "Feels secure, comfortable with self", domain: "Negative Emotionality", facet: "Depression", reverse: true },
  { text: "Stays optimistic after experiencing a setback", domain: "Negative Emotionality", facet: "Depression", reverse: true },
  { text: "Is temperamental, gets emotional easily", domain: "Negative Emotionality", facet: "Emotional Volatility", reverse: false },
  { text: "Is moody, has up and down mood swings", domain: "Negative Emotionality", facet: "Emotional Volatility", reverse: false },
  { text: "Is emotionally stable, not easily upset", domain: "Negative Emotionality", facet: "Emotional Volatility", reverse: true },
  { text: "Keeps their emotions under control", domain: "Negative Emotionality", facet: "Emotional Volatility", reverse: true },
  { text: "Is complex, a deep thinker", domain: "Open-Mindedness", facet: "Intellectual Curiosity", reverse: false },
  { text: "Is curious about many different things", domain: "Open-Mindedness", facet: "Intellectual Curiosity", reverse: false },
  { text: "Has little interest in abstract ideas", domain: "Open-Mindedness", facet: "Intellectual Curiosity", reverse: true },
  { text: "Avoids intellectual, philosophical discussions", domain: "Open-Mindedness", facet: "Intellectual Curiosity", reverse: true },
  { text: "Is fascinated by art, music, or literature", domain: "Open-Mindedness", facet: "Aesthetic Sensitivity", reverse: false },
  { text: "Values art and beauty", domain: "Open-Mindedness", facet: "Aesthetic Sensitivity", reverse: false },
  { text: "Has few artistic interests", domain: "Open-Mindedness", facet: "Aesthetic Sensitivity", reverse: true },
  { text: "Thinks poetry and plays are boring", domain: "Open-Mindedness", facet: "Aesthetic Sensitivity", reverse: true },
  { text: "Is inventive, finds clever ways to do things", domain: "Open-Mindedness", facet: "Creative Imagination", reverse: false },
  { text: "Is original, comes up with new ideas", domain: "Open-Mindedness", facet: "Creative Imagination", reverse: false },
  { text: "Has little creativity", domain: "Open-Mindedness", facet: "Creative Imagination", reverse: true },
  { text: "Has difficulty imagining things", domain: "Open-Mindedness", facet: "Creative Imagination", reverse: true },
];

// ---- Survey outcomes (Steps 2-4 & 6), from outputs/real_peers_steps2to4and6.csv ----
const RESPONDENTS = [
  {
    name: "Shree Charan", generalRisk: 7, generalPatience: 7,
    glTotal: 27, glLevel: "Average/moderate",
    dospertInv: 7.000, dospertGamb: 7.000,
    gammaRaw: 2.300, gammaPooled: 2.212, lamRaw: 1.000, lamPooled: 1.000,
    alphaW: 0.569, betaHyp: 0.798, delta: 0.944, retest: 1.0,
    bfi2: { Extraversion: 3.00, Agreeableness: 3.00, Conscientiousness: 3.00, "Negative Emotionality": 3.00, "Open-Mindedness": 3.00 },
    flag: "All five BFI-2 domain scores are exactly 3.00 — a perfectly flat profile. This is mathematically possible but statistically unusual across 60 items with mixed reverse-keying, and is flagged as a likely low-effort / straight-lined response rather than taken as a genuine null personality signal.",
  },
  {
    name: "Kshitij", generalRisk: 3, generalPatience: 6,
    glTotal: 31, glLevel: "Above-average",
    dospertInv: 5.000, dospertGamb: 5.000,
    gammaRaw: -0.500, gammaPooled: -0.500, lamRaw: 1.600, lamPooled: 1.600,
    alphaW: 0.400, betaHyp: 0.630, delta: 0.900, retest: 1.0,
    bfi2: { Extraversion: 3.42, Agreeableness: 2.92, Conscientiousness: 2.92, "Negative Emotionality": 3.00, "Open-Mindedness": 2.50 },
    flag: "Elicited risk aversion γ is negative (−0.50) — formally a CRRA/EUT boundary violation (implies risk-seeking, non-concave utility). Floored to 0.05 for all portfolio-construction arithmetic; the raw negative value is preserved and disclosed rather than silently discarded.",
  },
  {
    name: "Kartika", generalRisk: 4, generalPatience: 7,
    glTotal: 31, glLevel: "Above-average",
    dospertInv: 4.667, dospertGamb: 6.667,
    gammaRaw: 0.200, gammaPooled: 0.200, lamRaw: 1.000, lamPooled: 1.000,
    alphaW: 1.000, betaHyp: 0.900, delta: 0.930, retest: 1.0,
    bfi2: { Extraversion: 3.75, Agreeableness: 3.67, Conscientiousness: 2.83, "Negative Emotionality": 2.17, "Open-Mindedness": 3.17 },
    flag: "Most internally-varied BFI-2 profile of the group (domain scores spread from 2.17 to 3.75) — the most differentiated, individually-informative personality read among the five respondents.",
  },
  {
    name: "Ayushi", generalRisk: 7, generalPatience: 7,
    glTotal: 35, glLevel: "High",
    dospertInv: 6.333, dospertGamb: 4.333,
    gammaRaw: 2.294, gammaPooled: 2.206, lamRaw: 1.009, lamPooled: 1.009,
    alphaW: 1.090, betaHyp: 0.764, delta: 0.945, retest: 0.5,
    bfi2: { Extraversion: 3.50, Agreeableness: 3.50, Conscientiousness: 3.33, "Negative Emotionality": 3.00, "Open-Mindedness": 4.00 },
    flag: "Retest consistency is 0.50 (vs. 1.00 for the other four respondents) — her two hidden repeat-question answers diverged from her original answers. Flagged as a data-quality caveat; not excluded from analysis.",
  },
  {
    name: "Adwaaiit Pande", generalRisk: 10, generalPatience: 4,
    glTotal: 40, glLevel: "High",
    dospertInv: 4.667, dospertGamb: 4.333,
    gammaRaw: 2.273, gammaPooled: 2.187, lamRaw: 1.015, lamPooled: 1.015,
    alphaW: 1.253, betaHyp: 0.938, delta: 0.976, retest: 1.0,
    bfi2: { Extraversion: 3.75, Agreeableness: 3.58, Conscientiousness: 3.75, "Negative Emotionality": 2.75, "Open-Mindedness": 3.83 },
    flag: "Self-reported general risk tolerance (10/10) and Grable-Lytton score (40, “High” — the highest in the group) do not obviously track the adaptively-elicited γ≈2.19, which sits in the same moderately-risk-averse band as Shree Charan and Ayushi rather than being the lowest in the group. A self-report-vs-revealed-preference divergence worth a follow-up conversation before finalizing any recommendation.",
  },
];

// ---- Step 5b portfolio results (standard-lambda universe), from
// outputs/real_peers_step5b_standard_lambda.csv. This is the version used
// for the final recommendation (see Section 4.1 for why).
const PORTFOLIO_RESULTS = [
  { name: "Shree Charan", riskyFrac: 1.000, eutRet: 0.1321, eutVol: 0.1608, safetyFrac: 0.3000, bptRet: 0.1619, bptVol: 0.2946, unclipped: 1.130 },
  { name: "Kshitij", riskyFrac: 1.000, eutRet: 0.1321, eutVol: 0.1608, safetyFrac: 0.4000, bptRet: 0.1577, bptVol: 0.2712, unclipped: 50.000 },
  { name: "Kartika", riskyFrac: 1.000, eutRet: 0.1321, eutVol: 0.1608, safetyFrac: 0.3000, bptRet: 0.1619, bptVol: 0.2946, unclipped: 12.500 },
  { name: "Ayushi", riskyFrac: 1.000, eutRet: 0.1321, eutVol: 0.1608, safetyFrac: 0.3015, bptRet: 0.1619, bptVol: 0.2942, unclipped: 1.133 },
  { name: "Adwaaiit Pande", riskyFrac: 1.000, eutRet: 0.1321, eutVol: 0.1608, safetyFrac: 0.3025, bptRet: 0.1618, bptVol: 0.2940, unclipped: 1.143 },
];

// Top-10 holdings within the risky/tangency sleeve (identical across all
// five respondents by construction -- see Section 4.3). Weight is the
// share WITHIN the risky sleeve (i.e. of the equity allocation itself, not
// of total wealth).
const TOP_HOLDINGS = [
  { ticker: "TCS", weight: 0.1297 },
  { ticker: "HINDUNILVR", weight: 0.0749 },
  { ticker: "SUNPHARMA", weight: 0.0719 },
  { ticker: "ADANIPORTS", weight: 0.0605 },
  { ticker: "BEL", weight: 0.0469 },
  { ticker: "SHRIRAMFIN", weight: 0.0413 },
  { ticker: "HINDZINC", weight: 0.0401 },
  { ticker: "DIVISLAB", weight: 0.0354 },
  { ticker: "JIOFIN", weight: 0.0251 },
  { ticker: "CHOLAFIN", weight: 0.0248 },
];

module.exports = { GRABLE_LYTTON_ITEMS, DOSPERT_FIN_ITEMS, BFI2_ITEMS, RESPONDENTS, PORTFOLIO_RESULTS, TOP_HOLDINGS };
